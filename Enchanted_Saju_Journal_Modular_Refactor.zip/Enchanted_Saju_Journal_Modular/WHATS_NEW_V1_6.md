# Enchanted Saju Journal v1.6 — What’s New

v1.6 expands the working v1.5 calculator into a broader **Saju analysis application** without replacing the validated deterministic pipeline.

## Fully implemented in v1.6

- Full app navigation: **Today · My Saju · Luck Calendar · Calculator · People · Research · Glossary**.
- Saved **People** browser and reusable Primary Chart loading from Notion.
- Saved Chart application view with tabs: Overview, Elements, Ten Gods, Relationships, Advanced, Luck Cycles, Interpretation and Audit.
- Master result schema (`2.0.0`) and central methodology registry.
- Chart revision support: saving a new verified calculation creates a new Chart revision rather than silently overwriting the earlier Chart.
- Technical Chart persistence through `Technical Result JSON`, `Calculation Audit JSON`, `Analysis Settings`, method/version fields and `Current Revision`.
- Approximate birth-time uncertainty display: possible pillar variants are shown rather than silently choosing one.
- Hidden Stem roles: Main / Middle / Residual.
- Five Element visualisation with raw-presence view and productive/controlling cycles.
- Ten God aggregate **raw occurrence** analysis. Weighted Ten God scoring remains disabled until a methodology is certified.
- Advanced Analysis Settings are saved with the Chart but do not affect calculations until their corresponding method is implemented.
- Expanded Major Luck presentation.
- Multi-year **Annual Luck** explorer.
- Full **12 solar-term month** Monthly Luck explorer.
- Interactive Daily Luck monthly calendar that reuses saved Daily Luck records when they exist and deterministically previews dates when they do not.
- Structured relationship records and **Wonjin (원진)** detection.
- Relationship filter/chip interface.
- Full natal Workers AI interpretation from locked Chart data.
- Expanded Daily AI format: Overall Theme, Day Master Relationship, Elemental Influence, Ten God Influence, Natal Interactions, Major/Annual/Monthly Context, Work & Study, Relationships, Money & Resources, Creativity, Energy & Pace, Things to Notice and Reflection Prompt.
- Expanded protected permanent Daily Journal scaffold.
- **Research Inbox** with Website, PDF/Transcript, YouTube, Paste Text and Book/Manual workflows.
- Client-side PDF text-layer extraction with page markers; scanned PDFs are flagged **OCR required** instead of guessed.
- YouTube public metadata + video ID; transcripts are pasted/uploaded rather than scraped.
- Original research-file upload to the Notion `Original Material` property for files up to the configured direct-upload limit.
- Workers AI concept tagging constrained to existing **Saju Concepts** names.
- Source-derived content, AI Summary and My Interpretation remain separate.
- Glossary browser backed by the real Saju Concepts database.
- Developer **Compatibility Tests** with MATCH / DIFFERENT / METHOD-DEPENDENT / UNKNOWN statuses.

## Intentionally methodology-pending

The UI/framework now exists, but v1.6 **does not fabricate** results for:

- Lunar birth-date conversion
- Weighted Five Element Strength
- Weighted Ten God distribution
- Chart Strength
- Useful / Favourable / Unfavourable Element
- Symbolic Stars
- Twelve Stars

These remain `Methodology Pending` until an explicit, documented rule set is selected, implemented and regression-tested.

## Preserved from v1.5

v1.6 keeps the working v1.5 behaviour: deterministic natal calculation, historical timezone/solar correction, verified Chart saving, Notion relations, Daily Luck duplicate prevention, current Major/Annual/Monthly context, Workers AI Daily Reading, formatted permanent Daily Luck pages, protected journal content, and the automatically replaced live **Today** page while past days remain in the Daily Luck database.
