#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Updating Enchanted Saju — Update 5 Enchanted Field Journal..."
npm install
npm test
npx wrangler deploy
cat <<'MSG'
Update complete.
1. Open the same workers.dev URL and hard-refresh.
2. Explore Today, My Saju, People, Journal and Learn.
3. Open Timeline → 60 Jiazi Reference for the 60-type cabinet.
4. Existing charts do not need recalculation.
5. JewelSJPJ terminology, Research sources and the resumable importer are preserved.
MSG
