# Beginner Update — Enchanted Saju Update 2

## Update your existing installation

1. Extract the Update 2 ZIP.
2. Double-click **`update_existing_windows.bat`**.
3. The updater installs dependencies and runs the complete regression suite.
4. If the tests pass, it deploys to the **same Cloudflare Worker**.
5. Open your normal `workers.dev` address.
6. Press **Ctrl + F5**.
7. Click **Settings & Audit → Test Notion connection**.

No new Saju calculation method, Worker, Notion token, private save key or Workers AI key is required.

## What changed

### Today
Choose an Active Profile at the top. Today now displays the deterministic Day Pillar, animal, elements, Daily Ten God, current Major/Annual/Monthly layers and real chart interactions. AI interpretation appears below and is labelled separately.

### Calendar
Month View is a visual daily almanac. Toggle Animals, Elements, Ten Gods, Interactions, Journal Entries and Important Events. Clicking a date opens that profile's Daily Detail on Today.

Year View shows all 12 solar-term Saju months for the selected year.

### Journal
Journal entries are stored by **Profile ID + Date**. Ratings are 1–5 for Mood, Energy, Productivity, Social Energy and Stress. Add resonance, notes, highlights, challenges and tags.

### Timeline
Timeline displays saved Major Luck cycles. User-recorded life events are visibly separate from calculated luck cycles. Select a Major Luck period to inspect annual pillars inside it.

## Notion storage

Your workspace has been prepared with the additional Daily Luck fields used by Update 2:

- Social Energy
- Stress
- Resonance
- Highlights
- Challenges
- Custom Tags

The existing **Life Events** database is used for personal timeline events.
