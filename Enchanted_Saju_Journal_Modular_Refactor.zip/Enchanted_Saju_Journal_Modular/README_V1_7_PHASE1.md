# Enchanted Saju Journal v1.7 — Phase 1

Incremental upgrade of v1.6.2 implementing exactly four deterministic modules:

1. KASI lunar → Gregorian conversion
2. Weighted Five Element Strength
3. Weighted Ten God Distribution
4. Chart Strength

Start with `BEGINNER_UPDATE_V1_7_PHASE1.md`.

Technical methodology: `METHODOLOGY_V1_7_PHASE1.md`.

Test evidence: `TEST_REPORT_V1_7_PHASE1.md`.
