# Enchanted Saju — Update 4 Changelog

## Knowledge identity

- Added `concept_id`-centred terminology architecture.
- Alternate terms now resolve through alias indexing rather than becoming separate concepts.
- Added source-traceable alias records and full terminology fields for Glossary display.
- Added tolerant alias normalisation for case, whitespace, punctuation and hyphens without auto-merging unrelated concepts.

## JewelSJPJ terminology

- Added the ten accessible Stem / Day Master labels as preferred ordinary-site terminology.
- Added all 60 SJPJ Type names using accessible Stem name + Earthly Branch animal.
- Preserved Hanja, Korean, romanisation and technical English identities.
- Updated beginner-facing chart, Today, People, Compare, calendar and journal surfaces.

## Glossary / Learn

- Added all 60 Jiazi as canonical reference concepts, including stable IDs and verified search aliases.
- Glossary cards now show the accessible name first and the technical identity second.
- Glossary detail now separates formal/technical names, source-specific names and metaphors.
- Concept learning can resolve virtual or Notion-backed canonical concepts by alias.

## Research / sources

- Added Initial Knowledge Source Pack manifest with 41 records: 40 retrievable document records plus one Saju Atelier parent collection.
- Added 36 separately addressable Saju Atelier article records.
- Added embedded private text for the two user-supplied JewelSJPJ PDFs.
- Added Qiora same-site Learn/Reference collection retrieval.
- Added idempotent source upsert using permanent `source_id` metadata.
- Added terminology alias extraction and source-specific provenance.
- Added import progress/status, inaccessible-source reporting and duplicate-URL reporting.

## AI interpretation boundary

- Accessible terminology is preferred in AI prose while locked chart values remain unchanged.
- Natal interpretation provenance now also probes the Day Pillar / 60 SJPJ Type.
- Relevant short extracts from privately indexed source notes can be passed as interpretive context.
- Source excerpts are explicitly prevented from overriding deterministic calculations.

## Calculation engine

No deterministic calculation methodology was changed in Update 4.
