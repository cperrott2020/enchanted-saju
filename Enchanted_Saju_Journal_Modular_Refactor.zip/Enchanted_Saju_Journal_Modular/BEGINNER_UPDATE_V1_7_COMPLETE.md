# Beginner Update — Enchanted Saju Journal v1.7 Complete

This updates your existing v1.7 Phase 1 installation **in place**. It keeps the same Cloudflare Worker, Notion workspace, private connection key, Workers AI binding and Daily Luck archive.

## Windows

1. Download and extract the v1.7 Complete ZIP.
2. Open the extracted folder.
3. Double-click **`update_existing_windows.bat`**.
4. The script installs the pinned dependencies, runs the complete regression suite and deploys to the same Worker.
5. Open your existing `workers.dev` calculator address.
6. Press **Ctrl + F5**.
7. Click **Test Notion connection**.
8. Calculate a chart and verify the Advanced section now contains:
   - Chart Strength
   - Useful / Favourable / Unfavourable Elements
   - Void
   - Twelve Growth Stages
   - Symbolic Stars
   - Twelve Stars
9. Save a verified Chart to create a new revision with the v1.7 Complete technical result. Older revisions are not overwritten.

## macOS / Linux

```bash
chmod +x update_existing_mac_linux.sh
./update_existing_mac_linux.sh
```

Then hard-refresh the same Worker URL.

## Lunar dates

No KASI API key is required. The completed project keeps the Phase 1 offline lunar method and pins `korean-lunar-calendar` 0.4.0. The old `configure_kasi_*` files remain only as harmless compatibility notices.

## What you should see

### Advanced → Useful/Favourable/Unfavourable

You will see the selected element, method ID, deterministic factors and an expandable **How was this calculated?** panel. A workbook-borderline strength case is marked **Provisional**.

### Symbolic Stars

Only enabled rule tables are calculated. Each detected star shows its trigger/reference positions and a `?` expansion. The Saju Concept/research button opens the corresponding concept where one exists.

### Twelve Stars

This is shown under its own heading and explicitly says it is **not Twelve Growth Stages**.

## Saving to Notion

The existing Chart properties are reused:

- Useful Element
- Favourable Element
- Unfavourable Element
- Useful Element Method
- Symbolic Star Method
- Technical Result JSON
- Calculation Audit JSON

No large new property set is required.

## Important

A mismatch with ForceTeller is diagnostic. Do not change a method just to force a match. Use Compatibility Tests to identify the differing method/version first.
