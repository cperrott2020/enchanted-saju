# Enchanted Saju — Update 4.1 Hotfix Test Report

**40 automated suites passed** (the 38 inherited Update 4 suites plus 2 new retry/resume hotfix suites).

The hotfix adds regression coverage for:

- temporary upstream failure classification;
- HTTP status preservation;
- `Retry-After` parsing;
- resumable source queue persistence;
- skip-existing Ready / Needs Review behaviour;
- Retry Failed Sources fallback for the original Update 4 run;
- 5s / 15s / 30s retry backoff;
- 60-second cooldown after repeated Saju Atelier failures;
- 4-second Saju Atelier request spacing;
- Pause / Resume UI.

The deterministic Saju calculation engine is unchanged by this hotfix.
