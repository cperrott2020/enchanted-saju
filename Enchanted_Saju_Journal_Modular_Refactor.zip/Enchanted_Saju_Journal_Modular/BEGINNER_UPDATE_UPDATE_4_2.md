# Beginner Update — Enchanted Saju Update 4.2

## Windows

1. Extract the Update 4.2 ZIP.
2. Double-click **`update_existing_windows.bat`**.
3. Let the tests finish and the same Cloudflare Worker deploy.
4. Open your usual Enchanted Saju URL and press **Ctrl + F5**.
5. Open **Research → Initial Knowledge Source Pack → Import / Resume Pack**.

The importer skips sources already stored as Ready / Needs Review. It will add the two new JewelSJPJ lesson sources and then continue any source records that are still missing.

## What changes on the site

The Ten Gods now use JewelSJPJ's accessible names first: **Self, Rival, Creator, Rebel, Entrepreneur, Provider, Wild Card, Official, Mystic and Nurturer God**.

The Korean/Hanja and earlier technical English remain attached and searchable, so for example **Official God**, **Direct Officer**, **정관** and **正官** all refer to the same canonical concept.

Existing charts do not need to be recalculated.
