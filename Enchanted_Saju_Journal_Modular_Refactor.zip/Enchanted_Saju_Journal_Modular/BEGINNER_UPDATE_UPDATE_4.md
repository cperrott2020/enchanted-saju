# Beginner Update — Enchanted Saju Update 4

This update keeps your existing Cloudflare Worker, Notion data, private connection key and saved charts.

## Windows

1. Extract the Update 4 ZIP.
2. Open the extracted folder.
3. Double-click **`update_existing_windows.bat`**.
4. Let it install dependencies, run the tests and deploy.
5. Open the **same** Enchanted Saju `workers.dev` address you already use.
6. Press **Ctrl + F5**.

## macOS / Linux

Open Terminal in the extracted folder and run:

```bash
chmod +x update_existing_mac_linux.sh
./update_existing_mac_linux.sh
```

Then open the same Worker URL and hard-refresh.

## One new step: import the knowledge pack

After Update 4 is deployed:

1. Open **Research**.
2. Find **Initial Knowledge Source Pack**.
3. Click **Import / Refresh Pack**.
4. Leave the page open while the progress report runs.
5. The app creates any missing canonical 60 SJPJ Type concepts first.
6. It then indexes each source separately and records its source identity and terminology aliases.
7. If a public website blocks retrieval or has no readable text, the app reports it as **Failed / Needs Review** instead of pretending it was imported.

You can safely use **Import / Refresh Pack** again later. Initial-source records are upserted by their permanent source IDs instead of intentionally creating duplicate source records.

## What you should see

Normal beginner-facing screens now prefer names such as:

- Blue Tree
- Blue Vine
- Red Sun
- Red Moon
- Yellow Mountain
- Yellow Garden
- White Sword
- White Jewel
- Black Ocean
- Black Mist

The technical identity remains visible secondarily, for example:

**Black Mist**  
`癸 · Yin Water`

The Glossary exposes the fuller terminology structure and searches all verified aliases.

## Important

You do **not** need to recalculate old charts for this terminology update. Calculation values have not been changed.
