@echo off
setlocal
cd /d "%~dp0"

echo =============================================================
echo   ENCHANTED SAJU - UPDATE 5 ENCHANTED FIELD JOURNAL
echo   Visual redesign + all 60 SJPJ type art identities
echo.
echo   Updates your existing Worker in place and preserves the
echo   deterministic Saju calculation engine, Notion data and sources.
echo =============================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install the LTS version from https://nodejs.org/ then run this again.
  pause
  exit /b 1
)

echo Installing/updating project dependencies and Wrangler...
call npm install
if errorlevel 1 goto :error

echo.
echo Running the COMPLETE regression suite...
call npm test
if errorlevel 1 goto :error

echo.
echo Deploying Update 5 to the SAME Cloudflare Worker...
call npx wrangler deploy
if errorlevel 1 goto :error

echo.
echo =============================================================
echo UPDATE COMPLETE.
echo.
echo 1. Open your existing workers.dev URL.
echo 2. Press Ctrl+F5 to hard refresh.
echo 3. Explore Today, My Saju, People, Journal and Learn.
echo 4. Open Timeline - 60 Jiazi Reference to see the 60-type cabinet.
echo 5. Existing charts do NOT need recalculation.
echo 6. Update 4.2 JewelSJPJ God terminology and the resumable Research

echo    importer are preserved; no source re-import is required merely

echo    because of this visual update.
echo =============================================================
pause
exit /b 0

:error
echo.
echo The update stopped. Copy the last error message and send it to ChatGPT.
pause
exit /b 1
