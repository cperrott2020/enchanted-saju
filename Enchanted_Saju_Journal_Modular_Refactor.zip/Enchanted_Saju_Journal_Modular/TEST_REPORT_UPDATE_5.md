# Enchanted Saju — Update 5 Test Report

## Automated result

**42 automated suites passed.**

The complete inherited Update 4.2 regression suite passed together with:

- `update5_visual_redesign_test.mjs`

Update 5 coverage verifies:

- the new visual design tokens and ornament references
- accessibility / reduced-motion hooks
- original type-art helper integration
- all 60 unique SJPJ/Jiazi manifest records
- all **120** required SJPJ SVG files
- the five reusable ornament assets
- no uploaded mood-board JPG/PNG reference image is copied into the public application assets
- inherited profile, chart, Today, calendar, journal, timeline, compare, Learn, Research and knowledge-source contracts

## Deterministic calculation regression boundary

A recursive comparison of `src/` between Update 4.2 and Update 5 reports **no differences**.

Core deterministic hashes remain:

```text
efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785  src/daily_engine.js
8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb  src/solar_terms.js
77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0  src/luck_explorer.js
26fc3f70ecaf7406b63e635f03a2ec224cbc80fb98b3483533aef242391dd15b  src/method_registry.js
6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2  src/phase1/lunar_conversion.js
d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca  src/phase1/weighted_analysis.js
2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff  src/phase1/chart_strength.js
112d93135069292af6158eec9d9764a037f71d935a32749923d2b1c4086ef11c  src/phase2/useful_elements.js
7a8866a5c0308b0abf554d6a02604483b9ec956ef3d527d0da571eeddd3343cc  src/phase2/symbolic_stars.js
aa9251f2e6d7ffe8107a3b8f2daccce4e9dbc26d87209d70fa83d0cd800dd08b  src/phase2/twelve_stars.js
```

## Test-environment dependency note

The build environment did not contain the npm dependency directory. The regression run therefore used the same temporary API-compatible `korean-lunar-calendar@0.4.0` lunar-test fixture used in earlier build validation. The temporary `node_modules` directory is removed before packaging. Production deployment runs `npm install` and remains pinned to `korean-lunar-calendar@0.4.0`.
