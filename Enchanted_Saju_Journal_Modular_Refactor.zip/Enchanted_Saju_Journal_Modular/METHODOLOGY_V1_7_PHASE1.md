> **Historical Phase 1 document.** Superseded by v1.7 Complete and the offline lunar hotfix. For current setup and methodology, use `BEGINNER_UPDATE_V1_7_COMPLETE.md` and `METHODOLOGY_V1_7_COMPLETE.md`.

# Enchanted Saju Journal v1.7 — Phase 1 Methodology

Phase 1 activates **only** four previously pending deterministic modules:

1. Lunar birth-date conversion
2. Weighted Five Element Strength
3. Weighted Ten God Distribution
4. Chart Strength

Useful/Favourable/Unfavourable Element, Symbolic Stars and Twelve Stars remain intentionally **Methodology Pending** for Phase 2.

The existing calculation order remains:

`Input → Normalise → Calculate → Validate → Derive → Interpret`

Workers AI is not used by any of the four Phase 1 calculation modules.

---

## 1. Lunar birth-date conversion — `korean-lunar-calendar-0.4.0-kari-offline-v1`

### Source and service

The implementation uses the Korean Astronomy and Space Science Institute (KASI) lunar/solar calendar service available through Korea's Public Data Portal, `LrsrCldInfoService`.

Official references:

- https://astro.kasi.re.kr/life/pageView/31
- https://www.data.go.kr/data/15012679/openapi.do

The service exposes lunar/solar calendar data including the distinction between an ordinary lunar month (`평`) and an intercalary/leap lunar month (`윤`).

### Required input

For Lunar input the user must provide:

- lunar year;
- lunar month;
- lunar day;
- leap-month status: ordinary or leap.

The application never infers leap-month status.

### Pipeline

1. Validate the supplied lunar date against the module's guarded support range.
2. Send year/month/day to KASI `getSolCalInfo`.
3. Parse all returned records.
4. Select the record whose `lunLeapmonth` explicitly matches the user's ordinary/leap choice.
5. Require **exactly one** matching record.
6. Store the original lunar input and returned Gregorian date separately.
7. Pass the returned Gregorian date into the unchanged v1.6.2 Four Pillars engine.

If conversion is ambiguous, unavailable or outside the supported range, calculation stops. It does not approximate a date.

### Stored audit fields

```json
{
  "original_calendar_type": "Lunar",
  "original_birth_date": "2020-04-01",
  "lunar_year": 2020,
  "lunar_month": 4,
  "lunar_day": 1,
  "lunar_leap_month": true,
  "normalised_gregorian_date": "2020-05-23",
  "conversion_method": "korean-lunar-calendar-0.4.0-kari-offline-v1",
  "conversion_version": "1"
}
```

The KASI service key is stored as the Cloudflare secret `KASI_SERVICE_KEY`. It is never placed in the browser HTML.

---

## 2. Weighted Five Element Strength — `transparent-hidden-stem-equal-allocation-v1`

This is an **application-defined transparent structural weighting method**. It is not claimed to reproduce ForceTeller's proprietary weighting formula or to be a universal classical Saju-school formula.

### Raw Element Presence is preserved

The existing raw element calculation is unchanged and remains separately available.

Phase 1 does **not** relabel raw counts as weighted strength.

### Weighted contributor formula

For each available pillar:

- visible Heavenly Stem: base weight `1.0`;
- Earthly Branch: total base weight `1.0`.

If **Hidden Stem allocation is OFF**:

- the branch's full `1.0` goes to its encoded main qi / Main Hidden Stem.

If **Hidden Stem allocation is ON**:

- the branch's total `1.0` is divided equally across all encoded Hidden Stems.

Examples:

- one Hidden Stem → `1.0`;
- two Hidden Stems → `0.5 + 0.5`;
- three Hidden Stems → `1/3 + 1/3 + 1/3`.

The equal split is deliberately neutral. The supplied source material establishes that Hidden Stems matter but does not provide a reliable numeric Main/Middle/Residual weighting table. Phase 1 therefore does not invent unequal percentages.

### Seasonal weighting

The supplied workbook states that the **Month Branch is considerably more important** in a full strength reading, but it does not give a reproducible numerical coefficient. Therefore Phase 1 does **not** invent a seasonal multiplier such as ×2.

The `seasonal_adjustment` setting remains stored for compatibility but is inactive in Weighted Five Elements. Month Branch importance is used only where the supplied workbook gives an explicit decision rule: the borderline Chart Strength method below.

### Also inactive in Phase 1

- palace/position numerical weighting;
- combination-induced elemental transformation.

These settings are visible/auditable but cannot alter scores until a separately validated algorithm exists.

### Result formula

For element `E`:

`weighted_score(E) = Σ final_weight of contributors whose element = E`

`percentage(E) = weighted_score(E) / total_weight × 100`

Every contributor stores:

```json
{
  "source": "Hidden Stem",
  "pillar": "month",
  "hidden_role": "Middle",
  "stem": "丙",
  "element": "Fire",
  "base_weight": 0.333333333333,
  "modifier": 1,
  "final_weight": 0.333333333333,
  "reason": "..."
}
```

The score can be reconstructed by summing the component list.

---

## 3. Weighted Ten God Distribution — `transparent-hidden-stem-equal-allocation-v1`

Weighted Ten Gods reuse **the same contributor list and final weights** as Weighted Five Elements.

For each contributor:

1. resolve its Heavenly Stem;
2. calculate its Ten God relative to the natal Day Master using the existing deterministic element + polarity rule;
3. add the contributor's final weight to that Ten God;
4. normalise all ten scores to percentages.

For Ten God `G`:

`weighted_score(G) = Σ final_weight of contributors mapped to G`

`percentage(G) = weighted_score(G) / total_weight × 100`

Raw Ten God occurrences remain a separate layer. Each weighted row stores its contributing stems and weights.

---

## 4. Chart Strength — `workbook-support-drain-monthbranch-v1`

This method follows the supplied **Korean Saju Workbook**, pp. 58–59.

The workbook instructs the reader to count all eight visible characters and group them into five roles relative to the Day Master:

- Companion — same element;
- Resource — element that generates the Day Master;
- Output — element generated by the Day Master;
- Wealth — element controlled by the Day Master;
- Authority — element that controls the Day Master.

Then:

`Support = Companion + Resource`

`Drain = Output + Wealth + Authority`

### Clear cases

- if `Support − Drain > 2` → **Strong**;
- if `Drain − Support > 2` → **Weak**.

### Borderline cases

The workbook specifically identifies `4/4` and `5/3` either way as genuinely borderline and says the **Month Branch decides**.

Therefore when:

`abs(Support − Drain) <= 2`

Phase 1 examines the Month Branch main qi:

- Companion or Resource → Support → **Strong**;
- Output, Wealth or Authority → Drain → **Weak**.

The result is also marked `borderline: true` / `provisional: true` so the user can see that this was a Month-Branch-decided case.

### Numeric internal score

`score = Support / 8`

`Strength Index = score × 100`

This score is an auditable support share. It is **not** claimed to be ForceTeller's proprietary population-based strength index.

### Categories

Only **Strong** and **Weak** are asserted in Phase 1 because those are the classifications justified by the selected source. The application does not manufacture Very Weak / Balanced-Weak / Very Strong categories without a sourced threshold system.

If the Hour Pillar is unavailable, this eight-character method returns **unavailable** rather than pretending a seven-character chart is equivalent.

---

## 5. Central method registry

Active Phase 1 IDs:

```json
{
  "lunar_conversion": "korean-lunar-calendar-0.4.0-kari-offline-v1",
  "weighted_elements": "transparent-hidden-stem-equal-allocation-v1",
  "ten_god_weighting": "transparent-hidden-stem-equal-allocation-v1",
  "chart_strength": "workbook-support-drain-monthbranch-v1"
}
```

Still pending:

```json
{
  "useful_element": null,
  "symbolic_stars": null,
  "twelve_stars": null
}
```

---

## 6. Notion storage

No new large property set is created. Existing searchable `Charts` properties are used:

- `Chart Strength`
- `Strength Index`
- `Strength Method`

The complete Phase 1 calculations, contributors, methods and settings are stored inside:

- `Technical Result JSON`
- `Calculation Audit JSON`

Older chart revisions remain readable.
