# Enchanted Saju Journal v1.7 Complete — Methodology

This release preserves every certified Phase 1 method and activates the Phase 2 modules only where a reproducible rule set is available.

The calculation boundary remains:

`Input → Normalise → Calculate → Validate → Derive → Interpret`

Workers AI is **not** used by Lunar conversion, weighted Five Elements, weighted Ten Gods, Chart Strength, Useful/Favourable/Unfavourable Elements, Symbolic Stars or Twelve Stars. AI may explain already-calculated values only as locked input.

---

## Preserved Phase 1 methods

| Module | Method ID |
|---|---|
| Lunar conversion | `korean-lunar-calendar-0.4.0-kari-offline-v1` |
| Weighted Five Elements | `transparent-hidden-stem-equal-allocation-v1` |
| Weighted Ten Gods | `transparent-hidden-stem-equal-allocation-v1` |
| Chart Strength | `workbook-support-drain-monthbranch-v1` |

These identifiers and Phase 1 source files are regression-hash guarded in Phase 2.

### Lunar conversion

The application continues to use the pinned `korean-lunar-calendar` 0.4.0 adapter introduced by the v1.7.1 offline hotfix. Lunar input explicitly records ordinary vs leap month and is normalised to Gregorian before the unchanged Four Pillars engine runs.

### Weighted analysis

The Phase 1 weighted method remains unchanged: each visible Heavenly Stem contributes weight 1; each Earthly Branch contributes total weight 1; with Hidden Stem allocation enabled, that branch weight is divided equally over its encoded Hidden Stems. Raw counts remain separate.

### Chart Strength

The supplied *Korean Saju Workbook*, pp. 58–59, defines the five roles and the simplified support/drain method:

- Support = Companion + Resource
- Drain = Output + Wealth + Authority
- clear cases are Strong or Weak according to Support vs Drain;
- 4/4 and 5/3-style borderline cases are decided by the Month Branch main qi.

No additional Phase 2 strength coefficient is introduced.

---

# Phase 2

## 1. Useful Element / 용신 · 用神

**Method ID:** `workbook-useful-god-simplified-v1`

**Primary supplied source:** *Korean Saju Workbook*, pp. 59–62.

This method deliberately follows the workbook's simplified Useful God procedure. It is not presented as a universal 용신 methodology and is not claimed to reproduce ForceTeller's undocumented Useful Element algorithm.

### Inputs

The module consumes deterministic Phase 1 data:

- Day Master element;
- Chart Strength classification;
- Support and Drain scores;
- Companion / Resource / Output / Wealth / Authority counts;
- Month Branch tiebreak status for borderline strength cases.

It does **not** select the least common element, the missing element, or an opposite element by frequency.

### Weak Day Master

Default:

`Useful Element role = Companion`

Therefore the Useful Element is the Day Master's own element.

Workbook exception: when Output is clearly the dominant drain, Resource is used instead. The workbook describes this as Output occupying three or four of the eight visible characters. To make “clearly dominant” reproducible, v1.7 Complete operationalises the condition as:

`Output >= 3 AND Output > Wealth AND Output > Authority`

When true:

`Useful Element role = Resource`

This operationalisation is stored in `reasoning_data` and is version-specific rather than hidden.

### Strong Day Master

Compare Resource and Companion counts:

- Resource > Companion → Useful role = Wealth
- Companion > Resource → Useful role = Authority
- Resource = Companion → Useful role = Output

The corresponding Five Element is resolved from the Day Master's generating/controlling relationships.

### Confidence

A chart whose Phase 1 strength was decided by the Month Branch borderline rule is marked:

`confidence: "provisional"`

A clear Phase 1 strength case is marked:

`confidence: "method-consistent"`

This is methodological confidence inside the selected simplified rule, not a statistical probability.

---

## 2. Favourable Element / 희신 · 喜神

**Method ID:** `workbook-useful-god-simplified-v1`

The supplied workbook, p. 62, gives the derivation:

`Favourable Element = element that generates the Useful Element`

The app stores the Useful Element and the generating-cycle derivation separately in `factors`.

---

## 3. Unfavourable Element / 기신 · 忌神

**Method ID:** `workbook-useful-god-simplified-v1`

The supplied workbook, p. 62, gives the derivation:

`Unfavourable Element = element that controls the Useful Element`

The result schema uses an array so a future methodology that legitimately returns multiple unfavourable elements can be added without changing the schema. This method returns one.

---

## 4. Symbolic Stars / 신살

**Overall method ID:** `symbolic-stars-four-rule-set-v1`

Symbolic Stars are not treated as one universally agreed system. v1.7 Complete enables **only four separately versioned rule tables**. Names that appear elsewhere in the UI or research database do not become calculated stars unless a deterministic trigger table is registered and tested.

### Enabled rule 1 — Peach Blossom / 도화살 · 桃花煞

**Rule version:** `peach-blossom-year-day-trine-v1`

Reference basis: natal Year Branch and natal Day Branch. Find the reference branch's 삼합 group and detect the group's target branch in any natal pillar.

| Reference 삼합 | Target |
|---|---|
| 申子辰 | 酉 |
| 寅午戌 | 卯 |
| 巳酉丑 | 午 |
| 亥卯未 | 子 |

### Enabled rule 2 — Travelling Horse / 역마살 · 驛馬煞

**Rule version:** `travelling-horse-year-day-trine-v1`

| Reference 삼합 | Target |
|---|---|
| 申子辰 | 寅 |
| 寅午戌 | 申 |
| 巳酉丑 | 亥 |
| 亥卯未 | 巳 |

### Enabled rule 3 — Flower Canopy / 화개살 · 華蓋煞

**Rule version:** `flower-canopy-year-day-trine-v1`

| Reference 삼합 | Target |
|---|---|
| 申子辰 | 辰 |
| 寅午戌 | 戌 |
| 巳酉丑 | 丑 |
| 亥卯未 | 未 |

### Enabled rule 4 — Heavenly Nobleman / 천을귀인 · 天乙貴人

**Rule version:** `heavenly-nobleman-day-stem-v1`

Reference basis: natal Day Stem. Detect either target branch in any natal pillar.

| Day Stem | Target Branches |
|---|---|
| 甲 · 戊 · 庚 | 丑 · 未 |
| 乙 · 己 | 子 · 申 |
| 丙 · 丁 | 亥 · 酉 |
| 壬 · 癸 | 卯 · 巳 |
| 辛 | 寅 · 午 |

This is a selected Korean/common table. Alternate classical assignments exist, especially around some stem groupings; they are not blended into this version.

### Structured star record

Each detection stores:

- English name;
- Korean;
- Hanja;
- trigger text;
- reference pillar/value;
- detected pillar positions;
- rule version;
- a restrained traditional-interpretation note.

Traditional interpretations are displayed separately from trigger calculation and use non-deterministic wording.

### Not enabled in v1.7 Complete

The following remain research/glossary concepts only unless a separate rule table is later validated: Heavenly Virtue, Monthly Virtue, Academic Hall, Literary Star, Red Charm, Solitary Star, Widow Star, White Tiger, Needle Star, Yang Blade, and other 신살.

Useful public cross-check references used to document the selected fixed tables include Saju rule encyclopaedia/calculator pages for 삼합-based Peach Blossom, Travelling Horse and Flower Canopy and the common Day-Stem Heavenly Nobleman table. These are compatibility/method documentation sources, not proof that every Saju school agrees.

---

## 5. Twelve Stars / 십이신살

**Method ID:** `year-branch-trine-12sinsal-v1`

This module is completely separate from **Twelve Growth Stages / 십이운성**. It uses a different result object (`twelve_stars`) and never reads or writes `growth_stages`.

### Selected reference convention

Some practitioners use the Year Branch, some the Day Branch, and some inspect both. v1.7 Complete explicitly selects:

`Reference basis = Natal Year Branch only`

The Year Branch chooses its 삼합 group. The sequence then maps clockwise over the twelve branches:

1. Robbery Star · 겁살 · 劫煞
2. Disaster Star · 재살 · 災煞
3. Heavenly Star · 천살 · 天煞
4. Earth Star · 지살 · 地煞
5. Year Star · 년살 · 年煞
6. Month Star · 월살 · 月煞
7. Loss of Reputation Star · 망신살 · 亡身煞
8. General Star · 장성살 · 將星煞
9. Saddle Star · 반안살 · 攀鞍煞
10. Travelling Horse · 역마살 · 驛馬煞
11. Six Harm Star · 육해살 · 六害煞
12. Flower Canopy · 화개살 · 華蓋煞

### Starting branch by 삼합 group

| Natal Year-Branch 삼합 | 겁살 starting branch |
|---|---|
| 申子辰 | 巳 |
| 寅午戌 | 亥 |
| 巳酉丑 | 寅 |
| 亥卯未 | 申 |

The supplied ForceTeller reference fixture with natal Year Branch 午 is retained as a compatibility regression fixture:

- Hour 亥 → 겁살
- Day 寅 → 지살
- Month 辰 → 월살
- Year 午 → 장성살

A match on this fixture does **not** certify complete ForceTeller methodology equivalence.

---

# Result schema

v1.7 Complete uses schema `2.2.0-complete` and retains every Phase 1 field. New deterministic sections are:

```json
{
  "useful_element": {
    "result": {},
    "method": "workbook-useful-god-simplified-v1",
    "factors": []
  },
  "favourable_element": {
    "result": {},
    "method": "workbook-useful-god-simplified-v1",
    "factors": []
  },
  "unfavourable_element": {
    "result": [],
    "method": "workbook-useful-god-simplified-v1",
    "factors": []
  },
  "symbolic_stars": {
    "method": "symbolic-stars-four-rule-set-v1",
    "enabled_rules": [],
    "detected": []
  },
  "twelve_stars": {
    "method": "year-branch-trine-12sinsal-v1",
    "pillars": {}
  }
}
```

# Notion storage

Searchable Chart fields use the already-existing properties:

- Useful Element
- Favourable Element
- Unfavourable Element
- Useful Element Method
- Symbolic Star Method

The full factors, trigger tables, detected stars, Twelve Stars results and method versions are retained in `Technical Result JSON` and `Calculation Audit JSON`, and a readable deterministic summary is appended to the Chart page body.

# AI boundary

Natal AI interpretation receives the full technical result as `locked_chart`. The system prompt explicitly forbids changing, replacing, inventing or removing Phase 2 outputs. Fields that are unavailable remain unavailable; AI cannot fill them in.

# Source notes

- **Supplied source:** *Korean Saju Workbook*, especially pp. 58–62, for Support/Drain and the simplified Useful/Favourable/Unfavourable God procedure.
- **Offline Lunar library:** `usingsky/korean_lunar_calendar_js`, package version 0.4.0. Its public README documents offline Korean lunar/solar conversion, leap-month validation, zero runtime dependencies and the supported range; the app retains the narrower certified range selected in Phase 1.
- **Supplied ForceTeller screenshots:** used only as compatibility fixtures where a displayed mapping is clear, never as proof of an undocumented algorithm.
- **Peach Blossom / Travelling Horse / Flower Canopy cross-check:** https://sajuprime.co.kr/knowledge/sinsal-meanings and https://sajuwon.kr/glossary/dohwasal document the 삼합-based placement convention; this release fixes the exact chosen table in its versioned rule registry.
- **Heavenly Nobleman cross-check:** https://paranbaram.tistory.com/39 gives the selected Day-Stem table (甲戊庚→丑未, 乙己→子申, 丙丁→亥酉, 辛→寅午, 壬癸→卯巳).
- **Twelve Stars cross-check:** https://www.sajugeori.com/dictionary/sipi-sinsal and https://www.durumisaju.com/stories/samhap document the twelve-name sequence, 삼합 starting positions and Year-Branch convention used here. Other sources also use a Day-Branch reference, which is why the method ID explicitly says `year-branch`.

Where sources or schools disagree, the selected convention is encoded in the method ID rather than silently blended.
