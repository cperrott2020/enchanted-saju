> **Historical Phase 1 document.** Superseded by v1.7 Complete and the offline lunar hotfix. For current setup and methodology, use `BEGINNER_UPDATE_V1_7_COMPLETE.md` and `METHODOLOGY_V1_7_COMPLETE.md`.

# Beginner Update — Enchanted Saju Journal v1.7 Phase 1

This is an **in-place update** to your existing Cloudflare Worker. It does not create a new Worker or replace your Notion workspace.

## 1. Update the existing app

1. Extract the v1.7 Phase 1 ZIP.
2. Open the extracted folder.
3. Double-click `update_existing_windows.bat`.
4. Wait for the full regression suite to finish.
5. Let Wrangler deploy to the same Worker.
6. Open the same `workers.dev` address.
7. Press **Ctrl + F5**.
8. Click **Test Notion connection**.

Your existing `NOTION_TOKEN`, private connection key, Workers AI binding, Daily Luck archive and Today page remain in place.

## 2. Optional one-time setup for Lunar input

Gregorian/Solar input works without any additional key.

To use **Lunar** birth input, obtain a free service key for the Korean Astronomy and Space Science Institute lunar/solar calendar API through Korea's Public Data Portal:

https://www.data.go.kr/data/15012679/openapi.do

Then double-click:

`configure_kasi_windows.bat`

Paste the service key when Wrangler asks for `KASI_SERVICE_KEY`.

macOS/Linux:

```bash
chmod +x configure_kasi_mac_linux.sh
./configure_kasi_mac_linux.sh
```

The key is stored as a Cloudflare secret and is not exposed in the HTML.

## 3. Lunar birth input

In Calculator → Birth information:

1. choose **Lunar**;
2. enter lunar year/month/day;
3. explicitly choose **Ordinary month · 평달** or **Leap month · 윤달**;
4. calculate normally.

The app converts the date first, then sends the verified Gregorian date through the same Four Pillars engine used by Gregorian input.

## 4. Weighted analysis

After calculation you will see:

- **Raw Element Presence** — unchanged;
- **Weighted Element Strength** — separate;
- **Raw Ten God Distribution** — unchanged;
- **Weighted Ten God Distribution** — separate;
- **Chart Strength** — deterministic workbook result.

Under Advanced → Phase 1 analysis settings, **Include Hidden Stem allocation** is active.

Seasonal numerical adjustment, palace weighting and combination transformation remain inactive because Phase 1 does not have a validated numerical formula for them.

## 5. Chart Strength

Phase 1 uses only the source-supported classifications:

- Strong
- Weak

Borderline 4/4 or 5/3 cases are visibly marked and decided by the Month Branch main qi, following the supplied workbook method.

## 6. Saving to Notion

`Save Verified Chart` now populates the existing:

- Chart Strength
- Strength Index
- Strength Method

properties, while the detailed calculations go into Technical Result JSON and Calculation Audit JSON.

No new large set of Notion properties is required.
