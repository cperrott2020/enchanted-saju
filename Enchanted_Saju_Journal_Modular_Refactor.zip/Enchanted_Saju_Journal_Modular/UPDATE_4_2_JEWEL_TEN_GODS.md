# Enchanted Saju — Update 4.2
## JewelSJPJ Ten Gods + *How to Read Your SJPJ* lesson captures

Update 4.2 continues from Update 4.1. It adds the supplied JewelSJPJ *How to Read Your SJPJ* lesson captures to the private Research source pack and makes JewelSJPJ's accessible Ten God labels the normal user-facing terminology.

## Preferred Ten God terminology

| Category | Korean / Hanja | Preferred JewelSJPJ label | Technical English retained as alias |
| --- | --- | --- | --- |
| Me | 비견 / 比肩 | Self God | Friend / Companion |
| Me | 겁재 / 劫財 | Rival God | Rob Wealth |
| Output | 식신 / 食神 | Creator God | Eating God |
| Output | 상관 / 傷官 | Rebel God | Hurting Officer |
| Wealth | 편재 / 偏財 | Entrepreneur God | Indirect Wealth |
| Wealth | 정재 / 正財 | Provider God | Direct Wealth |
| Authority | 편관 / 偏官 | Wild Card God | Seven Killings / Indirect Officer |
| Authority | 정관 / 正官 | Official God | Direct Officer |
| Input | 편인 / 偏印 | Mystic God | Indirect Resource |
| Input | 정인 / 正印 | Nurturer God | Direct Resource |

The preferred Jewel label appears first in ordinary screens and AI readings. Hangul, Hanja, romanisation and the application's previous technical English remain attached to the same canonical concept and remain searchable in the Glossary.

## New private source records

- `SRC-JEWEL-003` — **How to Read Your SJPJ — The Why Part 1**. The supplied captures preserve the Ten Gods chart context, selected Special Star animal groupings, the Five Element Help cycle and the Five Element Hurt/control relationship.
- `SRC-JEWEL-004` — **How to Read Your SJPJ — The Why Part 2**. The supplied captures preserve all five JewelSJPJ Ten God categories and the ten preferred God names above.

Capture boundaries are kept inside the indexed source text. The material is used for private retrieval, terminology and source-attributed interpretation; it is not exposed as a public reproduction of the course pages.

## Where the terminology changes

The preferred JewelSJPJ God names are now used first across Today, My Saju, Calendar, Journal, People, Comparison, Major Luck, Ten Gods views, Learn/Glossary and accessible AI-generated readings. Technical terminology is shown secondarily where useful and remains available in Advanced/technical context.

The calculation engine still computes the same underlying Ten God identity. This update changes **terminology and source context, not deterministic Saju calculation**.

## Import after deployment

Open **Research → Initial Knowledge Source Pack → Import / Resume Pack** after deploying Update 4.2.

Update 4.1's resume logic is preserved, so sources already marked **Ready** or **Needs Review** are skipped. The two new embedded JewelSJPJ lesson sources are imported without redoing your existing source records, and any still-missing Saju Atelier articles can continue through the throttled retry queue.
