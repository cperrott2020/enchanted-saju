# Enchanted Saju Update 3.1 — Save Hotfix

This package fixes the verified-chart save error caused by Update 3 structured JSON exceeding the old 150,000-character pretty-JSON safety limit.

Use `update_existing_windows.bat` to update the same Cloudflare Worker. No Notion schema changes, new tokens or new databases are required.

See:

- `HOTFIX_UPDATE_3_1.md`
- `TEST_REPORT_UPDATE_3_1.md`
- `UPDATE_3_1_BUILD_REPORT.json`
