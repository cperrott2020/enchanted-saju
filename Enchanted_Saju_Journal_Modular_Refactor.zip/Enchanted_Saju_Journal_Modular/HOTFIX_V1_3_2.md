# v1.3.2 AI visible-output hotfix

This fixes the remaining `Workers AI returned an unsupported response shape` failure seen with GLM-4.7-Flash.

## Cause

GLM-4.7-Flash is reasoning-capable. In some Workers AI responses, a reasoning model can spend the available completion budget on reasoning and return `message.content: null`. The v1.3.1 parser correctly rejected that because we must not copy model reasoning into the user's Daily Reading.

## Fix

The Worker now sends the reasoning controls directly to `env.AI.run()`:

- `reasoning_effort: null`
- `chat_template_kwargs.enable_thinking: false`
- `chat_template_kwargs.clear_thinking: true`

It also gives the model a slightly larger visible-output budget and accepts nested text-content blocks. If no visible answer is returned, the error reports only the response *shape* (keys/types), never hidden reasoning text.

## Data integrity

Unchanged: AI output is still written only to `Daily Reading`. Calculated Saju properties cannot be modified by the model.

## Update

Run `update_existing_windows.bat`, refresh the calculator, then use **Regenerate AI Daily Reading**.
