# Enchanted Saju Update 3.2 — Save Subrequest Hotfix

Use this build if saving a verified Chart shows:

`Too many subrequests by single Worker invocation.`

The save workflow is split into a small core save and a separate idempotent finalization request. No deterministic Saju method changed.

Windows: run `update_existing_windows.bat`, then hard-refresh the existing workers.dev page.
