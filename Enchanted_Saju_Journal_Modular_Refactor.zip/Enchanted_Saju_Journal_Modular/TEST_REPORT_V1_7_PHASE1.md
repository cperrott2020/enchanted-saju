> **Historical Phase 1 document.** Superseded by v1.7 Complete and the offline lunar hotfix. For current setup and methodology, use `BEGINNER_UPDATE_V1_7_COMPLETE.md` and `METHODOLOGY_V1_7_COMPLETE.md`.

# Enchanted Saju Journal v1.7 Phase 1 — Test Report

Build date: 2026-09-25

## Summary

**17 automated tests passed.**

The test suite includes every existing v1.6.2 regression test plus the four mandatory Phase 1 calculation tests and Phase 1 regression/front-end guards.

## Automated results

```text
daily_engine_test: PASS
ai_daily_test: PASS
journal_layout_test: PASS
today_dashboard_test: PASS
method_registry_test: PASS
luck_explorer_test: PASS
result_schema_test: PASS
frontend_contract_test: PASS
notion_target_hotfix_test: PASS
month_boundary_display_test: PASS
lunar_conversion_test: PASS
weighted_elements_test: PASS
weighted_ten_gods_test: PASS
chart_strength_test: PASS
phase1_regression_guard_test: PASS
phase1_frontend_test: PASS
gregorian_engine_guard_test: PASS
```

## Mandatory Phase 1 tests

- `lunar_conversion_test.mjs` — ordinary lunar conversion, explicit leap-month selection, unsupported range, missing-key failure.
- `weighted_elements_test.mjs` — raw layer unchanged, deterministic weighted output, 100% total, active Hidden Stem setting changes output, inactive seasonal switch cannot silently change output.
- `weighted_ten_gods_test.mjs` — same weighted contributor system, reproducibility, raw counts retained, percentages total 100%.
- `chart_strength_test.mjs` — eight-character requirement, Support/Drain totals, source-supported Strong/Weak classification, Month Branch borderline decision.

## Required invariants

| Invariant | Result |
|---|---|
| Known Lunar → Gregorian fixture | PASS |
| Leap-month ordinary vs leap selection | PASS |
| Gregorian Four Pillars calculation body unchanged from v1.6.2 | PASS |
| Raw element counts unchanged | PASS |
| Weighted results deterministic between runs | PASS |
| Active Hidden Stem setting causes documented deterministic difference | PASS |
| Weighted Ten God percentages total 100% | PASS |
| Strength uses only source-supported thresholds/rules | PASS |
| No Phase 1 deterministic module calls Workers AI | PASS |
| Daily Luck engine unchanged | PASS |
| Today/journal/AI core modules unchanged | PASS |

## Protected v1.6.2 module hashes

- `src/daily_engine.js` — **UNCHANGED** — `efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785`
- `src/ai_daily.js` — **UNCHANGED** — `c6791b165107bd6419b5d4a1f61aa661bf6e5e49199bc6c2f81e319d99a33083`
- `src/journal_layout.js` — **UNCHANGED** — `a846d78cf82651d1361180b64de859d9ce64f151b213455f3d0bc8f061ad1a90`
- `src/luck_explorer.js` — **UNCHANGED** — `77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0`
- `src/solar_terms.js` — **UNCHANGED** — `8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb`

## Browser/static validation

- HTML IDs: 118 total / 118 unique / duplicates: none
- Inline browser JavaScript syntax: PASS
- Worker/Phase 1 module syntax: PASS

## External-service note

The lunar parser and conversion request path are tested with deterministic KASI-shaped XML fixtures, including a leap-month case. A offline conversion requires no live KASI request. After deployment, run `configure_kasi_windows.bat` (or the macOS/Linux equivalent) and perform one live Lunar conversion as the deployment smoke test.

## Phase 2 guard

Useful Element, Favourable Element, Unfavourable Element, Symbolic Stars and Twelve Stars remain Methodology Pending and were not activated.
