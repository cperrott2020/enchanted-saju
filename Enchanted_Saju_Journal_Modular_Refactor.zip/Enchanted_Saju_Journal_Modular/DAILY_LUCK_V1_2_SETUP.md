# Enchanted Saju Journal v1.2 — Daily Luck setup

This update adds the **deterministic Daily cycle endpoint** and **automatic Daily Luck generation** to the Cloudflare Worker you already connected to Notion.

You do **not** need a new Cloudflare Worker, Notion token, or private connection key.

## What is already prepared

Your Notion **Daily Luck** database has been extended with three technical properties:

- `Year Pillar`
- `Month Pillar`
- `Calculation Version`

The automation never overwrites your personal fields such as Journal, Mood, Energy, Productivity, Events, Retrospective, or Daily Reading.

---

## Step 1 — Give the Notion integration access to Daily Luck

In Notion open the **original** database:

`My Saju Journal → System & Data → Daily Luck`

Open the database menu (`•••`) → **Connections** → add:

**Saju Cloudflare Bridge**

If it is already connected, leave it as-is.

---

## Step 2 — Update the existing Cloudflare app

### Windows

1. Extract the v1.2 ZIP.
2. Open the extracted folder.
3. Double-click:

`update_existing_windows.bat`

The script:

- installs/updates Wrangler;
- runs the Daily engine test;
- deploys v1.2 to the **same** Worker;
- preserves your existing Cloudflare secrets.

### Mac/Linux

Run:

```bash
./update_existing_mac_linux.sh
```

---

## Step 3 — Refresh the calculator

Open the same `workers.dev` URL you already use.

On Windows press:

`Ctrl + F5`

You should now see a new section:

**05 · Daily Luck Automation**

---

## Step 4 — Test the Notion connection again

Click **Test Notion connection**.

The v1.2 connection test now also checks access to the **Daily Luck** database.

If the error says it cannot see `Daily Luck`, open the original Daily Luck database in Notion and add the **Saju Cloudflare Bridge** connection.

---

## Step 5 — Preview today's deterministic cycle

In **05 · Daily Luck Automation**:

1. Choose today's date.
2. Keep the timezone as `Asia/Seoul` for Korea.
3. Click **Preview Daily Cycle**.

This does **not** write anything to Notion.

It reads your Person marked **Me**, follows that Person's **Primary Chart**, and calculates:

- Daily stem and branch;
- Daily animal and element;
- Daily Ten God relative to your natal Day Master;
- Saju year pillar;
- solar-term month pillar;
- current Major Luck cycle from your stored records;
- configured daily-to-natal combinations, clashes, punishments, harms, and breaks;
- solar-term boundary warnings.

AI is not involved in these calculations.

---

## Step 6 — Generate the Daily Luck record

Click:

**Generate / Update Daily Luck**

The Worker will:

1. calculate the daily context;
2. create/reuse the correct **Annual** Luck Cycle record;
3. create/reuse the correct **Monthly** Luck Cycle record;
4. find the active **Major Luck** record;
5. find the Daily Luck record for that date;
6. create it if missing, or update it if it already exists.

This duplicate protection means repeatedly clicking the button for the same date should **update the existing day rather than create another one**.

The Daily Luck record receives:

- Date;
- Day Stem;
- Day Branch;
- Animal;
- Element;
- Yin/Yang;
- Ten God;
- Year Pillar;
- Month Pillar;
- natal interactions;
- Major Cycle relation;
- Annual Cycle relation;
- Monthly Cycle relation;
- Stem/Branch/Ten God glossary relations;
- Calculation Version.

`Reading Match` is initially set to `Not Reviewed` only when a new day is created.

---

## Step 7 — Automatic generation

`wrangler.toml` now includes:

```toml
[vars]
SAJU_DAILY_TIMEZONE = "Asia/Seoul"
SAJU_DAILY_ENABLED = "true"

[triggers]
crons = [ "0 * * * *" ]
```

Cloudflare wakes the Worker once per hour. The Worker checks the configured timezone and only performs Daily Luck generation when the local hour is midnight.

So with:

`SAJU_DAILY_TIMEZONE = "Asia/Seoul"`

the Daily Luck record is generated automatically just after the Korean calendar date changes.

### If you later want Ireland

Change:

```toml
SAJU_DAILY_TIMEZONE = "Europe/Dublin"
```

and run the update script again. Because the Worker checks local time internally, daylight-saving changes are handled by the IANA timezone rather than by manually changing the cron expression.

---

## API endpoints now available

### Preview calculation only

`GET /api/daily/calculate?date=YYYY-MM-DD&timezone=Asia/Seoul`

Requires your `X-Saju-Key` header.

### Generate/update Notion record

`POST /api/daily/generate`

Body:

```json
{
  "date": "2026-09-25",
  "timezone": "Asia/Seoul"
}
```

If date/timezone are omitted, the Worker uses the configured Daily timezone and current local date.

---

## Calculation convention used for one Daily Luck record

A Daily Luck database row represents one local calendar day. For the **year and solar month** context, v1.2 evaluates the day at **12:00 local time** and separately flags days on which a solar-term boundary occurs.

This avoids silently treating a solar-term transition day as unambiguous.

The sexagenary Daily Pillar itself uses the same JDN day anchor as the natal calculator.

---

## Not included yet

v1.2 deliberately does **not** generate AI interpretation yet.

The next layer can read the deterministic record that v1.2 creates and populate **Daily Reading** without being allowed to change any calculated stem, branch, Ten God, cycle, or interaction.
