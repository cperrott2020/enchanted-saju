# Enchanted Saju — Update 3 Changelog

## People

- Rebuilt People as a saved-profile/chart library rather than a settings-only list.
- Added profile cards showing category, Default Profile status, Day Master, Day Branch/animal and birth summary.
- Added category filters: All, Me, Partner, Family, Friends and Other.
- Added quick actions: View Saju, Compare, Edit and More.
- `View Saju` reuses the person's saved Primary Chart and opens My Saju; it never creates a duplicate chart-viewing screen.

## Compare Charts

- Added a dedicated two-profile Compare Charts page.
- Added side-by-side saved Four Pillars.
- Added deterministic Day Master element relation.
- Added cross-chart Heavenly Stem and Earthly Branch interactions using the existing relationship engine.
- Added a dedicated Day Branch section.
- Added cross-chart Ten God views relative to the other person's Day Master.
- Added clickable structural interaction cards and evidence/details.
- No compatibility percentage, ranking, “good match” or “bad match” result is calculated.

## Learn

- Expanded Learn into Foundations, Chart Structure, Relationships, Time and Reference.
- Saju Concepts remain the controlled knowledge vocabulary.
- Concept entries now connect to:
  - the Active Profile's saved chart;
  - all saved charts containing the concept;
  - relevant journal days;
  - linked Research Sources;
  - linked Research Notes;
  - related concepts;
  - My Notes.
- Added chart-aware concept presence rather than generic personalisation.

## Research

- Research now has a Library and a retained Research Inbox/Add Source workflow.
- Source detail visibly separates Original Source, Bibliographic Information, AI Summary and My Notes.
- Added author/teacher, publication date and pages to the ingestion/save workflow.
- Preserved extracted source material instead of treating the AI summary as the source.
- Existing controlled Saju Concept relations and conflicting-source flags remain intact.

## Provenance

The interface now distinguishes:

1. Calculated Fact
2. Traditional / Source-Based Interpretation
3. AI Synthesis
4. Personal Observation / My Notes

Source buttons open the underlying Research Source rather than collapsing source material and AI prose together.

## Personal Notes

- Added My Notes using the existing Research Notes database.
- Notes can be attached to Concept, 60 Jiazi, Chart and Relationship subject keys.
- User notes leave `Source-derived Content` and `AI Summary` blank, so they cannot masquerade as source evidence or AI output.

## Calculation Inspector

- Added a readable Year Pillar explanation using birth UTC and exact Ipchun.
- Added Saju-year stem/branch formula display.
- Added Month Pillar sectional-term boundaries and the exact month stem/branch formula used by the engine.
- Added Day/Hour/timezone explanation.
- Raw Technical Result / Calculation Audit remains available under Settings → Calculation Inspector → Advanced Audit.

## Visual system

- Continued dusty pink, cream, sage/moss and warm brown styling.
- Added restrained botanical/almanac styling to profile cards and zodiac medallions.
- Kept technical and audit pages calmer than personal/library pages.

## Engine preservation

Update 3 does not modify:

- Daily engine
- solar-term engine
- luck explorer
- Daily AI boundary
- journal layout
- Phase 1 lunar/weighted/strength modules
- Phase 2 Useful Elements/Symbolic Stars/Twelve Stars
- master result schema or method registry

A regression-hash test verifies these files against the Update 2 baseline.
