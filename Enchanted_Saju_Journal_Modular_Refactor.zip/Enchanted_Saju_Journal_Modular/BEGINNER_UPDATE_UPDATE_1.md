# Beginner Update Guide — Enchanted Saju Update 1

Update 1 deploys to the **same Cloudflare Worker** and uses your existing Notion workspace.

## Update on Windows

1. Extract the Update 1 ZIP.
2. Open the extracted folder.
3. Double-click `update_existing_windows.bat`.
4. The updater installs dependencies, runs the full regression suite and deploys only if the tests pass.
5. Open your existing `workers.dev` address.
6. Press **Ctrl + F5**.
7. Open **Settings & Audit** and click **Test Notion connection**.

You do not need a new Notion token, save key, Cloudflare Worker or Notion database.

## First use

Open **People** and choose the profile you normally want the app to use. Click:

`☆ Set as Default Profile`

It becomes:

`★ Default Profile`

Only one saved person can be the default.

Then open **My Saju**. The Default Profile loads automatically. Use the `Viewing` dropdown to switch instantly to another saved chart without recalculating it.

The same Active Profile follows you through:

- Today
- My Saju
- Calendar
- Journal

The last selection is remembered on your device.

## Important data behaviour

Daily Luck and Journal records are associated with the selected profile's unique Notion Person ID and saved Chart ID. Two people can therefore have records for the same date without one overwriting the other.

The main Notion Today page is one live dashboard. A manual refresh can show the currently selected Active Profile. The scheduled midnight generation resolves the profile marked `Default Profile`.

## New Chart

The ordinary form now focuses on Name, Birth Date, Birth Time, Birth Time Accuracy, Birth Place and Calendar. Technical settings remain available under **Advanced Calculation Options**.

After verifying a chart, choose its Profile Category and optionally tick **Set as Default Profile** before saving.
