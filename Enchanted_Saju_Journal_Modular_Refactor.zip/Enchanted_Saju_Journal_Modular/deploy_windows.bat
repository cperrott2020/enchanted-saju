@echo off
setlocal
cd /d "%~dp0"

echo =============================================================
echo   ENCHANTED SAJU - NEW SETUP WITH UPDATE 3
echo =============================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install the LTS version from https://nodejs.org/ then run this file again.
  pause
  exit /b 1
)

call npm install
if errorlevel 1 goto :error
call npm test
if errorlevel 1 goto :error
call npx wrangler login
if errorlevel 1 goto :error

echo Paste your Notion integration token when prompted:
call npx wrangler secret put NOTION_TOKEN
if errorlevel 1 goto :error

echo Choose and enter a long PRIVATE CONNECTION KEY:
call npx wrangler secret put SAJU_SAVE_KEY
if errorlevel 1 goto :error

call npx wrangler deploy
if errorlevel 1 goto :error

echo.
echo DONE. Open the workers.dev address printed above.
echo Lunar conversion is offline and needs no KASI key.
pause
exit /b 0

:error
echo.
echo Setup stopped. Copy the last error and send it to ChatGPT.
pause
exit /b 1
