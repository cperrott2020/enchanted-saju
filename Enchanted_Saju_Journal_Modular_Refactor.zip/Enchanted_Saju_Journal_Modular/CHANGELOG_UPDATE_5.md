# Enchanted Saju — Update 5 Changelog

## Global visual system

- Added the enchanted botanical / fairy-journal design token system.
- Added sage, moss, dusty pink, warm cream, parchment, mushroom brown, lilac, periwinkle, moon-blue and antique-gold palette variables.
- Added layered storybook/display, decorative-accent and readable UI typography roles.
- Reworked desktop navigation into a personal-journal / old-web directory while retaining responsive mobile navigation.
- Added subtle paper/grain, botanical, celestial and scrapbook treatments.
- Added `prefers-reduced-motion` support and stronger focus states.

## Original ornament system

Added original vector assets:

- fairy ring / cyclical spiral
- botanical corner
- lace strip
- pressed flower
- star divider

The user's mood-board images are not redistributed or embedded in the application.

## 60 SJPJ / Jiazi visual system

- Added 60 permanent art folders under `public/assets/sjpj-types/`.
- Added 60 emblem SVGs and 60 profile/reference-card SVGs.
- Added an asset manifest containing SJPJ name, Hanja, Korean, romanisation, element, polarity, animal and asset paths.
- Art is modular: five element families × twelve branch animals × Yin/Yang visual distinction.
- Added a collectible 60-type cabinet with lazy-loaded thumbnails.
- Added type art to Today, My Saju, People, Compare and 60-Jiazi Learn entries.
- Added explicit UI wording that decorative SJPJ art is calculation-neutral and is not itself traditional doctrine.

## Page redesigns

- **Today:** daily enchanted-almanac hero with SJPJ type emblem and fairy-ring cycle motif.
- **My Saju:** illustrated personal field-guide hero; Four Pillars styled as explicit reference/oracle cards without hiding factual values.
- **Calendar:** postage/almanac cells, compact animal marks and softer element/god markers.
- **Journal:** notebook lines, paper fragments, labels and scrapbook cards.
- **Timeline:** winding-path / cycle-ring visual treatment while calculated cycles and personal events remain separate layers.
- **People:** collectible botanical profile-shrine cards with SJPJ art and compact Four Pillars strips.
- **Compare:** mirrored type cards and orbit styling; still no compatibility percentages or rankings.
- **Learn:** field-guide/encyclopaedia styling plus SJPJ art for 60-Jiazi concepts.
- **Research:** scholar's-scrapbook styling while original source, AI summary, metadata and user notes remain visually separate.
- **Settings & Audit:** deliberately restrained technical variant.

## Functionality preserved / repaired

- Preserved Update 4.2 JewelSJPJ Ten God terminology and source behavior.
- Preserved Update 4.1 resumable source importer and Saju Atelier backoff/cooldown behavior.
- Preserved saved-profile editing, My Saju compare panel, natal AI interpretation, Learn group navigation, calendar/timeline/journal handlers and source provenance.
- Restored/guarded all inherited frontend contracts during the redesign.

## Calculation boundary

No files under `src/` were changed between Update 4.2 and Update 5. Deterministic chart calculation, lunar conversion, solar-term logic, Major Luck, weighted analysis, chart strength, Useful Element, Symbolic Stars, Twelve Stars, Daily Luck and research-calculation boundaries are therefore unchanged by this visual release.
