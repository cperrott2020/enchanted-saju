"use strict";
/* JewelSJPJ-facing terminology and decorative type metadata.
   Artwork files are exact copies of the supplied project assets. */
const SJPJ_AVATAR_ROOT='/assets/images/avatars';
const JEWEL_STEM_NAMES={'甲':'Blue Tree','乙':'Blue Vine','丙':'Red Sun','丁':'Red Moon','戊':'Yellow Mountain','己':'Yellow Garden','庚':'White Sword','辛':'White Jewel','壬':'Black Ocean','癸':'Black Mist'};
const JEWEL_TEN_GOD_TERMS={
'比肩':{name:'Self God',technical:'Friend / Companion',ko:'비견',roman:'Bi Gyeon',category:'Me',key:'friend'},
'劫財':{name:'Rival God',technical:'Rob Wealth',ko:'겁재',roman:'Geop Jae',category:'Me',key:'rob_wealth'},
'食神':{name:'Creator God',technical:'Eating God',ko:'식신',roman:'Sik Shin',category:'Output',key:'eating_god'},
'傷官':{name:'Rebel God',technical:'Hurting Officer',ko:'상관',roman:'Sang Gwan',category:'Output',key:'hurting_officer'},
'偏財':{name:'Entrepreneur God',technical:'Indirect Wealth',ko:'편재',roman:'Pyeon Jae',category:'Wealth',key:'indirect_wealth'},
'正財':{name:'Provider God',technical:'Direct Wealth',ko:'정재',roman:'Jeong Jae',category:'Wealth',key:'direct_wealth'},
'偏官':{name:'Wild Card God',technical:'Seven Killings / Indirect Officer',ko:'편관',roman:'Pyeon Gwan',category:'Authority',key:'seven_killings'},
'正官':{name:'Official God',technical:'Direct Officer',ko:'정관',roman:'Jeong Gwan',category:'Authority',key:'direct_officer'},
'偏印':{name:'Mystic God',technical:'Indirect Resource',ko:'편인',roman:'Pyeon In',category:'Input',key:'indirect_resource'},
'正印':{name:'Nurturer God',technical:'Direct Resource',ko:'정인',roman:'Jeong In',category:'Input',key:'direct_resource'}
};
const ELEMENT_ART_FAMILY={
  Wood:{motif:'vines · clover · ferns · dragonflies',palette:'sage · fern · cream · pink'},
  Fire:{motif:'little suns · sparks · glowing flowers · ribbons',palette:'dusty rose · antique gold · cream'},
  Earth:{motif:'moss · stones · cottages · roots · mushrooms',palette:'oat · mushroom · olive · pink'},
  Metal:{motif:'keys · bells · pearls · filigree · stars',palette:'cream · lilac · antique gold'},
  Water:{motif:'moon ponds · mist · ripples · droplets · lilies',palette:'moon blue · sage · lilac · cream'}
};
const BRANCH_ART_FAMILY={Rat:'lantern mouse',Ox:'pastoral ox',Tiger:'forest guardian tiger',Rabbit:'clover moon rabbit',Dragon:'pearl garden dragon',Snake:'vine moon snake',Horse:'meadow ribbon horse',Goat:'flowering hillside goat',Monkey:'curious garden monkey',Rooster:'dawn sun rooster',Dog:'hearth garden dog',Pig:'mushroom pond pig'};
