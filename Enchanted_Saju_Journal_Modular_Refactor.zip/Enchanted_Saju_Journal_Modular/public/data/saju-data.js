"use strict";
/* Stable Four Pillars reference tables and method identifiers. */
const STEMS = [
 {index:0,ko:'갑',hanja:'甲',roman:'Gap',element:'Wood',yin_yang:'Yang'},
 {index:1,ko:'을',hanja:'乙',roman:'Eul',element:'Wood',yin_yang:'Yin'},
 {index:2,ko:'병',hanja:'丙',roman:'Byeong',element:'Fire',yin_yang:'Yang'},
 {index:3,ko:'정',hanja:'丁',roman:'Jeong',element:'Fire',yin_yang:'Yin'},
 {index:4,ko:'무',hanja:'戊',roman:'Mu',element:'Earth',yin_yang:'Yang'},
 {index:5,ko:'기',hanja:'己',roman:'Gi',element:'Earth',yin_yang:'Yin'},
 {index:6,ko:'경',hanja:'庚',roman:'Gyeong',element:'Metal',yin_yang:'Yang'},
 {index:7,ko:'신',hanja:'辛',roman:'Sin',element:'Metal',yin_yang:'Yin'},
 {index:8,ko:'임',hanja:'壬',roman:'Im',element:'Water',yin_yang:'Yang'},
 {index:9,ko:'계',hanja:'癸',roman:'Gye',element:'Water',yin_yang:'Yin'}];
const BRANCHES = [
 {index:0,ko:'자',hanja:'子',roman:'Ja',animal:'Rat',element:'Water',yin_yang:'Yang',season:'Winter'},
 {index:1,ko:'축',hanja:'丑',roman:'Chuk',animal:'Ox',element:'Earth',yin_yang:'Yin',season:'Winter'},
 {index:2,ko:'인',hanja:'寅',roman:'In',animal:'Tiger',element:'Wood',yin_yang:'Yang',season:'Spring'},
 {index:3,ko:'묘',hanja:'卯',roman:'Myo',animal:'Rabbit',element:'Wood',yin_yang:'Yin',season:'Spring'},
 {index:4,ko:'진',hanja:'辰',roman:'Jin',animal:'Dragon',element:'Earth',yin_yang:'Yang',season:'Spring'},
 {index:5,ko:'사',hanja:'巳',roman:'Sa',animal:'Snake',element:'Fire',yin_yang:'Yin',season:'Summer'},
 {index:6,ko:'오',hanja:'午',roman:'O',animal:'Horse',element:'Fire',yin_yang:'Yang',season:'Summer'},
 {index:7,ko:'미',hanja:'未',roman:'Mi',animal:'Goat',element:'Earth',yin_yang:'Yin',season:'Summer'},
 {index:8,ko:'신',hanja:'申',roman:'Sin',animal:'Monkey',element:'Metal',yin_yang:'Yang',season:'Autumn'},
 {index:9,ko:'유',hanja:'酉',roman:'Yu',animal:'Rooster',element:'Metal',yin_yang:'Yin',season:'Autumn'},
 {index:10,ko:'술',hanja:'戌',roman:'Sul',animal:'Dog',element:'Earth',yin_yang:'Yang',season:'Autumn'},
 {index:11,ko:'해',hanja:'亥',roman:'Hae',animal:'Pig',element:'Water',yin_yang:'Yin',season:'Winter'}];
const HIDDEN_STEMS={0:[9],1:[5,9,7],2:[0,2,4],3:[1],4:[4,1,9],5:[2,4,6],6:[3,5],7:[5,3,1],8:[6,8,4],9:[7],10:[4,7,3],11:[8,0]};
const TEN_GODS={friend:{en:'Friend / Companion',ko:'비견',hanja:'比肩'},rob_wealth:{en:'Rob Wealth',ko:'겁재',hanja:'劫財'},eating_god:{en:'Eating God',ko:'식신',hanja:'食神'},hurting_officer:{en:'Hurting Officer',ko:'상관',hanja:'傷官'},indirect_wealth:{en:'Indirect Wealth',ko:'편재',hanja:'偏財'},direct_wealth:{en:'Direct Wealth',ko:'정재',hanja:'正財'},seven_killings:{en:'Seven Killings / Indirect Officer',ko:'편관',hanja:'偏官'},direct_officer:{en:'Direct Officer',ko:'정관',hanja:'正官'},indirect_resource:{en:'Indirect Resource',ko:'편인',hanja:'偏印'},direct_resource:{en:'Direct Resource',ko:'정인',hanja:'正印'}};
const GENERATES={Wood:'Fire',Fire:'Earth',Earth:'Metal',Metal:'Water',Water:'Wood'};
const CONTROLS={Wood:'Earth',Fire:'Metal',Earth:'Water',Metal:'Wood',Water:'Fire'};
const STEM_COMBINATIONS={'0,5':'Earth','1,6':'Metal','2,7':'Water','3,8':'Wood','4,9':'Fire'};
const SIX_COMBINATIONS={'0,1':'Earth','2,11':'Wood','3,10':'Fire','4,9':'Metal','5,8':'Water','6,7':'Earth'};
const CLASHES=new Set(['0,6','1,7','2,8','3,9','4,10','5,11']);
const HARMS=new Set(['0,7','1,6','2,5','3,4','8,11','9,10']);
const BREAKS=new Set(['0,9','3,6','1,4','7,10','2,11','5,8']);
const WONJIN=new Set(['0,7','1,6','2,9','3,8','4,11','5,10']);
const THREE_HARMONY=[[[0,4,8],'Water'],[[3,7,11],'Wood'],[[2,6,10],'Fire'],[[1,5,9],'Metal']];
const DIRECTIONAL=[[[2,3,4],'Wood'],[[5,6,7],'Fire'],[[8,9,10],'Metal'],[[0,1,11],'Water']];
const PUNISHMENT_TRIADS=[[2,5,8],[1,7,10]]; const PUNISHMENT_PAIR='0,3'; const SELF_PUNISHMENT=new Set([4,6,9,11]);
const GROWTH_STAGES=[['Birth / Long Life','장생','長生'],['Bath','목욕','沐浴'],['Crown and Belt','관대','冠帶'],['Establishment','건록','建祿'],['Imperial Prosperity','제왕','帝旺'],['Decline','쇠','衰'],['Illness','병','病'],['Death','사','死'],['Tomb','묘','墓'],['Extinction','절','絶'],['Conception','태','胎'],['Nurture','양','養']];
const GROWTH_BIRTH_BRANCH={0:11,1:6,2:2,3:9,4:2,5:9,6:5,7:0,8:8,9:3};
const VOID_BRANCHES_BY_XUN={0:[10,11],1:[8,9],2:[6,7],3:[4,5],4:[2,3],5:[0,1]};

const RESULT_SCHEMA_VERSION='2.2.0-complete';
const ANALYSIS_VERSION='1.7-complete';
const METHOD_REGISTRY={year_boundary:'ipchun-swiss-v1',month_boundary:'sectional-terms-swiss-v1',day_boundary:'configurable-midnight-or-zi-v1',hour_boundary:'double-hour-v1',hidden_stems:'standard-hidden-stems-v1',relationships:'relationship-table-v2-wonjin',growth_stages:'twelve-growth-daymaster-v1',void:'xun-void-v1',major_luck:'sectional-term-3days-v1',weighted_elements:'transparent-hidden-stem-equal-allocation-v1',ten_god_weighting:'transparent-hidden-stem-equal-allocation-v1',chart_strength:'workbook-support-drain-monthbranch-v1',useful_element:'workbook-useful-god-simplified-v1',favourable_element:'workbook-useful-god-simplified-v1',unfavourable_element:'workbook-useful-god-simplified-v1',symbolic_stars:'symbolic-stars-four-rule-set-v1',twelve_stars:'year-branch-trine-12sinsal-v1',lunar_conversion:'korean-lunar-calendar-0.4.0-kari-offline-v1'};
const DEFAULT_ANALYSIS_SETTINGS={apply_combination_transformations:false,seasonal_adjustment:false,palace_weighting:false,hidden_stem_weighting:true,symbolic_stars_enabled:true,twelve_stars_enabled:true};
