"use strict";
/* Lightweight canonical 60 Jiazi index for UI/reference use.
   It is derived only from the stable Stem/Branch tables; it does not alter calculations. */
const JIAZI_REFERENCE=Array.from({length:60},(_,index)=>{
  const stem=STEMS[index%10],branch=BRANCHES[index%12];
  return {index,number:index+1,characters:`${stem.hanja}${branch.hanja}`,stem_index:stem.index,branch_index:branch.index,animal:branch.animal,element:stem.element,yin_yang:stem.yin_yang};
});
