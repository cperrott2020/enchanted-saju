"use strict";
/* Shared DOM, presentation and navigation helpers. */
function jewelTenGodRecordUI(value){if(!value)return null;const raw=typeof value==='string'?value:String(value.hanja||value.ko||value.korean||value.en||value.english||value.key||'');const norm=normaliseConceptQuery(raw.split(' · ')[0]);for(const [hanja,t] of Object.entries(JEWEL_TEN_GOD_TERMS)){if([hanja,t.name,t.technical,t.ko,t.roman,t.key].some(x=>normaliseConceptQuery(x)===norm))return{hanja,...t};}return null;}
function accessibleTenGodNameUI(value){return jewelTenGodRecordUI(value)?.name||(typeof value==='string'?value:(value?.en||value?.english||value?.ko||value?.korean||value?.hanja||''));}
function tenGodSecondaryUI(value){const t=jewelTenGodRecordUI(value);return t?`${t.hanja} · ${t.ko} · ${t.technical}`:'';}
function accessibleStemNameUI(hanja){return JEWEL_STEM_NAMES[String(hanja||'').trim()]||'';}
function accessibleJiaziNameUI(stem,branch){const a=accessibleStemNameUI(stem?.hanja||stem),animal=branch?.animal||branch;return a&&animal?`${a} ${animal}`:'';}
function slugifyTypeNameUI(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');}
function sjpjTypeRecordUI(stem,branch){
  const s=typeof stem==='number'?STEMS[stem]:STEMS.find(x=>x.index===stem?.index||x.hanja===stem?.hanja||x.hanja===stem||x.ko===stem||x.roman===stem);
  const b=typeof branch==='number'?BRANCHES[branch]:BRANCHES.find(x=>x.index===branch?.index||x.hanja===branch?.hanja||x.hanja===branch||x.ko===branch||x.roman===branch||x.animal===branch?.animal||x.animal===branch);
  if(!s||!b)return null;let idx;try{idx=sexagenaryIndex(s.index,b.index);}catch{return null;}
  const name=accessibleJiaziNameUI(s,b)||`${s.yin_yang} ${s.element} ${b.animal}`;
  const folder=`${String(idx+1).padStart(2,'0')}-${slugifyTypeNameUI(name)}`;
  return {index:idx,number:idx+1,name,stem:s,branch:b,characters:`${s.hanja}${b.hanja}`,korean:`${s.ko}${b.ko}`,romanisation:`${s.roman}-${b.roman}`,technical:`${s.yin_yang} ${s.element} ${b.animal}`,element:s.element,yin_yang:s.yin_yang,animal:b.animal,art_family:ELEMENT_ART_FAMILY[s.element],animal_motif:BRANCH_ART_FAMILY[b.animal],folder,emblem:`${SJPJ_AVATAR_ROOT}/${folder}/emblem.svg`,card:`${SJPJ_AVATAR_ROOT}/${folder}/card.svg`};
}
function sjpjTypeArtMarkup(stem,branch,variant='emblem',extraClass=''){
  const r=sjpjTypeRecordUI(stem,branch);if(!r)return'';const src=variant==='card'?r.card:r.emblem;
  return `<div class="sjpj-type-art ${variant==='card'?'card-art':'emblem'} ${esc(extraClass)}" data-type-number="${r.number}" data-element-family="${esc(r.element)}" data-yin-yang="${esc(r.yin_yang)}"><img src="${src}" loading="lazy" alt="${esc(`${r.name} decorative SJPJ type artwork`)}"><span class="sr-only">Decorative symbolic artwork only; it does not alter calculated Saju data.</span></div>`;
}
function sjpjMiniArtMarkup(stem,branch){const r=sjpjTypeRecordUI(stem,branch);if(!r)return'';return `<div class="sjpj-mini-art"><img src="${r.card}" loading="lazy" alt=""><span class="type-label">${esc(r.name)}</span></div>`;}
function sjpjTypeArtFromConceptUI(c){const chars=[...String(c?.hanja||'')];if(c?.category!=='60 Jiazi'||chars.length!==2)return'';const st=STEMS.find(x=>x.hanja===chars[0]),br=BRANCHES.find(x=>x.hanja===chars[1]);return st&&br?`<div class="concept-type-art">${sjpjTypeArtMarkup(st,br,'emblem')}</div>`:'';}
function branchTinyMarkUI(branch){const b=typeof branch==='object'?branch:BRANCHES.find(x=>x.animal===branch||x.hanja===branch);return b?`<span class="animal-tiny-mark" title="${esc(b.animal)}">${esc(b.hanja)}</span>`:'';}
function miniPillarStripUI(t){const p=t?.pillars||{};return `<div class="mini-pillar-strip" aria-label="Four Pillars">${['year','month','day','hour'].map(k=>{const x=p[k];return `<span class="mini-pillar ${k}"><small>${k.slice(0,1).toUpperCase()}</small><b>${esc(`${x?.stem?.hanja||'—'}${x?.branch?.hanja||''}`)}</b></span>`;}).join('')}</div>`;}
function accessibleStoredPillarUI(stem,branch){const s=STEMS.find(x=>x.hanja===stem||x.ko===stem||x.roman===stem),b=BRANCHES.find(x=>x.hanja===branch||x.ko===branch||x.roman===branch||x.animal===branch);return s&&b?accessibleJiaziNameUI(s,b):'';}
function technicalStemIdentityUI(stem){return stem?`${stem.hanja||''} · ${stem.yin_yang||''} ${stem.element||''}`.replace(/\s+/g,' ').trim():'';}
function conceptSearchKey(c){return [c?.preferred_display_name,c?.jewel_sjpj_name,c?.technical_english_name,c?.english,c?.korean_hangul,c?.korean,c?.hanja,c?.romanisation,...(c?.alternative_translations||[]),...(c?.search_aliases||[]),...(c?.source_specific_names||[]).map(x=>x?.term),...(c?.metaphors||[])].filter(Boolean).join(' ').normalize('NFKC').toLowerCase().replace(/[\s\-_–—·.()\/'’]+/g,'');}
function normaliseConceptQuery(v){return String(v||'').normalize('NFKC').toLowerCase().replace(/[\s\-_–—·.()\/'’]+/g,'');}
const $=s=>document.querySelector(s); const form=$('#chart-form'); const errorBox=$('#error');
const esc=s=>String(s??'').replace(/[&<>'\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const selected=n=>form.querySelector(`[name="${n}"]:checked`)?.value; const value=n=>form.elements[n]?.value; const checked=n=>!!form.elements[n]?.checked;
const elemClass=e=>String(e||'').toLowerCase();
function methodologyHtml(m={}){const reg=m.registry||m;const rows=Object.entries(reg).map(([k,v])=>`<div class="stat"><small>${esc(k.replaceAll('_',' '))}</small><b style="font-size:12px">${v?esc(v):'Methodology Pending'}</b></div>`).join('');return `<div class="stat-grid">${rows}</div>${m.pending?.length?`<p class="micro">Pending: ${esc(m.pending.join(', '))}</p>`:''}`;}
function currentPage(){return document.querySelector('.app-page.active')?.id?.replace('page-','')||'today';}
async function switchPage(name){document.querySelectorAll('.app-page').forEach(x=>x.classList.toggle('active',x.id===`page-${name}`));document.querySelectorAll('.app-nav [data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===name));window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});if(['today','my-saju','luck-calendar','journal','timeline','people','compare','glossary','settings'].includes(name))await ensureProfiles();if(name==='people')renderPeopleList();if(name==='compare')prepareComparePage();if(name==='glossary'&&!glossaryCache.length)await loadConcepts();if(name==='research'&&!researchLibraryCache.length)loadResearchLibrary();if(name==='my-saju')renderMySajuState();if(name==='journal'){loadJournal();loadJournalDay();loadJournalAnalytics();}if(name==='timeline')loadTimelinePage();if(name==='today'&&activeProfile)previewActiveToday(false);if(name==='settings'){if(selectedChartData)$('#methodology-status').innerHTML=methodologyHtml(selectedChartData.methodology||{});}}
document.querySelectorAll('.app-nav [data-page]').forEach(b=>b.addEventListener('click',()=>switchPage(b.dataset.page)));
document.querySelectorAll('[data-page-jump]').forEach(b=>b.addEventListener('click',()=>switchPage(b.dataset.pageJump)));
document.querySelector('.new-chart-nav')?.addEventListener('click',()=>{editingProfileId=null;const f=$('#chart-form');if(f){f.reset();syncCalendarInputs();}if($('#notion-default-profile'))$('#notion-default-profile').checked=false;$('#results')?.classList.add('hidden');});

/* Existing note views referenced this renderer without defining it in the monolith.
   This compatibility helper renders the backend's existing personal-note shape only. */
function renderPersonalNotes(notes=[]){
  return notes.length?notes.map(n=>`<div class="journal-entry personal-note"><b>${esc(n.title||'My Note')}</b><div class="micro">${esc(n.created?String(n.created).slice(0,10):'')}</div><p>${esc(n.text||'')}</p>${n.questions?`<div class="micro"><b>Questions:</b> ${esc(n.questions)}</div>`:''}</div>`).join(''):'<div class="empty">No personal notes yet.</div>';
}
