"use strict";
/* DETERMINISTIC CALCULATION ENGINE
   Migrated without changing formula logic. Presentation and interpretation live elsewhere. */
const mod=(a,n)=>((a%n)+n)%n;
const key2=(a,b)=>[a,b].sort((x,y)=>x-y).join(',');
function jdFromUnix(ms){return 2440587.5+ms/86400000;}
function unixFromJd(jd){return (jd-2440587.5)*86400000;}
function iso(ms){return new Date(ms).toISOString();}
function naiveISO(ms){return new Date(ms).toISOString().slice(0,19);}
function fmtTime(x){if(!x)return'—'; return String(x).replace('T',' ').replace('Z',' UTC');}
function gregorianJDN(y,m,d){const a=Math.floor((14-m)/12), yy=y+4800-a, mm=m+12*a-3; return d+Math.floor((153*mm+2)/5)+365*yy+Math.floor(yy/4)-Math.floor(yy/100)+Math.floor(yy/400)-32045;}
function pillarLabel(s,b){return `${STEMS[s].roman}-${BRANCHES[b].roman} (${STEMS[s].hanja}${BRANCHES[b].hanja})`;}

function tzParts(ms,tz){
  const f=new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  const o={}; for(const p of f.formatToParts(new Date(ms))) if(p.type!=='literal') o[p.type]=p.value;
  return {y:+o.year,m:+o.month,d:+o.day,h:+o.hour,min:+o.minute,s:+o.second};
}
function tzOffsetMinutes(ms,tz){const p=tzParts(ms,tz); const asUTC=Date.UTC(p.y,p.m-1,p.d,p.h,p.min,p.s); return (asUTC-ms)/60000;}
function zonedToUtc(y,m,d,h,min,tz){
  const wall=Date.UTC(y,m-1,d,h,min,0); let utc=wall;
  for(let i=0;i<6;i++){const off=tzOffsetMinutes(utc,tz); const next=wall-off*60000; if(Math.abs(next-utc)<500){utc=next;break;} utc=next;}
  return utc;
}
function standardOffsetForYear(year,tz){
  const counts=new Map();
  for(let month=0;month<12;month++){
    const ms=Date.UTC(year,month,15,12); let off;
    try{off=tzOffsetMinutes(ms,tz);}catch{continue;}
    counts.set(off,(counts.get(off)||0)+1);
  }
  if(!counts.size) throw new Error('Timezone could not be resolved by this browser');
  return [...counts.entries()].sort((a,b)=>b[1]-a[1] || Math.abs(a[0])-Math.abs(b[0]))[0][0];
}
function validTimeZone(tz){try{new Intl.DateTimeFormat('en-US',{timeZone:tz}).format(); return true;}catch{return false;}}

function eotSecondsSwiss(jd){
  const arr=decodeEOT(); const x=jd-EOT_START_JD; const i=Math.floor(x); const f=x-i;
  if(i>=0 && i+1<arr.length) return arr[i]*(1-f)+arr[i+1]*f;
  return eotSecondsApprox(jd);
}
function eotSecondsApprox(jd){
  const T=(jd-2451545.0)/36525; const rad=Math.PI/180;
  let L0=mod(280.46646+T*(36000.76983+0.0003032*T),360); let M=357.52911+T*(35999.05029-0.0001537*T);
  const e=0.016708634-T*(0.000042037+0.0000001267*T);
  const omega=125.04-1934.136*T;
  const eps0=23+(26+(21.448-T*(46.815+T*(0.00059-T*0.001813)))/60)/60;
  const eps=eps0+0.00256*Math.cos(omega*rad); const y=Math.tan((eps*rad)/2)**2;
  const E=y*Math.sin(2*L0*rad)-2*e*Math.sin(M*rad)+4*e*y*Math.sin(M*rad)*Math.cos(2*L0*rad)-0.5*y*y*Math.sin(4*L0*rad)-1.25*e*e*Math.sin(2*M*rad);
  return (E/rad)*240;
}
function solarLongitudeApprox(jd){
  const T=(jd-2451545.0)/36525, rad=Math.PI/180;
  const L0=mod(280.46646+T*(36000.76983+0.0003032*T),360); const M=357.52911+T*(35999.05029-0.0001537*T);
  const C=Math.sin(M*rad)*(1.914602-T*(0.004817+0.000014*T))+Math.sin(2*M*rad)*(0.019993-0.000101*T)+Math.sin(3*M*rad)*0.000289;
  const omega=125.04-1934.136*T; return mod(L0+C-0.00569-0.00478*Math.sin(omega*rad),360);
}

function getTermEventsAround(year){
  const out=[];
  for(const y of [year-1,year,year+1]){
    const a=SWISS_TERMS[String(y)]; if(!a) continue;
    for(let i=0;i<12;i++) out.push({baseYear:y,index:i,target:mod(315+30*i,360),ms:a[i]*1000,jd:jdFromUnix(a[i]*1000)});
  }
  return out.sort((a,b)=>a.ms-b.ms);
}
function monthBoundaryInfo(birthMs, localYear){
  const events=getTermEventsAround(localYear); if(!events.length) throw new Error('Embedded Swiss solar-term table supports birth years 1800–2200.');
  let prev=null,next=null;
  for(const e of events){ if(e.ms<=birthMs) prev=e; else {next=e;break;} }
  if(!prev||!next) throw new Error('Could not resolve solar-term boundary for this date.');
  return {month_index:prev.index,previous:{longitude:prev.target,utc:iso(prev.ms),minutes_away:(birthMs-prev.ms)/60000},next:{longitude:next.target,utc:iso(next.ms),minutes_away:(next.ms-birthMs)/60000}};
}
function liChunMs(year){const a=SWISS_TERMS[String(year)]; if(!a) throw new Error('Embedded Swiss solar-term table supports years 1799–2201.'); return a[0]*1000;}

function tenGod(dmIdx,targetIdx){const dm=STEMS[dmIdx],t=STEMS[targetIdx], same=dm.yin_yang===t.yin_yang; let key;
  if(dm.element===t.element) key=same?'friend':'rob_wealth';
  else if(GENERATES[dm.element]===t.element) key=same?'eating_god':'hurting_officer';
  else if(CONTROLS[dm.element]===t.element) key=same?'indirect_wealth':'direct_wealth';
  else if(CONTROLS[t.element]===dm.element) key=same?'seven_killings':'direct_officer';
  else if(GENERATES[t.element]===dm.element) key=same?'indirect_resource':'direct_resource';
  else throw new Error('Unreachable Five Element relation'); return {key,...TEN_GODS[key]};
}
function stemPayload(i,dm=null,dayMaster=false){const p={...STEMS[i]}; if(dayMaster)p.ten_god={key:'day_master',en:'Day Master',ko:'일간',hanja:'日干'}; else if(dm!==null)p.ten_god=tenGod(dm,i); return p;}
function branchPayload(i,dm){return {...BRANCHES[i],hidden_stems:HIDDEN_STEMS[i].map(s=>stemPayload(s,dm))};}
function growthStage(dm,b){const start=GROWTH_BIRTH_BRANCH[dm], dir=STEMS[dm].yin_yang==='Yang'?1:-1, idx=mod((b-start)*dir,12), [en,ko,hanja]=GROWTH_STAGES[idx]; return {index:idx,en,ko,hanja};}
function buildPillar(s,b,dm,name){return {name,label:pillarLabel(s,b),stem:stemPayload(s,dm,name==='day'),branch:branchPayload(b,dm),growth_stage:growthStage(dm,b)};}
function naiveParts(ms){const d=new Date(ms);return{y:d.getUTCFullYear(),m:d.getUTCMonth()+1,d:d.getUTCDate(),h:d.getUTCHours(),min:d.getUTCMinutes(),s:d.getUTCSeconds()};}
function dayIndexForNaive(ms,conv){let p=naiveParts(ms); let dms=Date.UTC(p.y,p.m-1,p.d); if(conv==='zi_start'&&p.h>=23)dms+=86400000; else if(!['midnight','zi_start'].includes(conv))throw new Error('Invalid day boundary'); const q=new Date(dms); const j=gregorianJDN(q.getUTCFullYear(),q.getUTCMonth()+1,q.getUTCDate()); return {index:mod(j+49,60),date:q.toISOString().slice(0,10)};}
function hourBranch(ms){const p=naiveParts(ms), mins=p.h*60+p.min+p.s/60; return Math.floor(mod(mins/60+1,24)/2);}
function nearestHourBoundary(ms){const p=naiveParts(ms), x=p.h*60+p.min+p.s/60; const bs=Array.from({length:12},(_,i)=>60+120*i); return Math.min(...bs.map(b=>Math.abs(x-b)));}
function dayBoundaryMinutes(ms,conv){const p=naiveParts(ms),x=p.h*60+p.min+p.s/60; return conv==='midnight'?Math.min(x,1440-x):Math.abs(x-1380);}
function sexagenaryIndex(s,b){for(let i=0;i<60;i++)if(i%10===s&&i%12===b)return i; throw new Error('Invalid stem/branch parity');}
function luckDirection(yearStem,sex,explicit){if(explicit==='forward')return 1;if(explicit==='backward')return-1;if(explicit!=='auto'&&explicit!=null)throw new Error('Invalid luck direction');if(!['male','female'].includes(sex))return null;const yang=STEMS[yearStem].yin_yang==='Yang';return ((sex==='male'&&yang)||(sex==='female'&&!yang))?1:-1;}
function daewoon(pillars,monthBounds,sex,explicit,count=8){const dir=luckDirection(pillars.year.stem.index,sex,explicit); if(dir===null)return{status:'needs_method_input',reason:'Traditional auto-direction requires male/female basis or an explicit forward/backward choice.',method:'year-stem polarity × traditional sex basis; 3 days = 1 year',cycles:[]}; const boundary=dir===1?monthBounds.next:monthBounds.previous; const days=Math.abs(boundary.minutes_away)/1440, start=days/3, monthIdx=sexagenaryIndex(pillars.month.stem.index,pillars.month.branch.index),dm=pillars.day.stem.index,cycles=[]; for(let n=1;n<=count;n++){const idx=mod(monthIdx+dir*n,60),s=idx%10,b=idx%12;cycles.push({cycle_number:n,sexagenary_index:idx,start_age:+(start+(n-1)*10).toFixed(3),end_age:+(start+n*10).toFixed(3),stem:stemPayload(s,dm),branch:branchPayload(b,dm),label:pillarLabel(s,b),ten_god:tenGod(dm,s),growth_stage:growthStage(dm,b)});} return{status:'calculated',direction:dir===1?'forward':'backward',days_to_sectional_term:+days.toFixed(6),start_age_years:+start.toFixed(6),method:'standard configurable v1: year-stem polarity × traditional sex basis; nearest sectional term; 3 days = 1 year',note:'Exact transition-date conversion is not asserted in v0.1; start age is the audited primary output.',cycles};}
function rawElements(pillars){const es=['Wood','Fire','Earth','Metal','Water'],vs=Object.fromEntries(es.map(e=>[e,0])),bp=Object.fromEntries(es.map(e=>[e,0])),hs=Object.fromEntries(es.map(e=>[e,0]));Object.values(pillars).forEach(p=>{if(!p)return;vs[p.stem.element]++;bp[p.branch.element]++;p.branch.hidden_stems.forEach(x=>hs[x.element]++);});const combined=Object.fromEntries(es.map(e=>[e,vs[e]+bp[e]+hs[e]]));return{visible_stems:vs,branch_primary_elements:bp,hidden_stems_unweighted:hs,combined_unweighted_presence:combined,note:'Presence counts are not strength percentages. No hidden-stem weighting or seasonal strength is implied.'};}
function voidPayload(dayIdx,pillars){const x=Math.floor(dayIdx/10),vs=VOID_BRANCHES_BY_XUN[x],hits=[];Object.entries(pillars).forEach(([n,p])=>{if(p&&vs.includes(p.branch.index))hits.push(n)});return{xun_index:x,void_branches:vs.map(i=>({...BRANCHES[i]})),natal_hits:hits};}
function relationshipRecords(pillars){const order=['year','month','day','hour'].filter(k=>pillars[k]);const stems=order.map(k=>[k,pillars[k].stem.index]),branches=order.map(k=>[k,pillars[k].branch.index]);const r={stem_combinations:[],six_combinations:[],three_harmony:[],directional:[],clashes:[],punishments:[],harms:[],breaks:[],wonjin:[]};
 for(let i=0;i<stems.length;i++)for(let j=i+1;j<stems.length;j++){const [pa,a]=stems[i],[pb,b]=stems[j],k=key2(a,b);if(STEM_COMBINATIONS[k])r.stem_combinations.push({pillars:[pa,pb],stems:[STEMS[a].hanja,STEMS[b].hanja],traditional_transform_element:STEM_COMBINATIONS[k],transformation_evaluated:false});}
 for(let i=0;i<branches.length;i++)for(let j=i+1;j<branches.length;j++){const [pa,a]=branches[i],[pb,b]=branches[j],k=key2(a,b),base={pillars:[pa,pb],branches:[BRANCHES[a].hanja,BRANCHES[b].hanja]};if(SIX_COMBINATIONS[k])r.six_combinations.push({...base,traditional_transform_element:SIX_COMBINATIONS[k],transformation_evaluated:false});if(CLASHES.has(k))r.clashes.push(base);if(HARMS.has(k))r.harms.push(base);if(BREAKS.has(k))r.breaks.push(base);if(WONJIN.has(k))r.wonjin.push({...base,method_version:'wonjin-pairs-v1'});if(k===PUNISHMENT_PAIR)r.punishments.push({...base,subtype:'Zi-Mao punishment'});}
 const set=new Set(branches.map(x=>x[1])); for(const [tri,el] of THREE_HARMONY)if(tri.every(x=>set.has(x)))r.three_harmony.push({branches:[...tri].sort((a,b)=>a-b).map(x=>BRANCHES[x].hanja),element:el,transformation_evaluated:false}); for(const [tri,el] of DIRECTIONAL)if(tri.every(x=>set.has(x)))r.directional.push({branches:[...tri].sort((a,b)=>a-b).map(x=>BRANCHES[x].hanja),element:el,transformation_evaluated:false}); for(const tri of PUNISHMENT_TRIADS)if(tri.every(x=>set.has(x)))r.punishments.push({branches:[...tri].sort((a,b)=>a-b).map(x=>BRANCHES[x].hanja),subtype:'three-branch punishment group'}); for(const b of SELF_PUNISHMENT){const pos=branches.filter(x=>x[1]===b).map(x=>x[0]);if(pos.length>=2)r.punishments.push({pillars:pos,branches:pos.map(()=>BRANCHES[b].hanja),subtype:'self-punishment (repeated branch)'});}return r;}
function trueSolar(civilNaiveMs,utcMs,year,tz,lon){const currentOffset=tzOffsetMinutes(utcMs,tz),stdOffset=standardOffsetForYear(year,tz),dst=currentOffset-stdOffset,stdMeridian=stdOffset/60*15,longMin=4*(lon-stdMeridian),jd=jdFromUnix(utcMs),eot=eotSecondsSwiss(jd)/60,corrected=civilNaiveMs-dst*60000+(longMin+eot)*60000;return{corrected_naive_ms:corrected,dst_minutes_removed:dst,standard_utc_offset_hours:stdOffset/60,standard_meridian_degrees:stdMeridian,longitude_correction_minutes:longMin,equation_of_time_minutes:eot,total_clock_to_solar_minutes:-dst+longMin+eot};}

function calculateChart(data){
  const [Y,M,D]=data.birth_date.split('-').map(Number); if(Y<1800||Y>2200) throw new Error('This standalone HTML build currently supports birth years 1800–2200.'); if(!validTimeZone(data.timezone))throw new Error('Invalid IANA timezone. Example: Asia/Seoul or Europe/Dublin.'); const timeStatus=data.time_status||'exact'; let h=12,min=0,supplied=null;if(timeStatus!=='unknown'){if(!data.birth_time)throw new Error('Birth time is required unless time is unknown.');[h,min]=data.birth_time.split(':').map(Number);supplied=`${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}`;}
 const lat=+data.latitude,lon=+data.longitude;if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat<-90||lat>90||lon<-180||lon>180)throw new Error('Latitude/longitude out of range.');
 const civilNaive=Date.UTC(Y,M-1,D,h,min,0); const utcMs=zonedToUtc(Y,M,D,h,min,data.timezone); const jd=jdFromUnix(utcMs); const offset=tzOffsetMinutes(utcMs,data.timezone); const solar=trueSolar(civilNaive,utcMs,Y,data.timezone,lon); const effective=data.use_true_solar_time?solar.corrected_naive_ms:civilNaive; const dayBoundary=data.day_boundary||'midnight';
 const li=liChunMs(Y),sajuYear=utcMs>=li?Y:Y-1,ys=mod(sajuYear-4,10),yb=mod(sajuYear-4,12); const monthBounds=monthBoundaryInfo(utcMs,Y),mi=monthBounds.month_index,mb=mod(2+mi,12),ms=mod(2*ys+2+mi,10);
 const di=dayIndexForNaive(effective,dayBoundary),ds=di.index%10,db=di.index%12; let hs=null,hb=null;if(timeStatus!=='unknown'){hb=hourBranch(effective);hs=mod(2*ds+hb,10);} const pillars={year:buildPillar(ys,yb,ds,'year'),month:buildPillar(ms,mb,ds,'month'),day:buildPillar(ds,db,ds,'day'),hour:hs===null?null:buildPillar(hs,hb,ds,'hour')};
 const safety=+(data.boundary_safety_minutes||120),yearMin=Math.abs(utcMs-li)/60000,monthMin=Math.min(monthBounds.previous.minutes_away,monthBounds.next.minutes_away),hourMin=timeStatus==='unknown'?null:nearestHourBoundary(effective),dayMin=dayBoundaryMinutes(effective,dayBoundary),warnings=[]; if(yearMin<=safety)warnings.push('YEAR PILLAR BOUNDARY CASE'); if(monthMin<=safety)warnings.push('MONTH PILLAR BOUNDARY CASE');if(dayMin<=safety)warnings.push('DAY BOUNDARY SENSITIVE');if(hourMin!==null&&hourMin<=safety)warnings.push('HOUR PILLAR BOUNDARY SENSITIVE');if(timeStatus==='unknown')warnings.push('HOUR PILLAR OMITTED — BIRTH TIME UNKNOWN');
 const civilDI=dayIndexForNaive(civilNaive,dayBoundary).index,civilHB=timeStatus==='unknown'?null:hourBranch(civilNaive),solarHB=timeStatus==='unknown'?null:hourBranch(solar.corrected_naive_ms); const result={calculation_status:'deterministic browser engine hosted with secure Cloudflare-to-Notion bridge; embedded Swiss Ephemeris solar-term/EOT tables; ForceTeller validation pending',certified_forceteller_match:false,engine:{version:'0.4-cloudflare-html',calculation_reference:'ForceTeller-style workflow; independent deterministic browser engine',ephemeris:'Embedded Swiss Ephemeris sectional-term timestamps + daily equation-of-time table (1799–2201)',timezone_engine:'Browser Intl/IANA timezone database',day_anchor:'(Gregorian JDN + 49) mod 60; 1949-10-01 = Gap-Ja / 甲子',year_boundary:'exact embedded Swiss solar longitude 315° (Ipchun)',month_boundary:'12 embedded Swiss sectional terms at 30° intervals beginning 315°',day_boundary:dayBoundary,true_solar_time:!!data.use_true_solar_time,hidden_stem_table:'standard existence table v1; weights not asserted',strength_model:'not enabled until a specific auditable school/formula is selected',useful_element_model:'not enabled until a specific auditable school/formula is selected',symbolic_star_model:'not enabled until documented rules are selected'},identity:{name:data.name||'',nickname:data.nickname||'',sex:data.sex||'unspecified'},birth:{original_date:data.birth_date,original_time:supplied,time_status:timeStatus,place_label:data.place||'',latitude:lat,longitude:lon,iana_timezone:data.timezone,historical_utc_offset_minutes:offset,resolved_utc:iso(utcMs),civil_local:`${data.birth_date}T${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}:00`,corrected_solar_local:naiveISO(solar.corrected_naive_ms),effective_for_day_hour:naiveISO(effective),effective_day_date:di.date,solar_correction:{dst_minutes_removed:solar.dst_minutes_removed,standard_utc_offset_hours:solar.standard_utc_offset_hours,standard_meridian_degrees:solar.standard_meridian_degrees,longitude_correction_minutes:solar.longitude_correction_minutes,equation_of_time_minutes:solar.equation_of_time_minutes,total_clock_to_solar_minutes:solar.total_clock_to_solar_minutes},correction_changes_chart:{day_pillar:civilDI!==di.index,hour_branch:timeStatus==='unknown'?null:civilHB!==solarHB}},astronomy:{birth_jd_ut:jd,solar_longitude_degrees_approx:solarLongitudeApprox(jd),li_chun_utc:iso(li),month_boundaries:monthBounds},boundary_check:{safety_window_minutes:safety,year_boundary_minutes_away:yearMin,month_boundary_minutes_away:monthMin,day_boundary_minutes_away:dayMin,hour_boundary_minutes_away:hourMin,warnings,boundary_sensitive:warnings.length>0},pillars,day_master:stemPayload(ds,ds,true),five_elements:rawElements(pillars),relationships:relationshipRecords(pillars),void:voidPayload(di.index,pillars),daewoon:daewoon(pillars,monthBounds,String(data.sex||'unspecified').toLowerCase(),data.luck_direction||'auto',+(data.daewoon_cycles||8)),interpretation:{status:'separate_layer',message:'This file returns calculated structure only. Interpretive prose must not alter these values.'}};
 if(timeStatus==='approximate'){const u=+(data.uncertainty_minutes||30),variants=[-u,u].map(delta=>{const c=effective+delta*60000,dix=dayIndexForNaive(c,dayBoundary),dbx=dix.index%12,dsx=dix.index%10,hbx=hourBranch(c),hsx=mod(2*dsx+hbx,10);return{offset_minutes:delta,effective_time:naiveISO(c),day:pillarLabel(dsx,dbx),hour:pillarLabel(hsx,hbx)}}); if(variants[0].day!==variants[1].day||variants[0].hour!==variants[1].hour){result.time_uncertainty_variants=variants;result.boundary_check.warnings.push('APPROXIMATE BIRTH TIME CROSSES A PILLAR BOUNDARY');result.boundary_check.boundary_sensitive=true;}}
 return result;
}
