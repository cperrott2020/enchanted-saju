"use strict";
/* Client-side Cloudflare/Notion bridge. No server-side secrets are stored here. */
const NOTION_TARGETS={
  people_data_source_id:'809d7190-6e92-83cb-a0a2-870acced4b32',
  charts_data_source_id:'03bd7190-6e92-82e8-a221-872314de70bb',
  luck_cycles_data_source_id:'c97d7190-6e92-826c-aa6f-07fb0a455e64',
  readings_data_source_id:'3afd7190-6e92-8334-ba46-075fb5f99099',
  concepts_data_source_id:'7cfd7190-6e92-83a7-939a-071e83a28769',
  daily_luck_data_source_id:'770d7190-6e92-82c7-b954-070647d8ea4f'
};
function compactPillar(p){
  if(!p)return null;
  return {
    label:p.label,
    stem:{english:p.stem.roman,korean:p.stem.ko,hanja:p.stem.hanja,element:p.stem.element,yin_yang:p.stem.yin_yang,ten_god:p.stem.ten_god||null},
    branch:{english:p.branch.roman,korean:p.branch.ko,hanja:p.branch.hanja,animal:p.branch.animal,element:p.branch.element,yin_yang:p.branch.yin_yang},
    hidden_stems:(p.branch.hidden_stems||[]).map(s=>({english:s.roman,korean:s.ko,hanja:s.hanja,element:s.element,yin_yang:s.yin_yang,ten_god:s.ten_god||null})),
    growth_stage:p.growth_stage||null
  };
}

function readAnalysisSettings(){return{apply_combination_transformations:false,seasonal_adjustment:false,palace_weighting:false,hidden_stem_weighting:$('#setting-hidden')?!!$('#setting-hidden').checked:DEFAULT_ANALYSIS_SETTINGS.hidden_stem_weighting,symbolic_stars_enabled:true,twelve_stars_enabled:true};}
function notionPayload(r){
  const name=r.identity.name||r.identity.nickname||'Unnamed Saju Profile';
  const profileCategory=$('#notion-profile-category')?.value||'Other';
  const personType=profileCategory==='Me'?'Me':profileCategory==='Family'?'Family':profileCategory==='Friend'?'Friend':'Casual Reading';
  const status=$('#notion-chart-status').value;
  const p=r.pillars, b=r.birth;
  const luck=(r.daewoon?.cycles||[]).map(c=>({
    cycle_number:c.cycle_number,
    cycle_type:'Major Luck',
    label:c.label,
    start_age:c.start_age,
    end_age:c.end_age,
    stem:c.stem,
    branch:c.branch,
    ten_god:c.ten_god,
    calculation_method:r.daewoon.method||''
  }));
  return {
    schema_version:'enchanted-saju-result-v2',
    action:'upsert_saju_profile',
    generated_at:new Date().toISOString(),
    options:{
      upsert_person:$('#opt-person').checked,
      create_chart:$('#opt-chart').checked,
      create_major_luck_cycles:$('#opt-luck').checked,
      create_reading:$('#opt-reading').checked
    },
    notion_targets:NOTION_TARGETS,
    person:{
      ...(editingProfileId?{id:editingProfileId}:{}),
      name,
      preferred_name:r.identity.nickname||'',
      person_type:personType,
      birth_date:r.calendar_conversion?.normalised_gregorian_date||b.normalised_gregorian_date||b.original_date,
      birth_time:b.original_time,
      birth_time_status:b.time_status,
      birthplace:b.place_label,
      latitude:b.latitude,
      longitude:b.longitude,
      timezone:b.iana_timezone,
      sex:r.identity.sex,
      sex_basis:({female:'Female',male:'Male'})[String(r.identity.sex||'').toLowerCase()]||'Unspecified',
      profile_category:profileCategory,
      ...($('#notion-default-profile')?.checked?{default_profile:true}:{})
    },
    chart:{
      chart_name:`${name} · Natal Saju`,
      status,
      birth_date:r.calendar_conversion?.normalised_gregorian_date||b.normalised_gregorian_date||b.original_date,
      recorded_birth_time:b.original_time,
      corrected_time:b.corrected_solar_local,
      birthplace:b.place_label,
      timezone:b.iana_timezone,
      calendar_type:r.input_calendar||value('calendar_type')||'Gregorian',
      year_pillar:p.year?.label||'',
      month_pillar:p.month?.label||'',
      day_pillar:p.day?.label||'',
      hour_pillar:p.hour?.label||'',
      day_master:r.day_master,
      pillars:{hour:compactPillar(p.hour),day:compactPillar(p.day),month:compactPillar(p.month),year:compactPillar(p.year)},
      five_elements:r.five_elements,
      weighted_elements:r.elements_weighted||null,
      raw_ten_gods:rawTenGodDistribution(p).counts,
      weighted_ten_gods:r.weighted_ten_gods||null,
      chart_strength_result:r.chart_strength_result||r.strength||null,
      calendar_conversion:r.calendar_conversion||null,
      relationships:r.relationships,
      void:r.void,
      boundary_warning:!!r.boundary_check?.boundary_sensitive,
      boundary_warnings:r.boundary_check?.warnings||[],
      calculation_version:r.engine.version,
      calculation_reference:r.engine.calculation_reference,
      force_teller_match_certified:!!r.certified_forceteller_match,
      live_astronomy_crosscheck:r.external_crosscheck||null,
      analysis_version:ANALYSIS_VERSION,
      analysis_settings:readAnalysisSettings(),
      method_registry:METHOD_REGISTRY,
      result_schema_version:RESULT_SCHEMA_VERSION,
      strength_method:r.strength?.method||METHOD_REGISTRY.chart_strength,
      useful_element:r.useful_element||null,
      favourable_element:r.favourable_element||null,
      unfavourable_element:r.unfavourable_element||null,
      symbolic_stars:r.symbolic_stars||null,
      twelve_stars:r.twelve_stars||null,
      useful_element_method:r.useful_element?.method||METHOD_REGISTRY.useful_element,
      symbolic_star_method:r.symbolic_stars?.method||METHOD_REGISTRY.symbolic_stars,
      major_luck_method:r.daewoon?.method||'',
      daewoon_start_age:r.daewoon?.start_age_years??null,
      daewoon_number:r.daewoon?.cycles?.length||0
    },
    major_luck_cycles:luck,
    reading:$('#opt-reading').checked?{
      reading_type:'Natal',
      reading_date:new Date().toISOString().slice(0,10),
      status:'Draft',
      main_themes:'',
      note:'Created from verified calculator export; interpretation is a separate layer.'
    }:null,
    audit:{
      calculation_status:r.calculation_status,
      engine:r.engine,
      birth:r.birth,
      astronomy:r.astronomy,
      boundary_check:r.boundary_check,
      calendar_conversion:r.calendar_conversion||null,
      element_weighting:r.elements_weighted||null,
      ten_god_weighting:r.weighted_ten_gods||null,
      chart_strength:r.chart_strength_result||r.strength||null,
      useful_element:r.useful_element||null,
      favourable_element:r.favourable_element||null,
      unfavourable_element:r.unfavourable_element||null,
      symbolic_stars:r.symbolic_stars||null,
      twelve_stars:r.twelve_stars||null,
      analysis_settings:r.analysis_settings||readAnalysisSettings(),
      method_registry:METHOD_REGISTRY
    },
    raw_calculation:r
  };
}
function downloadObject(obj,filename){
  const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=u;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
}
function chartFileStem(){
  if(!lastResult)return'saju-chart';
  return `saju-${(lastResult.identity.name||'chart').replace(/[^a-z0-9_-]+/gi,'_')}-${lastResult.birth.original_date}`;
}
$('#download-json').addEventListener('click',()=>{if(lastResult)downloadObject(lastResult,`${chartFileStem()}.json`);});
$('#copy-json').addEventListener('click',async()=>{if(!lastResult)return;try{await navigator.clipboard.writeText(JSON.stringify(lastResult,null,2));$('#save-message').textContent='Chart JSON copied.';}catch{$('#save-message').textContent='Clipboard unavailable. Use Download Chart JSON.';}});
$('#download-notion-json').addEventListener('click',()=>{if(lastResult)downloadObject(notionPayload(lastResult),`${chartFileStem()}-notion.json`);});
$('#copy-notion-json').addEventListener('click',async()=>{if(!lastResult)return;try{await navigator.clipboard.writeText(JSON.stringify(notionPayload(lastResult),null,2));$('#save-message').textContent='Notion-ready JSON copied.';}catch{$('#save-message').textContent='Clipboard unavailable. Use Download Notion JSON.';}});
$('#verified-check').addEventListener('change',e=>{$('#send-webhook').disabled=!e.target.checked;});
$('#save-key').value=storageGet(STORAGE_KEYS.connection,'');
$('#save-key').addEventListener('change',e=>storageSet(STORAGE_KEYS.connection,e.target.value));
$('#notion-profile-category').value=storageGet(STORAGE_KEYS.profileCategory,'Me');
$('#notion-profile-category').addEventListener('change',e=>storageSet(STORAGE_KEYS.profileCategory,e.target.value));
function connectionKey(){return $('#save-key').value.trim();}
function renderSavedLinks(data){
  const items=[];
  if(data.person?.url)items.push(`<a class="integration-link" href="${data.person.url}" target="_blank" rel="noopener">Open Person in Notion ↗</a>`);
  if(data.chart?.url)items.push(`<a class="integration-link" href="${data.chart.url}" target="_blank" rel="noopener">Open Chart in Notion ↗</a>`);
  if(data.reading?.url)items.push(`<a class="integration-link" href="${data.reading.url}" target="_blank" rel="noopener">Open Reading in Notion ↗</a>`);
  $('#saved-links').innerHTML=items.join(' &nbsp; ');
}
$('#test-connection').addEventListener('click',async()=>{
  const key=connectionKey();
  if(!key){$('#save-message').textContent='Enter your private connection key first.';return;}
  storageSet(STORAGE_KEYS.connection,key);
  const b=$('#test-connection');b.disabled=true;b.textContent='Testing…';
  try{
    const resp=await fetch('/api/connection',{headers:{'X-Saju-Key':key}});
    const data=await resp.json().catch(()=>({}));
    if(!resp.ok||!data.ok)throw new Error(data.error||`HTTP ${resp.status}`);
    $('#save-message').textContent=`✓ Notion connected${data.bot_name?` as ${data.bot_name}`:''}${data.daily_timezone?` · Daily timezone ${data.daily_timezone}`:''}${data.ai_binding_configured?` · Workers AI ready (${data.ai_model})`:' · Workers AI binding missing'}${data.lunar_conversion_ready?' · Lunar conversion ready · offline':' · Lunar conversion unavailable'}.`;
    if(data.daily_timezone){$('#daily-timezone').value=data.daily_timezone;storageSet(STORAGE_KEYS.dailyTimezone,data.daily_timezone);}
  }catch(e){$('#save-message').textContent=`Connection test failed: ${e.message}`;}
  finally{b.disabled=false;b.textContent='Test Notion connection';}
});
$('#send-webhook').addEventListener('click',async()=>{
  if(!lastResult)return;
  if(!$('#verified-check').checked){$('#save-message').textContent='Check the verification box first.';return;}
  const key=connectionKey();
  if(!key){$('#save-message').textContent='Open First-time connection setup and enter your private connection key.';return;}
  storageSet(STORAGE_KEYS.connection,key);
  const b=$('#send-webhook');b.disabled=true;b.textContent='Saving to Notion…';$('#saved-links').innerHTML='';
  try{
    const payload=notionPayload(lastResult);
    const resp=await fetch('/api/save-chart',{method:'POST',headers:{'Content-Type':'application/json','X-Saju-Key':key},body:JSON.stringify(payload)});
    const data=await resp.json().catch(()=>({}));
    if(!resp.ok||!data.ok)throw new Error(data.error||`Cloudflare bridge returned ${resp.status}`);
    $('#save-message').textContent='✓ Core Person + Chart saved. Finishing audit and Luck Cycle records…';
    renderSavedLinks(data);
    let finalized=null,finalizeError=null;
    if(data.finalize_required&&data.chart?.id){
      const finalizeBody={payload,chart_id:data.chart.id,person_id:data.person?.id||'',revision:data.revision||1,concepts:data.finalize_context?.concepts||[]};
      for(let attempt=0;attempt<2&&!finalized;attempt++){
        try{
          const fr=await fetch('/api/save-chart/finalize',{method:'POST',headers:{'Content-Type':'application/json','X-Saju-Key':key},body:JSON.stringify(finalizeBody)});
          const fd=await fr.json().catch(()=>({}));
          if(!fr.ok||!fd.ok)throw new Error(fd.error||`Finalize returned ${fr.status}`);
          finalized=fd;
        }catch(err){finalizeError=err;if(attempt===0)await new Promise(r=>setTimeout(r,650));}
      }
    }
    const cycleCount=Number(finalized?.major_luck_cycles_created||0);
    const skipped=Number(finalized?.major_luck_cycles_skipped||0);
    const cycleText=(cycleCount||skipped)?` · Major Luck ${cycleCount} created${skipped?`, ${skipped} already present`:''}`:'';
    if(finalizeError&&!finalized){
      $('#save-message').textContent=`✓ Core chart saved safely. Secondary audit/Luck records did not finish: ${finalizeError.message}. Press Save again only after refreshing; the core chart is already in Notion.`;
    }else{
      $('#save-message').textContent=`✓ Saved to My Saju Journal${data.person_reused?' · existing Person updated':' · Person created'}${cycleText}.`;
    }
    await ensureProfiles(true);
    const savedPersonId=data.person?.id||'';
    if(savedPersonId){
      editingProfileId=savedPersonId;
      const saved=profileCache.find(p=>p.id===savedPersonId);
      if(saved){
        if(data.chart?.id)saved.primary_chart_id=data.chart.id;
        await setActiveProfile(saved,{loadChart:true,persist:true,silent:true});
      }
    }
  }catch(e){
    $('#save-message').textContent=`Save failed: ${e.message}`;
  }finally{
    b.disabled=!$('#verified-check').checked;b.textContent='Save Verified Chart to Notion';
  }
});

function requireAppKey(messageTarget){const key=connectionKey();if(!key){if(messageTarget)messageTarget.textContent='Enter your private connection key under Settings or New Chart → Notion connection first.';switchPage('settings');return null;}return key;}
function apiHeaders(){const key=connectionKey();return key?{'X-Saju-Key':key}:{};}
async function apiJson(url,opts={}){const headers={...(opts.headers||{}),...apiHeaders()};if(opts.body&&!headers['Content-Type'])headers['Content-Type']='application/json';const resp=await fetch(url,{...opts,headers});const data=await resp.json().catch(()=>({}));if(!resp.ok||data.ok===false)throw new Error(data.error||`HTTP ${resp.status}`);return data;}
