"use strict";
/* New Chart form, validation, verification and deterministic-result rendering. */
function formPayload(){const status=selected('time_status')||'exact';return{name:value('name'),nickname:value('nickname'),sex:value('sex'),calendar_type:value('calendar_type')||'Gregorian',birth_date:value('birth_date'),lunar_year:+value('lunar_year'),lunar_month:+value('lunar_month'),lunar_day:+value('lunar_day'),lunar_leap_month:value('lunar_leap_month')==='leap',birth_time:status==='unknown'?null:value('birth_time'),time_status:status,uncertainty_minutes:+(value('uncertainty_minutes')||30),place:value('place'),latitude:+value('latitude'),longitude:+value('longitude'),timezone:value('timezone'),use_true_solar_time:checked('use_true_solar_time'),day_boundary:value('day_boundary'),luck_direction:value('luck_direction'),boundary_safety_minutes:+(value('boundary_safety_minutes')||120),daewoon_cycles:8};}
form.addEventListener('change',e=>{if(e.target.name==='time_status'){const s=selected('time_status');$('#uncertainty-wrap').classList.toggle('hidden',s!=='approximate');form.elements.birth_time.disabled=s==='unknown';form.elements.birth_time.required=s!=='unknown';}});
function applyLocationMatch(index){
  const x=locationMatches[index]; if(!x)return;
  form.elements.latitude.value=Number(x.latitude).toFixed(6);
  form.elements.longitude.value=Number(x.longitude).toFixed(6);
  form.elements.timezone.value=x.timezone||'';
  const label=[x.name,x.admin1,x.country].filter(Boolean).join(', ');
  $('#place-message').textContent=`Using: ${label} · ${x.timezone||'timezone unavailable'}`;
}
$('#lookup-place').addEventListener('click',async()=>{
  const q=value('place');if(!q)return;
  const b=$('#lookup-place');b.disabled=true;b.textContent='Finding…';
  $('#place-message').textContent='Searching…'; $('#location-choice-wrap').classList.add('hidden');
  try{
    const r=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=8&language=en&format=json`);
    const j=await r.json(); locationMatches=j.results||[];
    if(!locationMatches.length)throw new Error('Location not found');
    const sel=$('#location-choice');
    sel.innerHTML=locationMatches.map((x,i)=>`<option value="${i}">${esc([x.name,x.admin1,x.country].filter(Boolean).join(', '))} · ${esc(x.timezone||'')}</option>`).join('');
    $('#location-choice-wrap').classList.remove('hidden');
    applyLocationMatch(0);
  }catch(e){
    locationMatches=[]; $('#place-message').textContent=`${e.message}. Enter coordinates and an IANA timezone manually.`;
  }finally{b.disabled=false;b.textContent='Find';}
});
$('#location-choice').addEventListener('change',e=>applyLocationMatch(+e.target.value));

function astronomyCrossCheck(result){
  const A=window.Astronomy;
  if(!A || typeof A.SearchSunLongitude!=='function'){
    return {available:false,status:'offline_or_blocked',message:'Live Astronomy Engine cross-check unavailable; embedded Swiss tables remain the calculation source.'};
  }
  try{
    const checks=[];
    const liEmbedded=new Date(result.astronomy.li_chun_utc);
    const liHit=A.SearchSunLongitude(315,new Date(liEmbedded.getTime()-3*86400000),6);
    if(liHit?.date){
      const diff=(liHit.date.getTime()-liEmbedded.getTime())/60000;
      checks.push({name:'Ipchun',embedded_utc:liEmbedded.toISOString(),astronomy_engine_utc:liHit.date.toISOString(),difference_minutes:+diff.toFixed(3)});
    }
    for(const which of ['previous','next']){
      const b=result.astronomy.month_boundaries[which];
      const emb=new Date(b.utc);
      const hit=A.SearchSunLongitude(+b.longitude,new Date(emb.getTime()-3*86400000),6);
      if(hit?.date){
        const diff=(hit.date.getTime()-emb.getTime())/60000;
        checks.push({name:`Month boundary ${which}`,longitude:+b.longitude,embedded_utc:emb.toISOString(),astronomy_engine_utc:hit.date.toISOString(),difference_minutes:+diff.toFixed(3)});
      }
    }
    const max=Math.max(0,...checks.map(x=>Math.abs(x.difference_minutes)));
    return {available:true,status:max<=2?'match':'review',max_difference_minutes:+max.toFixed(3),checks,message:max<=2?'Live Astronomy Engine agrees with embedded Swiss boundaries within 2 minutes.':'Cross-check differs by more than 2 minutes; review a boundary-sensitive chart.'};
  }catch(e){
    return {available:true,status:'error',message:`Astronomy Engine cross-check failed: ${e.message}`};
  }
}

form.addEventListener('submit',async e=>{e.preventDefault();errorBox.classList.add('hidden');const btn=form.querySelector('button[type="submit"]');btn.disabled=true;btn.textContent='Calculating…';try{const input=formPayload();
      let calendarConversion={original_calendar_type:'Gregorian',original_birth_date:input.birth_date,normalised_gregorian_date:input.birth_date,conversion_method:'identity-gregorian-v1',conversion_version:'1'};
      if(input.calendar_type==='Lunar'){
        const converted=await apiJson('/api/calendar/lunar-to-solar',{method:'POST',body:JSON.stringify({year:input.lunar_year,month:input.lunar_month,day:input.lunar_day,leap_month:input.lunar_leap_month})});
        calendarConversion=converted.calendar_conversion; input.birth_date=calendarConversion.normalised_gregorian_date;
      }
      lastResult=calculateChart(input);
      if(calendarConversion.original_calendar_type==='Lunar'){lastResult.birth.normalised_gregorian_date=calendarConversion.normalised_gregorian_date;lastResult.birth.original_calendar_type='Lunar';lastResult.birth.original_lunar_date=calendarConversion.original_birth_date;lastResult.birth.original_date=calendarConversion.original_birth_date;}
      lastResult.input_calendar=input.calendar_type; lastResult.calendar_conversion=calendarConversion;
      const phase1=globalThis.SajuPhase1.analyze(lastResult,readAnalysisSettings());
      lastResult.elements_weighted=phase1.elements; lastResult.weighted_ten_gods=phase1.ten_gods; lastResult.strength=phase1.strength; lastResult.chart_strength_result=phase1.strength;const phase2=globalThis.SajuPhase2.analyze(lastResult,{strength:phase1.strength});lastResult.useful_element=phase2.useful_element;lastResult.favourable_element=phase2.favourable_element;lastResult.unfavourable_element=phase2.unfavourable_element;lastResult.symbolic_stars=phase2.symbolic_stars;lastResult.twelve_stars=phase2.twelve_stars;lastResult.input_calendar=input.calendar_type;lastResult.analysis_settings=readAnalysisSettings();lastResult.method_registry=METHOD_REGISTRY;lastResult.result_schema_version=RESULT_SCHEMA_VERSION;lastResult.analysis_version=ANALYSIS_VERSION;lastResult.external_crosscheck=astronomyCrossCheck(lastResult);render(lastResult);$('#results').classList.remove('hidden');$('#results').scrollIntoView({behavior:'smooth',block:'start'});}catch(err){errorBox.textContent=err.message;errorBox.classList.remove('hidden');}finally{btn.disabled=false;btn.textContent='Calculate chart';}});

function render(r){r.analysis_settings=r.analysis_settings||{...DEFAULT_ANALYSIS_SETTINGS};renderVerification(r);renderPillars(r.pillars);renderDayMaster(r.day_master,r.five_elements);renderTenGodAnalysis(r.pillars);renderRelationships(r.relationships);renderAdvancedAnalysis(r);renderPhase1Analysis(r);renderVoid(r.void);renderDaewoon(r.daewoon);$('#audit').textContent=JSON.stringify(r,null,2);$('#save-message').textContent='';$('#verified-check').checked=false;$('#send-webhook').disabled=true;}
function renderVerification(r){
  const b=r.birth,a=r.astronomy,c=r.boundary_check,x=r.external_crosscheck||{};
  const xLabel=!x.available?'Offline cross-check':(x.status==='match'?`Match · ≤${Number(x.max_difference_minutes||0).toFixed(2)} min`:(x.status==='review'?`Review · ${Number(x.max_difference_minutes||0).toFixed(2)} min`:'Cross-check error'));
  const items=[
    ['Recorded',`${b.original_date} ${b.original_time||'time unknown'}`],
    ['Input calendar',r.input_calendar||'Gregorian'],
    ...(r.calendar_conversion?.original_calendar_type==='Lunar'?[['Normalised Gregorian',r.calendar_conversion.normalised_gregorian_date],['Lunar leap month',r.calendar_conversion.lunar_leap_month?'Yes':'No'],['Conversion method',r.calendar_conversion.conversion_method]]:[]),
    ['Timezone',`${b.iana_timezone} · UTC ${b.historical_utc_offset_minutes>=0?'+':''}${(b.historical_utc_offset_minutes/60).toFixed(2)}`],
    ['Resolved UTC',fmtTime(b.resolved_utc)],
    ['Corrected solar',fmtTime(b.corrected_solar_local)],
    ['Solar correction',`${Number(b.solar_correction.total_clock_to_solar_minutes).toFixed(1)} min`],
    ['Ipchun boundary',fmtTime(a.li_chun_utc)],
    ['Solar longitude',`${Number(a.solar_longitude_degrees_approx).toFixed(5)}° (display only)`],
    ['Live ephemeris check',xLabel],
    ['Engine',`v${r.engine.version} · ForceTeller validation pending`]
  ];
  $('#verification-grid').innerHTML=items.map(([k,v])=>`<div class="verify-item"><b>${esc(k)}</b><span>${esc(v)}</span></div>`).join('');
  const ws=[...(c.warnings||[])];
  if(x.available&&x.status==='review')ws.push('LIVE EPHEMERIS CROSS-CHECK DIFFERENCE > 2 MIN');
  const approx=r.time_uncertainty_variants?.length?`<div class="warning-soft" style="margin-top:10px"><b>Approximate-time variants</b><br>${r.time_uncertainty_variants.map(v=>`${esc(v.offset_minutes>0?'+':'')}${esc(v.offset_minutes)} min → Day ${esc(v.day)} · Hour ${esc(v.hour)} · corrected ${esc(v.effective_time)}`).join('<br>')}<br><b>${r.boundary_check?.boundary_sensitive?'Hour/Day result may be uncertain across the entered range.':'No pillar change detected across the entered range.'}</b></div>`:''; $('#warnings').innerHTML=(ws.length?`<div class="warning-list">${ws.map(z=>`<span class="warning-chip">⚠ ${esc(z)}</span>`).join('')}</div>`:`<div class="warning-list"><span class="ok-chip">✓ No boundary warnings in the selected safety window</span></div>`)+approx;
}
function pillarCard(name,p){if(!p)return`<article class="pillar"><div class="pillar-name">Hour</div><p class="empty">Birth time unknown — hour pillar not invented.</p></article>`;const s=p.stem,b=p.branch,roles=b.hidden_stems.length===1?['Main']:b.hidden_stems.length===2?['Main','Residual']:['Main','Middle','Residual'],hidden=b.hidden_stems.map((x,i)=>`<b>${roles[i]||'Hidden'}:</b> ${x.hanja} ${x.roman} · ${x.element} · ${x.yin_yang} · ${accessibleTenGodNameUI(x.ten_god)}`).join('<br>');return`<article class="pillar ${name==='day'?'day':''}"><div class="pillar-name">${esc(name)}</div><div class="stem"><div class="char ${elemClass(s.element)}">${esc(s.hanja)}</div><div class="meta"><strong>${esc(s.roman)} · ${esc(s.element)}</strong><small>${esc(s.yin_yang)}</small><div class="ten-god">${esc(accessibleTenGodNameUI(s.ten_god))}</div></div></div><div class="branch"><div class="char ${elemClass(b.element)}">${esc(b.hanja)}</div><div class="meta"><strong>${esc(b.roman)} · ${esc(b.animal)}</strong><small>${esc(b.element)} · ${esc(b.yin_yang)}</small></div></div><div class="hidden-stems"><strong>Hidden stems</strong><br>${hidden||'—'}</div><div class="growth">12 Growth Stage: ${esc(p.growth_stage.en)} · ${esc(p.growth_stage.ko)}</div></article>`;}
function renderPillars(p){$('#pillars').innerHTML=['hour','day','month','year'].map(k=>pillarCard(k,p[k])).join('');}
function rawTenGodDistribution(pillars){
  const counts=Object.fromEntries(Object.keys(TEN_GODS).map(k=>[k,0]));
  const contributors=[];
  Object.entries(pillars||{}).forEach(([pos,p])=>{if(!p)return;if(pos!=='day'&&p.stem?.ten_god?.key&&counts[p.stem.ten_god.key]!=null){counts[p.stem.ten_god.key]++;contributors.push({source:`${pos} stem`,key:p.stem.ten_god.key});}(p.branch?.hidden_stems||[]).forEach((h,i)=>{if(h.ten_god?.key&&counts[h.ten_god.key]!=null){counts[h.ten_god.key]++;contributors.push({source:`${pos} hidden ${i+1}`,key:h.ten_god.key});}})});
  const total=Object.values(counts).reduce((a,b)=>a+b,0)||1;return{counts,total,contributors};
}
function renderDayMaster(dm,five){
  const preferred=accessibleStemNameUI(dm.hanja)||`${dm.yin_yang} ${dm.element}`;$('#day-master').innerHTML=`<div class="daymaster"><div class="char ${elemClass(dm.element)}">${esc(dm.hanja)}</div><div><strong>${esc(preferred)}</strong><div class="micro">${esc(dm.hanja)} · ${esc(dm.yin_yang)} ${esc(dm.element)} · ${esc(dm.roman)} · Day Master / 일간 · 日干</div></div></div>`;
  const counts=five.combined_unweighted_presence,max=Math.max(...Object.values(counts),1);
  $('#elements').innerHTML=`<p class="micro"><strong>Raw Element Presence</strong> — unweighted counts, not strength percentages.</p><div class="bars">${Object.entries(counts).map(([e,n])=>`<div class="bar-row"><b>${esc(e)}</b><div class="bar"><i style="width:${n/max*100}%"></i></div><span>${n}</span></div>`).join('')}</div>`;
  $('#element-visual').innerHTML=`<div class="element-cycle">${Object.entries(counts).map(([e,n])=>`<div class="element-tile ${elemClass(e)}"><b>${esc(e)}</b><strong>${n}</strong></div>`).join('')}</div><p class="micro">Generating: Wood → Fire → Earth → Metal → Water → Wood<br>Controlling: Wood → Earth → Water → Fire → Metal → Wood</p>`;
}
function renderTenGodAnalysis(pillars){const d=rawTenGodDistribution(pillars);const rows=Object.entries(TEN_GODS).map(([k,t])=>{const n=d.counts[k],pct=n/d.total*100;return`<div class="bar-row" style="grid-template-columns:150px 1fr 50px"><b>${esc(accessibleTenGodNameUI(t))}</b><div class="bar"><i style="width:${pct}%"></i></div><span>${n} · ${pct.toFixed(0)}%</span></div>`}).join('');$('#ten-god-analysis').innerHTML=`<p class="micro"><strong>Raw occurrences</strong> across visible non-Day stems + all listed Hidden Stems. Percentages are raw count share only, not weighted strength.</p><div class="bars">${rows}</div>`;}
const RELATION_LABELS={stem_combinations:'Stem Combination',six_combinations:'Six Combination · 육합',three_harmony:'Three Harmony · 삼합',directional:'Directional · 방합',clashes:'Clash · 충',punishments:'Punishment · 형',breaks:'Break · 파',harms:'Harm · 해',wonjin:'Wonjin · 원진'};
let activeRelationshipTab='all';
function renderRelationships(rel){const keys=Object.keys(RELATION_LABELS);$('#relationship-tabs').innerHTML=`<button type="button" class="chip ${activeRelationshipTab==='all'?'active':''}" data-rel-tab="all">All</button>`+keys.map(k=>`<button type="button" class="chip ${activeRelationshipTab===k?'active':''}" data-rel-tab="${k}">${esc(RELATION_LABELS[k].split(' · ')[0])}</button>`).join('');const show=activeRelationshipTab==='all'?keys:[activeRelationshipTab];$('#relationships').innerHTML=show.map(k=>{const list=rel[k]||[],tags=list.map(x=>{const mem=(x.stems||x.branches||[]).join(' · '),src=x.pillars?` (${x.pillars.join('–')})`:'',el=x.traditional_transform_element||x.element||x.resulting_element;return`<span class="tag"><b>${esc(mem)}</b>${esc(src)}${el?` → ${esc(el)}${x.transformation_evaluated===false?' (transformation not asserted)':''}`:''}</span>`}).join('');return`<div class="relation-group"><h3>${esc(RELATION_LABELS[k])}</h3>${tags||'<span class="empty">None detected</span>'}</div>`}).join('');document.querySelectorAll('[data-rel-tab]').forEach(b=>b.onclick=()=>{activeRelationshipTab=b.dataset.relTab;renderRelationships(rel);});}
function renderAdvancedAnalysis(r){
  const st=r.analysis_settings||DEFAULT_ANALYSIS_SETTINGS,u=r.useful_element||{},f=r.favourable_element||{},un=r.unfavourable_element||{},stars=r.symbolic_stars||{},twelve=r.twelve_stars||{};
  const resultText=x=>x?.english||x?.element||x||'—';
  const unf=Array.isArray(un.result)?un.result.map(resultText).join(', '):resultText(un.result);
  const starCards=(stars.detected||[]).length?(stars.detected||[]).map(x=>`<div class="luck-card"><b>${esc(x.star)}</b><div>${esc(x.korean||'')} · ${esc(x.hanja||'')}</div><div class="micro">${esc((x.detected_in||[]).join(', '))}<br>Reference: ${esc(x.reference_basis||'')} ${esc(x.reference_value||'')}<br>${esc(x.method_version||'')}</div><details><summary>?</summary><div class="details-body"><b>Technical definition</b><p class="micro">Deterministic Symbolic Star detected from the active versioned trigger table.</p><b>Korean / Hanja</b><p class="micro">${esc(x.korean||'')} · ${esc(x.hanja||'')}</p><b>Trigger rule</b><p class="micro">${esc(x.trigger||'')}</p><b>Where it occurs</b><p class="micro">${esc((x.detected_in||[]).join(', '))}</p><div class="warning-soft"><b>General traditional interpretation</b><br>${esc(x.traditional_interpretation||'Traditional interpretation varies by school and context.')}</div><button type="button" class="chip" data-concept="${esc(x.star)}">Open related Saju Concept / research</button></div></details></div>`).join(''):'<div class="empty">No enabled Symbolic Stars detected in this natal chart.</div>';
  const starByPillar=pos=>(stars.detected||[]).filter(x=>(x.result_positions||[]).some(r=>r.pillar===pos)).map(x=>x.star).filter((x,i,a)=>a.indexOf(x)===i).join(', ')||'—';
  const starGrid=`<table class="compat-table"><thead><tr><th></th><th>Hour</th><th>Day</th><th>Month</th><th>Year</th></tr></thead><tbody><tr><th>Stem Stars</th><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><th>Branch Stars</th>${['hour','day','month','year'].map(pos=>`<td>${esc(starByPillar(pos))}</td>`).join('')}</tr></tbody></table>`;
  const twelveCards=['hour','day','month','year'].map(pos=>{const x=twelve.pillars?.[pos];return x?`<div class="luck-card"><small>${esc(pos)}</small><b>${esc(x.name)}</b><div>${esc(x.korean)} · ${esc(x.hanja)}</div><div class="micro">${esc(x.branch||'')} · ${esc(x.method_version||'')}</div><button type="button" class="chip" data-concept="Twelve Stars">?</button></div>`:''}).join('');
  $('#advanced-analysis').innerHTML=`
    <div id="strength-phase1-host" class="pending-box"><b>Chart Strength</b> <span class="method-status">Calculated · Phase 1</span><br>Deterministic strength result loads below.</div>
    <div class="card-clean" style="margin-top:12px"><h3>Useful / Favourable / Unfavourable Elements</h3>
      <div class="verification-grid"><div class="verify-item"><b>Useful Element · 용신 用神</b><span>${esc(resultText(u.result))} ${esc(u.result?.korean||'')} ${esc(u.result?.hanja||'')} <button type="button" class="chip" data-concept="Useful Element">?</button></span></div><div class="verify-item"><b>Favourable Element · 희신 喜神</b><span>${esc(resultText(f.result))} ${esc(f.result?.korean||'')} ${esc(f.result?.hanja||'')} <button type="button" class="chip" data-concept="Favourable Element">?</button></span></div><div class="verify-item"><b>Unfavourable Element · 기신 忌神</b><span>${esc(unf)} <button type="button" class="chip" data-concept="Unfavourable Element">?</button></span></div><div class="verify-item"><b>Method</b><span>${esc(u.method||METHOD_REGISTRY.useful_element)}</span></div></div>
      ${u.provisional?'<div class="warning-soft"><b>Provisional.</b> Phase 1 strength was a workbook borderline case decided by the Month Branch.</div>':''}
      <details><summary>How was this calculated?</summary><div class="details-body"><p class="micro">These are deterministic workbook-method factors, not AI prose.</p><pre>${esc(JSON.stringify({useful:u.factors||u.reasoning_data||[],favourable:f.factors||[],unfavourable:un.factors||[]},null,2))}</pre></div></details>
    </div>
    <div style="margin-top:14px"><h3>Void & Twelve Growth Stages</h3><p class="micro">These established deterministic modules are shown here for Advanced-screen context and remain unchanged.</p><div class="verification-grid"><div class="verify-item"><b>Void · 공망</b><span>${esc((r.void?.void_branches||[]).map(x=>x.hanja||x.roman||x).join(', ')||'None')}</span></div><div class="verify-item"><b>Twelve Growth Stages · 십이운성</b><span>${esc(['hour','day','month','year'].filter(p=>r.pillars?.[p]).map(p=>`${p}: ${r.pillars[p].growth_stage?.en||'—'}`).join(' · '))}</span></div></div></div>
    <div style="margin-top:14px"><h3>Symbolic Stars · 신살</h3><p class="micro"><b>Method:</b> ${esc(stars.method||METHOD_REGISTRY.symbolic_stars)}. Only the four explicitly enabled rule tables are calculated; other named stars are not inferred.</p>${starGrid}<div class="annual-row" style="margin-top:10px">${starCards}</div><details><summary>How were Symbolic Stars calculated?</summary><div class="details-body"><pre>${esc(JSON.stringify({enabled_rules:stars.enabled_rules||[],detected:stars.detected||[],notes:stars.methodological_notes||[]},null,2))}</pre></div></details></div>
    <div style="margin-top:14px"><h3>Twelve Stars · 십이신살</h3><div class="warning-soft"><b>Separate system.</b> This is not Twelve Growth Stages · 십이운성, which remains unchanged elsewhere in the chart.</div><p class="micro"><b>Method:</b> ${esc(twelve.method||METHOD_REGISTRY.twelve_stars)} · Reference: ${esc(twelve.reference_basis||'')} ${esc(twelve.reference_value||'')}</p><div class="annual-row">${twelveCards||'<div class="empty">Twelve Stars unavailable.</div>'}</div><details><summary>How were Twelve Stars calculated?</summary><div class="details-body"><pre>${esc(JSON.stringify(twelve,null,2))}</pre></div></details></div>
    <details style="margin-top:12px"><summary>Analysis settings</summary><div class="details-body"><label class="toggle"><input id="setting-transform" type="checkbox" disabled/> Apply combination transformations <small>(inactive — no validated formula)</small></label><label class="toggle"><input id="setting-seasonal" type="checkbox" disabled/> Seasonal numerical adjustment <small>(inactive — Month Branch importance is used in the sourced strength tiebreak)</small></label><label class="toggle"><input id="setting-palace" type="checkbox" disabled/> Palace/position weighting <small>(inactive — no validated numerical formula)</small></label><label class="toggle"><input id="setting-hidden" type="checkbox" ${st.hidden_stem_weighting!==false?'checked':''}/> Include Hidden Stem allocation <small>(Phase 1 weighted analysis)</small></label></div></details>
    <p class="micro">Active methods: ${esc(METHOD_REGISTRY.chart_strength)} · ${esc(METHOD_REGISTRY.useful_element)} · ${esc(METHOD_REGISTRY.symbolic_stars)} · ${esc(METHOD_REGISTRY.twelve_stars)}</p>`;
}

function renderPhase1Analysis(r){
  const elements=r.elements_weighted, ten=r.weighted_ten_gods, strength=r.chart_strength_result||r.strength;
  if(elements){
    const rows=Object.entries(elements.elements||{}).map(([name,x])=>`<div class="bar-row" style="grid-template-columns:90px 1fr 72px"><b>${esc(name)}</b><div class="bar"><i style="width:${Math.max(0,Math.min(100,Number(x.percentage||0)))}%"></i></div><span>${Number(x.percentage||0).toFixed(1)}%</span></div>`).join('');
    const details=`<details style="margin-top:10px"><summary>How was Weighted Element Strength calculated?</summary><div class="details-body"><p class="micro"><b>Method:</b> ${esc(elements.method)}. Each visible Heavenly Stem has weight 1. Each Earthly Branch has total weight 1. With Hidden Stem allocation enabled, that branch weight is divided equally across its encoded Hidden Stems. No numerical seasonal, palace or combination-transformation multiplier is applied in Phase 1.</p><pre>${esc(JSON.stringify(elements.contributors||[],null,2))}</pre></div></details>`;
    $('#element-visual').insertAdjacentHTML('beforeend',`<div id="weighted-element-phase1" style="margin-top:14px"><h3>Weighted Element Strength</h3><p class="micro">Separate from Raw Element Presence · total reproducible weight ${Number(elements.total_weight||0).toFixed(3)}</p><div class="bars">${rows}</div>${details}</div>`);
  }
  if(ten){
    const rows=Object.values(ten.distribution||{}).filter(x=>Number(x.weighted_score||0)>0||Number(x.raw_occurrences||0)>0).map(x=>`<div class="bar-row" style="grid-template-columns:160px 1fr 72px"><b>${esc(x.name?.en||'')}</b><div class="bar"><i style="width:${Math.max(0,Math.min(100,Number(x.percentage||0)))}%"></i></div><span>${Number(x.percentage||0).toFixed(1)}%</span></div>`).join('');
    $('#ten-god-analysis').insertAdjacentHTML('beforeend',`<div id="weighted-ten-phase1" style="margin-top:14px"><h3>Weighted Ten God Distribution</h3><p class="micro">Method ${esc(ten.method)} · uses exactly the same deterministic contributors as Weighted Five Elements.</p><div class="bars">${rows}</div><details style="margin-top:10px"><summary>How was this calculated?</summary><div class="details-body"><pre>${esc(JSON.stringify(ten.contributors||[],null,2))}</pre></div></details></div>`);
  }
  const host=$('#strength-phase1-host');
  if(host&&strength){
    if(strength.status!=='calculated'){
      host.innerHTML=`<b>Chart Strength</b> <span class="method-status">Unavailable</span><br>${esc(strength.reason||'All eight visible characters are required.')}`;
    }else{
      const pct=Math.max(0,Math.min(100,Number(strength.strength_index||0)));
      host.innerHTML=`<b>Chart Strength</b> <span class="method-status">${esc(strength.classification)}</span><div style="margin:10px 0"><div class="bar" style="height:14px;position:relative"><i style="width:${pct}%"></i><span style="position:absolute;left:${pct}%;top:-4px;transform:translateX(-50%);font-size:18px">●</span></div><div class="micro" style="display:flex;justify-content:space-between"><span>Drain</span><span>Support</span></div></div><div class="verification-grid"><div class="verify-item"><b>Strength Index</b><span>${pct.toFixed(1)}%</span></div><div class="verify-item"><b>Support / Drain</b><span>${strength.support_score} / ${strength.drain_score}</span></div><div class="verify-item"><b>Month Branch</b><span>${esc(strength.month_branch_role||'—')} · ${esc(strength.month_branch_effect||'—')}</span></div><div class="verify-item"><b>Method</b><span>${esc(strength.method)}</span></div></div>${strength.borderline?'<div class="warning-soft" style="margin-top:9px"><b>Borderline workbook case.</b> The Month Branch main qi is used as the deciding factor.</div>':''}<p class="micro">${esc(strength.decision_rule||'')}</p><details><summary>How was this calculated?</summary><div class="details-body"><pre>${esc(JSON.stringify({thresholds:strength.thresholds,role_counts:strength.role_counts,breakdown:strength.breakdown},null,2))}</pre></div></details>`;
    }
  }
  const hidden=$('#setting-hidden');
  if(hidden&&!hidden.dataset.bound){hidden.dataset.bound='1';hidden.addEventListener('change',()=>{if(!lastResult)return;const settings=readAnalysisSettings(),phase=globalThis.SajuPhase1.analyze(lastResult,settings);lastResult.elements_weighted=phase.elements;lastResult.weighted_ten_gods=phase.ten_gods;lastResult.strength=phase.strength;lastResult.chart_strength_result=phase.strength;const p2=globalThis.SajuPhase2.analyze(lastResult,{strength:phase.strength});Object.assign(lastResult,p2);lastResult.analysis_settings=settings;render(lastResult);});}
}

function renderVoid(v){const branches=v.void_branches.map(x=>`${x.hanja} ${x.roman} (${x.animal})`).join(' · '),hits=v.natal_hits.length?v.natal_hits.join(', '):'None';$('#void').innerHTML=`<p><strong>Void branches:</strong> ${esc(branches)}</p><p><strong>Natal hits:</strong> ${esc(hits)}</p>`;}
function renderDaewoon(d){if(d.status!=='calculated'){$('#daewoon').innerHTML=`<p class="empty">${esc(d.reason||'Luck-cycle methodology input required.')}</p><p class="micro">${esc(d.method||'')}</p>`;return;}$('#daewoon').innerHTML=`<p class="micro"><strong>Direction: ${esc(d.direction)}</strong> · Major Luck Start Age ${Number(d.start_age_years).toFixed(2)} · ${esc(d.method)}<br>Days to sectional term: ${Number(d.days_to_sectional_term||0).toFixed(3)}</p><div class="luck-list">${d.cycles.map(c=>`<div class="luck-row" style="grid-template-columns:54px 1fr 110px"><div class="age">${Number(c.start_age).toFixed(1)}–${Number(c.end_age).toFixed(1)}</div><strong>${esc(c.stem.hanja)}${esc(c.branch.hanja)} · ${esc(c.stem.roman)}-${esc(c.branch.roman)}<small style="display:block;font-family:Inter;font-size:10px;color:#88756c">${esc(c.branch.animal)} · ${esc(c.branch.element)} · ${esc(c.growth_stage?.en||'')}</small></strong><span>${esc(accessibleTenGodNameUI(c.ten_god))}</span></div>`).join('')}</div>`;}
