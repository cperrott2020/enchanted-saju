"use strict";
/* Shared runtime state. Feature modules mutate only the state they own. */
let lastResult=null;
let locationMatches=[];
let selectedPerson=null, selectedChartId=null, selectedChartData=null, editingProfileId=null, profileCache=[], glossaryCache=[], researchOriginalFile=null, researchDraft={analysis:null,source_text:'',title:'',url:'',source_type:'Other'}, peopleFilter='All', researchLibraryCache=[];
let activeProfile=null, activeChartTab='overview', selectedElement=null, interactionDetailIndex=null;
let readingLevel=storageGet(STORAGE_KEYS.readingLevel,'beginner');
const ACTIVE_PROFILE_KEY=STORAGE_KEYS.activeProfile;
const PILLAR_ORDER=['hour','day','month','year'];
const PILLAR_LABEL={hour:'Hour',day:'Day',month:'Month',year:'Year'};
const ELEMENT_META={Wood:['🌳','목','木'],Fire:['🔥','화','火'],Earth:['🪨','토','土'],Metal:['⚙','금','金'],Water:['💧','수','水']};
const JOURNAL_TAGS=['Work','Study','Relationship','Family','Health','Travel','Creativity','Money','Social','Rest'];
let journalSelectedTags=new Set(), calendarFilters={animals:false,elements:true,ten_gods:true,interactions:false,journal:true,events:false},lastCalendarData=null;
let knowledgePackCache=null;
const KNOWLEDGE_QUEUE_STATE_KEY=STORAGE_KEYS.knowledgeQueue;
let knowledgeImportRunning=false,knowledgeImportStopRequested=false;
