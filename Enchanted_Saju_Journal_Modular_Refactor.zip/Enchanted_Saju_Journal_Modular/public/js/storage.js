"use strict";
/* Shared browser-storage interface. Existing storage key strings are preserved. */
const STORAGE_KEYS=Object.freeze({
  connection:'sajuCloudflareSaveKey',
  profileCategory:'sajuProfileCategory',
  dailyTimezone:'sajuDailyTimezone',
  readingLevel:'sajuReadingLevel',
  activeProfile:'enchantedSajuActiveProfileId',
  knowledgeQueue:'enchantedSajuKnowledgeQueueV2'
});
function storageGet(key,fallback=''){try{const v=localStorage.getItem(key);return v===null?fallback:v;}catch{return fallback;}}
function storageSet(key,value){try{localStorage.setItem(key,String(value));return true;}catch{return false;}}
function storageGetJson(key,fallback={}){try{return JSON.parse(localStorage.getItem(key)||'null')??fallback;}catch{return fallback;}}
function storageSetJson(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
