"use strict";
/* Main entry point: final bindings and initial page state. */

renderReadingLevelControls();
const calendarSelect=document.querySelector('[name="calendar_type"]');
function syncCalendarInputs(){const lunar=calendarSelect?.value==='Lunar';document.getElementById('lunar-inputs')?.classList.toggle('hidden',!lunar);const bd=document.querySelector('[name="birth_date"]');if(bd){bd.disabled=!!lunar;bd.required=!lunar;}for(const n of ['lunar_year','lunar_month','lunar_day']){const el=document.querySelector('[name="'+n+'"]');if(el)el.required=!!lunar;}}
calendarSelect?.addEventListener('change',syncCalendarInputs);syncCalendarInputs();

// Default to Today, while keeping the calculator one click away.
switchPage('today');
