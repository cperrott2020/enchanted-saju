"use strict";
/* Public compatibility interface for future feature work.
   Existing code keeps its migration-safe ordered-script bindings; this namespace
   provides clear module boundaries without changing calculation behaviour. */
globalThis.EnchantedSaju={
  modules:{
    storage:{STORAGE_KEYS,storageGet,storageSet,storageGetJson,storageSetJson},
    calculator:{calculateChart,sexagenaryIndex,tenGod,monthBoundaryInfo,liChunMs,trueSolar},
    ui:{switchPage,sjpjTypeRecordUI,accessibleJiaziNameUI,accessibleTenGodNameUI},
    notion:{apiJson,connectionKey,notionPayload},
    profiles:{ensureProfiles,setActiveProfile,loadSavedChart,renderPeopleList},
    readings:{previewActiveToday,renderChartTab,renderReadingLevelControls},
    calendar:{loadCalendarMonth,renderCalendarData},
    journal:{loadJournal,loadJournalDay,loadJournalAnalytics},
    compare:{prepareComparePage,renderComparison},
    glossary:{loadConcepts,openConceptLearning},
    research:{loadResearchLibrary,loadKnowledgePackStatus,runKnowledgeImport},
    audit:{loadChartNotes},
    jiazi:{loadJiaziReference,renderJiazi},
    timeline:{loadTimelinePage}
  }
};
