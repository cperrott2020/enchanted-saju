# Enchanted Saju — Update 2 Changelog

## Added

- Profile-aware Today dashboard and Daily Energy hero
- explicit Natal → Major → Annual → Monthly → Daily calculation layers
- evidence cards for deterministic daily-to-natal interactions
- saved AI Daily Reading rendered as a clearly labelled interpretation layer
- Month View calendar with optional Animals, Elements, Ten Gods, Interactions, Journal and Important Event overlays
- Year View for all 12 Saju solar months
- profile-safe Daily Journal editor
- Mood, Energy, Productivity, Social Energy and Stress ratings
- Resonance, Highlights, Challenges and Custom Tags
- descriptive Journal Analytics with minimum sample threshold
- Life Timeline based on saved Major Luck records
- user-recorded Life Events with category/date/description/related journal link
- 60-Jiazi technical reference + explicitly non-doctrinal Journal Symbolism
- Update 2 Notion connection checks

## Preserved

- all Update 1 Active/Default Profile behaviour
- v1.7 Four Pillars engine
- Phase 1 weighted analysis and Chart Strength
- Phase 2 Useful Elements, Symbolic Stars and Twelve Stars
- Daily Luck deterministic engine
- Today Notion mirroring
- Workers AI write boundary

No deterministic Saju methodology was changed in Update 2.
