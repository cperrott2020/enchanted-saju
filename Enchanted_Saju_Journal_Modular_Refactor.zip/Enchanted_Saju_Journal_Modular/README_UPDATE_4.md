# Enchanted Saju — Update 4
## Knowledge identity, terminology, source provenance and searchable 60 SJPJ Types

Update 4 continues directly from **Update 3.2**. It is an in-place upgrade for the same Cloudflare Worker and the same Notion workspace.

### What changed

- Added permanent canonical concept identities so alternate names resolve to one concept instead of fragmenting the glossary.
- Added alias-aware Glossary search across English, Hangul, Hanja, romanisation, source-specific terminology and approved metaphors.
- Added JewelSJPJ-first beginner terminology for the Ten Heavenly Stems while retaining the technical identity underneath it.
- Added all **60 SJPJ Types** as canonical, searchable Stem–Branch reference concepts.
- Updated Today, My Saju, Calendar, Journal, People, Comparison and beginner-facing chart displays to prefer the accessible SJPJ labels where available.
- Updated AI-facing terminology so accessible names are used first while deterministic technical values remain locked.
- Added source-specific alias provenance so the app can preserve which source uses which term.
- Added an **Initial Knowledge Source Pack** importer in Research.
- Added private indexed-source retrieval for natal interpretation: short relevant source extracts can be supplied to AI as interpretive context, but they cannot override calculated chart values.
- Added import status reporting, including failed/inaccessible pages, manual-review flags and duplicate-URL reporting.

### What did NOT change

The deterministic Saju engine is unchanged. Update 4 does not alter Four Pillars, solar terms, lunar conversion, weighted elements, weighted Ten Gods, chart strength, Useful Element, Symbolic Stars, Twelve Stars, Daily Luck, Major Luck or the Update 3.2 split-save architecture.

### Deploy

Use the existing update helper:

- Windows: `update_existing_windows.bat`
- macOS/Linux: `./update_existing_mac_linux.sh`

The helper runs `npm install`, the complete regression suite, and `wrangler deploy` to the **same Worker**.

After deployment, hard-refresh the existing `workers.dev` URL.

### Import the source pack

Open **Research → Initial Knowledge Source Pack → Import / Refresh Pack**.

The importer first ensures the 60 canonical SJPJ Type concepts exist, then processes the source documents one Worker request at a time. This deliberately avoids making one oversized Worker invocation.

The two JewelSJPJ PDFs supplied for this build are embedded privately in the Worker source pack for indexing. Public Qiora, What's My Saju and Saju Atelier pages are retrieved at import time. If a public page cannot actually be retrieved, it is reported as failed/manual review and is **not** falsely marked as ingested.

### Test the identity system

Useful Glossary searches after import include:

- `Black Mist`, `癸`, `계수`, `Gyesu`, `Yin Water`
- `Red Moon Rabbit`, `丁卯`, `정묘`, `Jeong-Myo`, `Yin Fire Rabbit`
- `Direct Officer`, `정관`, `正官`, `Jeonggwan`
- `Friend`, `Peer`, `비견`, `比肩`, `Bigyeon`

Each verified alias should resolve to one canonical concept entry rather than separate duplicate pages.
