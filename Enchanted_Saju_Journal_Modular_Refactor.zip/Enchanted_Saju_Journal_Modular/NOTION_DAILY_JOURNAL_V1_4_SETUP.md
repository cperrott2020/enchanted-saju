# v1.4 · Notion Daily Journal Layout

## What this release does

v1.4 keeps the database properties as the authoritative record and creates a readable page-body presentation underneath them.

The Daily Luck page now has two layers:

### Authoritative properties

These remain the source of truth and are written by deterministic code:

- Date
- Day Stem / Day Branch
- Element / Yin Yang
- Ten God
- Year Pillar / Month Pillar
- Major / Annual / Monthly cycle relations
- Interactions
- Calculation Version

Workers AI still has no path to edit these fields.

### Page-body presentation

The Worker creates one top-level generated callout named **🌸 Daily Saju**. Inside it are:

1. **🔒 Calculated Context** — copied from the deterministic calculation.
2. **🌸 AI Daily Reading** — copied from the Daily Reading interpretation.

Outside that generated callout the Worker creates:

- **☕ Daily Journal**
- **✎ Notes & reflection**

Anything you write in the journal area is kept separate from generated content.

## Safe regeneration behaviour

When calculated context is refreshed, the Worker deletes/recreates only the **🔒 Calculated Context** child block.

When the AI reading is regenerated, the Worker:

1. updates only the `Daily Reading` database property;
2. deletes/recreates only the **🌸 AI Daily Reading** child block.

It does **not** delete the Daily Journal section or your own page-body notes.

## Refresh an entry that already exists

1. Deploy v1.4.
2. Open the calculator.
3. Go to **05 · Daily Luck + AI Journal**.
4. Select the date.
5. Click **Refresh Notion Journal Layout**.
6. Open the supplied Notion link.

This uses the existing Daily Reading if one is already stored. It does not call AI again.

## Today dashboard

Your Daily Luck database now also has an **Is Today** formula property. In the Today linked database view, set a Notion filter:

`Is Today` → `is` → checked/true

That filter automatically follows the current date. The formula uses Notion's `today()` function.

A compact Today view works well with these visible properties:

- Entry
- Day Stem
- Day Branch
- Element
- Animal
- Ten God
- Year Pillar
- Month Pillar
- Reading Match

Open the single row to see the formatted reading and write in the journal area.

## Important rule

Write personal notes under **☕ Daily Journal** or in your Journal/Events/Retrospective database properties. Avoid editing inside the generated **🌸 Daily Saju** callout if you want those edits preserved, because generated sub-blocks are designed to be refreshed.
