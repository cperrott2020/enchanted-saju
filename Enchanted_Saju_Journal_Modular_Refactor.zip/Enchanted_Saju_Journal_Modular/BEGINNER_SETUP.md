# Enchanted Saju Journal v1.7 Complete — Beginner Setup

Existing installation: use `BEGINNER_UPDATE_V1_7_COMPLETE.md` and double-click `update_existing_windows.bat`.

New installation: use `deploy_windows.bat`, then open the workers.dev URL it prints.

Lunar conversion is offline and does not require a KASI API key.
