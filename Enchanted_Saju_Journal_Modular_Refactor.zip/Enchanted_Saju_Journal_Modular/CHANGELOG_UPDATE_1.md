# Enchanted Saju — Update 1 Changelog

## Purpose

Update 1 changes the application from a calculator-centred interface into a saved-profile personal Saju application. The deterministic v1.7 Complete calculation modules are preserved unchanged.

## Saved profiles and Active Profile

- Added a global saved-profile loader backed by the existing Notion `People` and `Charts` data sources.
- Added `Default Profile` support. Setting a default clears the flag from all other profiles so only one profile is default.
- Added persistent browser-side `Active Profile` state keyed by the unique Notion Person page ID, never by display name.
- Profile-selection order on initial load is: explicit Default Profile → last selected profile → first saved profile with a Primary Chart → first saved profile.
- Added profile selectors to My Saju, Today, Calendar and Journal.
- Added profile categories: Me, Partner, Family, Friend and Other.
- Added Sex / Luck Basis and profile notes editing in People.
- Saving a new verified chart refreshes the profile cache and makes the saved Person/Chart the active profile.

## Profile-safe daily data

- Daily Luck duplicate detection is now scoped by both Date and Person relation.
- Every generated Daily Luck record explicitly stores both the Person ID and Chart ID.
- Saved calendar markers are scoped to the selected Chart ID.
- Daily calculate/generate/AI/layout/Today refresh endpoints accept explicit `person_id` and `chart_id`.
- Manual Active Profile selection never changes another profile's natal data.
- Scheduled daily generation resolves the explicit Notion Default Profile first, then uses the legacy Me fallback only when no default exists.

## My Saju redesign

- Added saved-profile Day Master hero and profile/avatar treatment.
- Added central Four Pillars saved-chart view with Day Pillar / Day Master emphasis.
- Added eight tabs: Overview, Five Elements, Ten Gods, Relationships, Advanced, Luck Cycles, Interpretation and Calculation.
- Added Five Element occurrence highlighting across visible stems, branches and Hidden Stems.
- Added deterministic relationship interaction map from stored relationship results.
- Added Beginner, Intermediate and Traditional reading presentation levels. These alter presentation only.
- Added contextual `What does this mean?` help for Ten Gods and enabled Symbolic Stars using actual stored chart data.
- Added deterministic Birth Time Confidence presentation from stored time-status/boundary information.

## Navigation and calculator UX

- Reorganised navigation into Main, Library, Action and Settings groups.
- Added dedicated Journal and Settings/Audit pages.
- Simplified initial chart form to ordinary birth details.
- Moved solar-time, day-boundary, luck-direction and other technical options under Advanced Calculation Options.
- Preserved Compatibility Tests under Settings & Audit.

## Notion schema

Update 1 uses existing properties already present in the live workspace, including `Default Profile`, `Profile Category`, `Sex / Luck Basis`, `Profile Notes`, `Primary Chart`, Daily Luck `Person`, and Daily Luck `Chart`. No large schema expansion is required.

## Deterministic engine preservation

Regression hashes confirm these v1.7 Complete files were not changed by Update 1:

- `src/daily_engine.js`
- `src/solar_terms.js`
- `src/luck_explorer.js`
- `src/ai_daily.js`
- `src/journal_layout.js`
- `src/result_schema.js`
- `src/method_registry.js`
- Phase 1 deterministic modules
- Phase 2 deterministic modules
