# Enchanted Saju — Update 1

A UX/profile-system update built on **Enchanted Saju Journal v1.7 Complete**.

It preserves the deterministic Saju engine and adds:

- Default Profile and persistent Active Profile;
- profile selectors across personal pages;
- profile-safe Daily Luck/Journal routing;
- redesigned My Saju interface;
- Four Pillars saved-chart overview;
- Five Element occurrence exploration;
- deterministic relationship map;
- Beginner / Intermediate / Traditional presentation levels;
- contextual chart help;
- grouped application navigation;
- simplified New Chart experience.

Start with `BEGINNER_UPDATE_UPDATE_1.md`.
