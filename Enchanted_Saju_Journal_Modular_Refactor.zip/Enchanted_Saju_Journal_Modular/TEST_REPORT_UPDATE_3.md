# Enchanted Saju — Update 3 Test Report

## Result

**33 automated test suites pass.**

Update 3 retains the complete inherited v1.7 / Update 1 / Update 2 regression suite and adds:

```text
update3_compare_test: PASS
update3_backend_contract_test: PASS
update3_frontend_test: PASS
update3_regression_guard_test: PASS
```

## Update 3 coverage

### Deterministic comparison

- compares saved technical charts without recalculation;
- detects known cross-chart branch interactions using the existing deterministic relationship engine;
- verifies a Day Branch clash fixture;
- calculates cross-chart Ten God relationships relative to the other Day Master;
- contains no compatibility percentage.

### Backend contracts

Verified routes include:

- `/api/compare`
- `/api/learn/concept`
- `/api/notes`
- `/api/notes/save`
- `/api/research/library`
- `/api/research/source`
- `/api/calculation/inspector`

Personal-note saves explicitly keep source-derived content and AI summary empty.

### Frontend contracts

Verified:

- People library and category filters;
- Compare Charts selectors and relationship map;
- Learn groups and connected concept detail;
- Research Library provenance layers;
- Calculation Inspector and raw Advanced Audit;
- all four provenance labels;
- Concept, 60 Jiazi, Relationship and Chart My Notes.

### Engine preservation

The following files are SHA-256 checked against the Update 2 baseline and remain unchanged:

- `src/daily_engine.js`
- `src/solar_terms.js`
- `src/luck_explorer.js`
- `src/ai_daily.js`
- `src/journal_layout.js`
- `src/method_registry.js`
- `src/result_schema.js`
- all Phase 1 deterministic modules
- all Phase 2 deterministic modules
- `public/phase1-browser.js`
- `public/phase2-browser.js`

`src/update3_features.js` is also checked to ensure the new comparison/inspector module contains no Workers AI calls.

## Static checks

- Worker and deterministic JavaScript syntax: PASS
- Browser inline JavaScript syntax: PASS
- HTML duplicate IDs: none

## Lunar build-environment note

The final project pins the real `korean-lunar-calendar@0.4.0` dependency. The build sandbox did not have registry access, so the inherited lunar fixture test was run with a temporary API-compatible test stub containing only the existing certified regression fixtures. The temporary `node_modules` is excluded from the release ZIP. Normal installation runs `npm install` before tests and deployment.
