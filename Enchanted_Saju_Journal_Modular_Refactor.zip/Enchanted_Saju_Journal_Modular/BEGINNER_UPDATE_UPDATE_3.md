# Update 3.1 save hotfix

If Update 3 showed `Structured Notion JSON exceeds the 150000-character safety limit`, use this package instead. No Notion database changes or new secrets are required. Run `update_existing_windows.bat`, hard-refresh the same Worker URL, then save the verified chart again.

# Beginner Update Guide — Enchanted Saju Update 3

Update 3 installs over your existing **Update 2** Cloudflare Worker and Notion workspace.

You do **not** need to recreate saved profiles or recalculate existing Primary Charts.

## Windows

1. Extract `Enchanted_Saju_Update_3.zip`.
2. Open the extracted folder.
3. Double-click `update_existing_windows.bat`.
4. The updater installs dependencies and runs the complete regression suite first.
5. If all tests pass, it deploys to the same Cloudflare Worker.
6. Open your usual `workers.dev` address.
7. Press **Ctrl + F5**.
8. Click **Test Connection** in Settings if needed.

## What to try first

Open **People**. Your saved people should appear as profile cards.

- **View Saju** opens the person's saved chart in My Saju.
- **Compare** opens the new deterministic Compare Charts page.
- **Edit** reuses the same unique Person ID.
- **More** opens profile settings.

Open **Learn** to browse Saju Concepts. Selecting a concept can show whether it appears in the Active Profile's real saved chart, which saved charts contain it, related journal days, research and My Notes.

Open **Research** to switch between:

- **Library** — existing saved sources with provenance;
- **Add Source** — the existing website/PDF/YouTube/paste/book ingestion flow.

Open **Settings → Calculation Inspector** for a readable explanation of the Active Profile's saved Year and Month Pillars. The complete raw JSON is still available underneath Advanced Audit.

## Important

Compare Charts is structural. It does **not** create a compatibility score or tell you whether a relationship is “good” or “bad”.

My Notes are personal notes. They are stored separately from source-derived material and are never used as deterministic Saju calculation rules.
