# Enchanted Saju — Update 3

Update 3 continues directly from **Update 2**. It does not rebuild the deterministic Saju engine.

This release adds the connected multi-person, learning, research and provenance layer:

- People saved-chart library
- deterministic Compare Charts
- connected Learn library
- upgraded Research Library + Research Inbox
- interpretation provenance
- My Notes on concepts, charts, relationships and 60 Jiazi
- readable Calculation Inspector
- raw Advanced Audit under Settings

Start with `BEGINNER_UPDATE_UPDATE_3.md`.
