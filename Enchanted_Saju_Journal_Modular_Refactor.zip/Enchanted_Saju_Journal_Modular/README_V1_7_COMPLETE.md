# Enchanted Saju Journal v1.7 Complete

The complete v1.7 methodology release.

## Active advanced deterministic methods

- Lunar conversion — `korean-lunar-calendar-0.4.0-kari-offline-v1`
- Weighted Five Elements — `transparent-hidden-stem-equal-allocation-v1`
- Weighted Ten Gods — `transparent-hidden-stem-equal-allocation-v1`
- Chart Strength — `workbook-support-drain-monthbranch-v1`
- Useful/Favourable/Unfavourable Element — `workbook-useful-god-simplified-v1`
- Symbolic Stars — `symbolic-stars-four-rule-set-v1`
- Twelve Stars — `year-branch-trine-12sinsal-v1`

Start with `BEGINNER_UPDATE_V1_7_COMPLETE.md`.

For exact formulas and tables, read `METHODOLOGY_V1_7_COMPLETE.md`.

For regression evidence, read `TEST_REPORT_V1_7_COMPLETE.md`.
