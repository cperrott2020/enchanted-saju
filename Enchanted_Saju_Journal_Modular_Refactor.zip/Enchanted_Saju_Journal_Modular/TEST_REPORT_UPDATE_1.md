# Enchanted Saju — Update 1 Test Report

## Result

**26 automated suites passed.**

```text
daily_engine_test: PASS
ai_daily_test: PASS
journal_layout_test: PASS
today_dashboard_test: PASS
method_registry_test: PASS
luck_explorer_test: PASS
result_schema_test: PASS
frontend_contract_test: PASS
notion_target_hotfix_test: PASS
month_boundary_display_test: PASS
lunar_conversion_test: PASS
weighted_elements_test: PASS
weighted_ten_gods_test: PASS
chart_strength_test: PASS
phase1_regression_guard_test: PASS
phase1_frontend_test: PASS
gregorian_engine_guard_test: PASS
useful_element_test: PASS
symbolic_stars_test: PASS
twelve_stars_test: PASS
phase2_audit_compat_test: PASS
phase2_regression_guard_test: PASS
notion_phase2_contract_test: PASS
profile_system_test: PASS
update1_frontend_test: PASS
update1_regression_guard_test: PASS
```

## Update 1-specific checks

- `profile_system_test` verifies profile/default APIs, unique-ID chart/profile routing, Person+Date Daily Luck duplicate isolation, Person/Chart relations, chart-specific calendar markers, unique default enforcement, and profile metadata persistence.
- `update1_frontend_test` verifies the four Active Profile selectors, My Saju tabs, reading levels, element occurrence highlighting, relationship map, contextual help, birth-time confidence, profile category/default controls, and persistent Active Profile ID.
- `update1_regression_guard_test` hashes the v1.7 Complete deterministic engine, Phase 1 and Phase 2 calculation modules and confirms they are unchanged.

## Static validation

- Worker/module JavaScript syntax: PASS
- Inline browser JavaScript syntax: PASS
- HTML ID uniqueness: PASS (145 unique IDs)

## Existing regression coverage retained

Daily Luck, Workers AI isolation, Today page, journal layout, monthly boundaries, offline lunar conversion, weighted elements/Ten Gods, Chart Strength, Useful Elements, Symbolic Stars, Twelve Stars, result schema, Notion contracts and v1.7 Complete phase guards all continue to pass.

## Test-environment note

The build sandbox could not reach npm during `npm install`, so the already-pinned `korean-lunar-calendar@0.4.0` import was supplied by a temporary test-only fixture for the same certified lunar fixtures used by the existing v1.7 test. The final ZIP does **not** contain that temporary `node_modules` directory. On deployment, `update_existing_windows.bat` runs the normal `npm install` before tests and deployment. The lunar calculation source itself was not modified by Update 1.
