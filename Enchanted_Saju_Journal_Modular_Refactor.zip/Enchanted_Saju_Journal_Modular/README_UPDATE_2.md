# Enchanted Saju — Update 2

Update 2 continues from **Update 1** and keeps the v1.7 deterministic Saju engine unchanged.

It adds a profile-aware personal journal/almanac layer:

- Today dashboard with Daily Energy hero, luck layers and evidence-backed interactions
- AI-supported daily interpretation shown separately from calculated facts
- monthly visual Luck Calendar with calm display filters
- year overview of the 12 Saju solar months
- Daily Journal editor keyed by Profile ID + Date
- Mood/Energy/Productivity/Social Energy/Stress ratings
- resonance, highlights, challenges, standard + custom tags
- descriptive journal analytics labelled **Personal Journal Observation**
- Life Timeline with Major Luck periods, annual pillars and user-recorded life events
- 60-Jiazi reference with Traditional/Technical and Journal Symbolism kept separate

Start with `BEGINNER_UPDATE_UPDATE_2.md`.
