# Enchanted Saju Journal v1.6 — Full App Update Guide

This is an **in-place update** for the same Cloudflare Worker and the same Notion workspace used by v1.5.

## Before you update

You do **not** need a new Cloudflare Worker, Notion integration, Workers AI key, or private connection key.

Your active `Charts` database has already been extended with:

- `Technical Result JSON`
- `Calculation Audit JSON`
- `Current Revision`

The rest of the new data is stored in the existing application/database structures rather than creating a huge new Notion table.

## Windows — update an existing installation

1. Download and extract the v1.6 ZIP.
2. Open the extracted folder.
3. Double-click **`update_existing_windows.bat`**.
4. Let it install/update Wrangler and run the regression suite.
5. When deployment succeeds, open the **same** `workers.dev` address you already use.
6. Press **Ctrl + F5**.
7. Enter your existing private connection key if the browser asks for it.
8. Click **Test Notion connection**.
9. Confirm the top navigation now shows:
   `Today · My Saju · Luck Calendar · Calculator · People · Research · Glossary`.

## macOS / Linux — update an existing installation

In Terminal, open the extracted v1.6 folder and run:

```bash
chmod +x update_existing_mac_linux.sh
./update_existing_mac_linux.sh
```

Then open the same Worker URL and hard-refresh.

## First checks after deployment

### 1. People
Open **People** and click **Load Saved People**. A Person with a Primary Chart should be reusable without re-entering birth data.

### 2. My Saju
Open **My Saju**. Your Primary Chart should load automatically when available. Use the chart tabs to inspect Overview, Elements, Ten Gods, Relationships, Advanced, Luck Cycles, Interpretation and Audit.

Older Chart revisions saved before v1.6 may not contain the complete `Technical Result JSON`. They remain valid historical records; recalculate/save a new verified revision only if you want the richer v1.6 schema.

### 3. Luck Calendar
Open **Luck Calendar** and try Annual, Monthly and Daily Calendar views. Monthly Luck is divided by Saju solar-term months rather than ordinary Gregorian month boundaries.

### 4. Research
Open **Research**. You can add a Website, PDF/text file, YouTube link, pasted text or manual/book source. Review extracted content before saving it to Notion.

### 5. Glossary
Open **Glossary** to browse the actual Notion `Saju Concepts` database.

## Research-file behaviour

- Text-layer PDFs are extracted in the browser and keep `[Page n]` markers in the extracted text.
- If a PDF has no usable text layer, v1.6 says **OCR required**; it does not invent content.
- YouTube uses public metadata only. Paste or upload an authorised `.txt`, `.srt` or `.vtt` transcript for analysis.
- Original selected files are uploaded to the Research Source `Original Material` property when saved.

## Methodology-pending modules

The following appear in the app but remain disabled/pending until a real method is selected:

- Lunar conversion
- Weighted Element Strength
- Weighted Ten God scoring
- Chart Strength
- Useful/Favourable/Unfavourable Elements
- Symbolic Stars
- Twelve Stars

This is deliberate. v1.6 will not turn an unverified interpretative convention into a fake deterministic result.

## If deployment fails

Copy the last Cloudflare/Wrangler error shown in the terminal window. Do not delete the existing Worker or its secrets.
