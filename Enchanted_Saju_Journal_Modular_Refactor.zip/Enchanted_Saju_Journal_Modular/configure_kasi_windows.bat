@echo off
echo KASI_SERVICE_KEY is no longer required.
echo v1.7 Complete uses the pinned offline Korean lunar calendar converter.
pause
