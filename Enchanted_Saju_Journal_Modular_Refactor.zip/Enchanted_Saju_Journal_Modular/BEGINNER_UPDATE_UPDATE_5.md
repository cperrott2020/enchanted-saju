# Beginner Update — Enchanted Saju Update 5

This update changes how the site **looks and feels**, not how your saved Saju charts are calculated.

## Windows

1. Extract the Update 5 ZIP.
2. Double-click **`update_existing_windows.bat`**.
3. Wait for the tests and deployment to finish.
4. Open the same Enchanted Saju `workers.dev` address you already use.
5. Press **Ctrl + F5**.

## macOS / Linux

Open Terminal in the extracted folder and run:

```bash
chmod +x update_existing_mac_linux.sh
./update_existing_mac_linux.sh
```

Then hard-refresh the same Worker URL.

## What should look different

- the opening now resembles an enchanted personal field journal rather than a dashboard
- desktop navigation looks like a little journal / old-web directory
- Today looks more like a daily almanac
- My Saju has an illustrated profile hero
- People look like collectible profile cards
- Journal looks more like paper notes / scrapbook fragments
- Timeline uses a winding cyclical visual language
- Learn resembles an illustrated field guide
- Research resembles a scholar's scrapbook but keeps provenance clear
- all 60 SJPJ/Jiazi types have their own generated emblem and card artwork

## 60 SJPJ Type Cabinet

Open:

**Timeline → 60 Jiazi Reference · SJPJ Type Cabinet**

You can browse all 60 type emblems and open the existing technical/reference entry for any type.

## Important

- You do **not** need to recalculate existing charts.
- You do **not** need to re-import your Research source pack merely because of this visual update.
- JewelSJPJ God terminology from Update 4.2 remains the main beginner-facing terminology.
- The Update 4.1 retry/backoff behaviour for Saju Atelier imports remains in place.
