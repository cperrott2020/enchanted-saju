# v1.2.1 hotfix

This hotfix changes only the Cloudflare Workers `compatibility_date` from `2026-09-25` to `2026-09-24`.

Why: Cloudflare validates compatibility dates against UTC. During the first hours of 25 September in Korea, Cloudflare can still be on 24 September UTC and reject `2026-09-25` as a future compatibility date.

No Notion IDs, secrets, calculation rules, or Daily Luck logic were changed.

## Update
1. Extract this folder.
2. Double-click `update_existing_windows.bat`.
3. Keep using the same workers.dev URL.
4. Press Ctrl+F5 after deployment.
