# Enchanted Saju v1.5 — Live Today Page

v1.5 changes the architecture so the main Notion **🔮 Today** page is temporary/live, while every day remains permanently saved in **System & Data → Daily Luck**.

## What happens automatically

At local midnight in `SAJU_DAILY_TIMEZONE`:

1. Cloudflare calculates the new deterministic Daily Luck context.
2. It creates or updates that date's permanent **Daily Luck** record.
3. Workers AI writes only the `Daily Reading` property.
4. The formatted historical Daily Luck page is refreshed.
5. The main Notion **🔮 Today** page is cleared and rebuilt from that day's saved record.
6. Yesterday's Today-page display disappears, but yesterday's Daily Luck record remains untouched in the database.

The live Today page ends with a link back to the permanent Daily Luck record. Enter personal journal notes in that permanent record, not directly on the live Today page, because Today is intentionally overwritten every day.

## One-time setup

### 1. Share the Today page with the integration

In Notion open:

**My Saju Journal → 🔮 Today → ••• → Connections → Saju Cloudflare Bridge**

Approve access.

### 2. Update the existing Worker

Extract the v1.5 ZIP and double-click:

`update_existing_windows.bat`

No new Notion token, Cloudflare account, AI key, or private connection key is required.

### 3. Hard refresh

Open your existing `workers.dev` calculator URL and press **Ctrl + F5**.

### 4. Test

Click **Test Notion connection**. v1.5 also checks access to the Today page.

Then scroll to **05 · Daily Luck + Live Today Page** and press:

**Refresh Live Today Page**

For the current date, the Today page should immediately become the current Saju dashboard.

## Important data rule

- **Daily Luck database** = permanent historical record.
- **Today page** = temporary mirror of the current date.
- **Daily Reading property** = permanent AI text for that date.
- **Journal / Mood / Energy / Productivity / Events / Retrospective** = permanent personal fields on the Daily Luck record.

The Today refresh never deletes a Daily Luck record and never gives Workers AI permission to change calculated properties.
