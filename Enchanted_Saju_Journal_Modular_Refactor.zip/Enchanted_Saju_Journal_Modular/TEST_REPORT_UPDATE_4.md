# Enchanted Saju — Update 4 Test Report

## Result

**38 automated suites passed.**

The complete inherited Update 3.2 regression suite passed together with three new Update 4 suites:

- `knowledge_identity_test.mjs`
- `update4_backend_contract_test.mjs`
- `update4_frontend_test.mjs`

The new coverage verifies the ten JewelSJPJ accessible Stem terms, all 60 unique canonical Jiazi identities, alias normalisation, glossary merging, source-manifest URL deduplication, the 36 Saju Atelier child records, source-pack routes, provenance metadata, source retrieval context and the new frontend terminology/search behaviour.

## Deterministic regression guard

The following deterministic or deterministic-support files retain the same SHA-256 values as Update 3.2:

```text
efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785  src/daily_engine.js
8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb  src/solar_terms.js
77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0  src/luck_explorer.js
a846d78cf82651d1361180b64de859d9ce64f151b213455f3d0bc8f061ad1a90  src/journal_layout.js
26fc3f70ecaf7406b63e635f03a2ec224cbc80fb98b3483533aef242391dd15b  src/method_registry.js
1e32aca812202b223dae3553ae118bf7833d9e2a45c3eb7515640549926dc866  src/result_schema.js
6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2  src/phase1/lunar_conversion.js
d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca  src/phase1/weighted_analysis.js
2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff  src/phase1/chart_strength.js
112d93135069292af6158eec9d9764a037f71d935a32749923d2b1c4086ef11c  src/phase2/useful_elements.js
7a8866a5c0308b0abf554d6a02604483b9ec956ef3d527d0da571eeddd3343cc  src/phase2/symbolic_stars.js
aa9251f2e6d7ffe8107a3b8f2daccce4e9dbc26d87209d70fa83d0cd800dd08b  src/phase2/twelve_stars.js
e1539a711184a908681730097e9d96d06cd7318adaa4af799009597c84b00a6d  public/phase1-browser.js
d083d538c2d623451c25f5ff033daca051bb5cdb46b2d6e8e8d95a678b420b0a  public/phase2-browser.js
```

`src/ai_daily.js` intentionally changed because Update 4 changes **display terminology and retrieval context** in AI prose. It is not a deterministic calculation module.

## Lunar test environment note

The build environment had no npm-registry access. The full suite was therefore run with the same temporary API-compatible `korean-lunar-calendar@0.4.0` test fixture approach used in the preceding release build. The temporary `node_modules` directory is removed before packaging. The included deployment script performs `npm install` and the production project remains pinned to `korean-lunar-calendar@0.4.0`.
