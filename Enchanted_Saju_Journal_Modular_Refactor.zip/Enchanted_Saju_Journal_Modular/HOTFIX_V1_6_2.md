# v1.6.2 — Monthly Luck boundary display correction

## What was wrong

The Monthly Luck explorer calculated the solar-term instant correctly but the browser displayed the raw UTC date by slicing `start_utc`. For a transition such as 2026 Ipchun, this could display `2026-02-03` even when the selected display timezone was Asia/Seoul, where the same instant is `2026-02-04 05:02`.

This was a **display-timezone bug**, not a change to the sexagenary month-pillar rule.

## What changed

- Monthly API results now include `start_local`, `end_local`, and `display_timezone`.
- Monthly cards show the exact local transition date and time plus the timezone.
- The interface explicitly distinguishes exact astronomical transition instants from rounded whole-day fortune labels used by some consumer services.
- Added a regression fixture for the 2026 monthly sequence:
  - 庚寅 Gyeong-In
  - 辛卯 Sin-Myo
  - 壬辰 Im-Jin
  - 癸巳 Gye-Sa
  - 甲午 Gap-O
  - 乙未 Eul-Mi
  - 丙申 Byeong-Sin
  - 丁酉 Jeong-Yu
  - 戊戌 Mu-Sul
  - 己亥 Gi-Hae
  - 庚子 Gyeong-Ja
  - 辛丑 Sin-Chuk

## Important

v1.6.2 does **not** change a 2026 Gyeong-In month to Jeong-Myo. Under the active standard month-head rule, 2026 is a Byeong year after Ipchun and its In month begins with Gyeong-In.
