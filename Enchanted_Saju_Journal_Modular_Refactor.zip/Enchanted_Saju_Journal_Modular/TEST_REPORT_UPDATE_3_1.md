# Enchanted Saju Update 3.1 — Save Hotfix Test Report

## Result

**34 automated test suites passed.**

```text
daily_engine_test: PASS
ai_daily_test: PASS
journal_layout_test: PASS
today_dashboard_test: PASS
method_registry_test: PASS
luck_explorer_test: PASS
result_schema_test: PASS
frontend_contract_test: PASS
notion_target_hotfix_test: PASS
month_boundary_display_test: PASS
lunar_conversion_test: PASS
weighted_elements_test: PASS
weighted_ten_gods_test: PASS
chart_strength_test: PASS
phase1_regression_guard_test: PASS
phase1_frontend_test: PASS
gregorian_engine_guard_test: PASS
useful_element_test: PASS
symbolic_stars_test: PASS
twelve_stars_test: PASS
phase2_audit_compat_test: PASS
phase2_regression_guard_test: PASS
notion_phase2_contract_test: PASS
profile_system_test: PASS
update1_frontend_test: PASS
update1_regression_guard_test: PASS
update2_backend_contract_test: PASS
update2_frontend_test: PASS
update2_regression_guard_test: PASS
update3_compare_test: PASS
update3_backend_contract_test: PASS
update3_frontend_test: PASS
update3_regression_guard_test: PASS
notion_json_storage_hotfix_test: PASS
```

## Save-limit regression

`notion_json_storage_hotfix_test` reproduces the old failure class with a structured object whose pretty-printed JSON is greater than 150,000 characters. It verifies that the new storage path:

- uses compact valid JSON;
- removes the duplicated full Calculation Audit from `Technical Result JSON`;
- stores the full audit separately in `Calculation Audit JSON`;
- round-trips through `JSON.parse`;
- refuses genuine over-limit data rather than truncating it;
- increases the Notion rich-text chunk allowance safely;
- appends readable page-body audit blocks in batches rather than cutting off after 70 chunks.

## Calculation regression

The complete inherited Update 3 regression suite passed, including Phase 1, Phase 2, Gregorian-engine, Daily Luck, Today, profile isolation, Calendar/Journal/Timeline, comparison, research/provenance and Update 3 engine hash guards.

No deterministic Saju calculation module was changed by this hotfix.

## Lunar test environment

As in the prior build environment, npm registry access was unavailable during this run. A temporary API-compatible `korean-lunar-calendar` fixture containing only the existing certified regression dates was used solely to execute the inherited lunar test. That temporary `node_modules` directory is removed before packaging and is not shipped. The deploy updater runs `npm install` for the real pinned dependency.
