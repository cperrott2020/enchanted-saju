# Update 5 — Enchanted Botanical Field Journal

- Full visual/UX redesign using an enchanted botanical scrapbook + old-web personal shrine + vintage field-guide system.
- Added original fairy-ring, botanical, lace, pressed-flower and celestial ornament assets.
- Added 120 original SVG assets covering all 60 SJPJ/Jiazi type emblems and cards.
- Added collectible SJPJ type cabinet and integrated type art into Today, My Saju, People, Compare and Learn.
- Preserved Update 4.2 terminology/source functionality and all deterministic calculation code.
- 42 automated regression suites pass.

# Update 4.2 — JewelSJPJ Ten Gods

- Added the nine supplied *How to Read Your SJPJ* lesson captures as two CORE private Research sources while preserving capture boundaries.
- Made JewelSJPJ's Ten God labels the preferred ordinary user-facing terminology: Self, Rival, Creator, Rebel, Entrepreneur, Provider, Wild Card, Official, Mystic and Nurturer God.
- Preserved Hangul, Hanja, Jewel romanisation and previous technical English as searchable aliases on the same canonical Ten God concepts.
- Added the five JewelSJPJ categories: Me, Output, Wealth, Authority and Input.
- Updated Today, My Saju, Calendar, Journal, People, Comparison, Luck, Learn/Glossary and accessible AI readings to prefer the Jewel labels.
- Preserved Update 4.1 resumable/throttled source import and all deterministic calculation rules.

# Update 4.1 — Import / Resume Hotfix

- Skips Research sources already saved as Ready / Needs Review.
- Adds Retry Failed Sources and Pause / Resume behaviour.
- Adds 4-second Saju Atelier request spacing.
- Retries temporary 429/500/502/503/504 responses after 5s, 15s and 30s, respecting longer Retry-After values.
- Adds 60-second cooldown after three consecutive temporary Saju Atelier failures.
- Persists the retry queue locally and distinguishes temporary unavailability from hard failure.
- Deterministic Saju calculations unchanged.

# Update 4 — Knowledge Identity + Terminology

- Canonical glossary concept IDs and alias-aware search.
- JewelSJPJ-first accessible terminology with technical identities retained.
- All 60 SJPJ Types added as searchable canonical references.
- Initial Knowledge Source Pack importer with source provenance and failure reporting.
- Private indexed-source retrieval added to natal interpretation without changing deterministic calculations.

# Update 3.2 — Cloudflare subrequest hotfix

- Split chart save into core and finalize Worker invocations.
- Reduced redundant Notion requests for pinned data sources and Default Profile handling.
- Made Chart-page audit and Major Luck finalization retry-safe/idempotent.
- Explicitly keeps each invocation at the Workers Free 50-subrequest ceiling instead of requiring a paid limit increase.
- Deterministic Saju engine unchanged.

# Update 3.1 — Notion Structured JSON Save Hotfix

- Fixed verified-chart saves failing when rich Update 3 Technical Result JSON exceeded the old 150,000-character pretty-JSON limit.
- Compact valid JSON storage; no invalid truncation.
- Removed duplicated full Calculation Audit from Technical Result JSON; complete audit remains in its dedicated property.
- Increased safe rich-text chunk capacity and batched page-body audit append.
- Deterministic calculation code unchanged.

# Update 3 · People, Compare, Learn, Research & Provenance

- Added saved-profile People library and category filters.
- Added deterministic Compare Charts without compatibility scoring.
- Added connected Learn concept pages tied to saved charts, journal and Research.
- Added Research Library provenance layers and expanded bibliography.
- Added My Notes for concepts, relationships, 60 Jiazi and charts.
- Added readable Calculation Inspector while retaining Advanced Audit.
- Preserved Update 2 deterministic calculation modules under regression hashes.

# Update 2 — Today, Calendar, Journal & Life Timeline

- Profile-aware Today hero and calculation layers.
- Visual Month/Year Luck Calendar with calm filters.
- Daily Journal ratings, resonance, highlights, challenges and custom tags.
- Descriptive journal analytics labelled Personal Journal Observation.
- Life Timeline, personal Life Events and 60-Jiazi reference.
- Deterministic v1.7 calculation modules unchanged.

# v1.7 Complete — Phase 2 deterministic analysis

- Preserves the completed Phase 1 method IDs and regression-guarded implementations.
- Adds `workbook-useful-god-simplified-v1` for Useful/Favourable/Unfavourable Elements.
- Adds `symbolic-stars-four-rule-set-v1` with four independently versioned star tables only.
- Adds `year-branch-trine-12sinsal-v1` Twelve Stars as a separate structure from Twelve Growth Stages.
- Extends Notion relations, page-body summaries, Calculation Audit, Technical Result JSON, Glossary entry points and locked natal AI input.
- Extends Compatibility Tests with method-aware `METHOD-DEPENDENT` diagnostics.
- Keeps unregistered Symbolic Stars uncalculated rather than inventing triggers.

# v1.7.0 Phase 1

- Added KASI-backed Lunar birth-date conversion with explicit leap-month selection.
- Added auditable Weighted Five Element Strength and Weighted Ten God Distribution.
- Added sourced workbook Chart Strength with Month Branch tiebreak for borderline cases.
- Added existing Notion Strength Index persistence and Phase 1 audit/schema data.
- Preserved v1.6.2 Gregorian Four Pillars calculation, Daily Luck, Today and Workers AI boundary.
- Useful/Favourable/Unfavourable Element, Symbolic Stars and Twelve Stars remain Phase 2.

# v1.6.2

- Fixed Monthly Luck cards displaying raw UTC date instead of the selected timezone.
- Added exact local solar-term start/end timestamps and timezone labels.
- Added 2026 monthly-pillar regression sequence test.

# Changelog

## v1.6.1 — Notion Save Target Hotfix

- Fixed `Save Verified Chart` failing with `Could not find property with name or id: Birth Date`.
- Root cause: Notion contained more than one database named `People`; v1.6 title-first discovery could resolve the unrelated database.
- Explicit configured data-source IDs now take priority over title discovery.
- The current My Saju Journal People, Charts, Readings, Luck Cycles, Saju Concepts and Daily Luck IDs are pinned in `wrangler.toml`.
- Person saving now also writes the existing `Birth Time Status` property (`Exact`, `Approximate`, or `Unknown`).
- No calculation logic, chart values, Daily Luck logic, AI safety boundary, or live Today behaviour changed.

## v1.6.0 — Full Analysis Application Foundation

- Expanded the single calculator into a seven-section application: Today, My Saju, Luck Calendar, Calculator, People, Research and Glossary.
- Added saved People + Primary Chart loading and reusable verified-chart workflow.
- Added master result schema v2, method registry and Chart calculation revisions.
- Added Technical Result JSON, Calculation Audit JSON and Current Revision persistence.
- Added approximate-time uncertainty display and Hidden Stem role labels.
- Added Five Element visualisation and raw Ten God distribution without inventing weighted strength.
- Added analysis-setting persistence while leaving unvalidated methods disabled.
- Added richer Major Luck cards, multi-year Annual Luck, exact 12 solar-term Monthly Luck and interactive Daily calendar.
- Added structured relationship records plus Wonjin.
- Added full natal AI interpretation and expanded Daily AI sections while preserving the calculation/AI write boundary.
- Added Research Inbox: website extraction, client-side PDF text extraction, YouTube metadata, controlled-vocabulary concept tagging, source/AI separation and original-file attachment.
- Added real Notion-backed Glossary and developer Compatibility Tests.
- Lunar conversion, weighted analysis, Chart Strength, Useful/Favourable/Unfavourable Element, Symbolic Stars and Twelve Stars remain explicitly Methodology Pending.
- Added v1.6 regression/contract tests.

## v1.5.0

- Added a **live Notion Today page** that is replaced automatically with the current day after scheduled Daily Luck generation.
- Historical days remain permanently stored as separate records in the **Daily Luck** database.
- Added `SAJU_TODAY_PAGE_ID` configuration for the current workspace Today page.
- Added `/api/today/refresh` for manual testing and recovery.
- Added **Refresh Live Today Page** button in the calculator.
- The live Today page shows the locked calculated context + AI Daily Reading, then links to the permanent Daily Luck record.
- Personal journal writing should be entered in the saved Daily Luck record; the live Today page is intentionally ephemeral and is overwritten at local midnight.
- AI regeneration and saved-journal refresh also resync the live Today page when operating on the current local date.
- Connection test now verifies that `Saju Cloudflare Bridge` can access the Today page.
- Added `today_dashboard_test`.

## v1.4.0

- Added formatted Notion Daily Luck page bodies.
- Added generated `🌸 Daily Saju` container.
- Added locked `🔒 Calculated Context` section rendered from deterministic facts.
- Added formatted `🌸 AI Daily Reading` section with separate headings.
- Added protected `☕ Daily Journal` scaffold outside generated content.
- AI regeneration replaces only the generated AI section and the `Daily Reading` property.
- Added `/api/daily/render` to format an existing Daily Luck entry without calling AI.
- Added **Refresh Notion Journal Layout** button to the calculator.
- Added `journal_layout_test` safety checks.
- Retains all v1.3.2 reasoning-disabled Workers AI response handling and all v1.2 deterministic Daily Luck safeguards.
