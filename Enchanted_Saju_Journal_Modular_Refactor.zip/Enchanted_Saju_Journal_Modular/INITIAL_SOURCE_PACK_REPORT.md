# Initial Knowledge Source Pack — Build-Time Import Report

This report distinguishes **content physically available during this build** from **public web sources configured for runtime retrieval after deployment**. It deliberately does not label a public source as ingested before its content has actually been retrieved into the user's Research Library.

## Build summary

- Source manifest records: **43**
- Importable document/source records: **42**
- Parent collection records: **1** (`SRC-ATELIER-001`)
- Saju Atelier child article records: **36**
- URL-bearing records: **38**
- Duplicate URLs in the shipped manifest: **0**
- Canonical 60 Jiazi / SJPJ Type references defined: **60**

## Sources available in the build

### SRC-JEWEL-001 — Complete SJPJ Types Guide

- Priority: CORE — 5/5
- Build-time content status: **Retrieved from the user-supplied PDF**
- PDF length: **129 pages**
- Packaged handling: extracted text is bundled privately for Research import; it is not exposed as a public Learn-page reproduction.
- Known terminology seeded before AI indexing: the ten accessible Stem names and all 60 accessible SJPJ Type names.
- Runtime import: creates/updates the Research Source by permanent `source_id`, stores private source-derived content in Research Notes, links detected canonical concepts and records terminology provenance.

### SRC-JEWEL-002 — SJPJ Type Celebrities

- Priority: SUPPORTING — 3/5
- Build-time content status: **Retrieved from the user-supplied PDF**
- PDF length: **12 pages**
- Packaged handling: extracted text is bundled privately for Research import.
- Usage boundary: terminology/examples only; celebrity examples are not deterministic chart calculation rules.

### SRC-JEWEL-003 — How to Read Your SJPJ — The Why Part 1

- Priority: CORE — 5/5
- Build-time content status: **Structured from four user-supplied course-page captures**
- Capture boundaries preserved: Ten Gods chart context; selected Special Stars; Five Elements Help relationship; Five Elements Hurt/control relationship.
- Usage boundary: source context and Learn/reference material only; these captures do not change calculation rules.

### SRC-JEWEL-004 — How to Read Your SJPJ — The Why Part 2

- Priority: CORE — 5/5
- Build-time content status: **Structured from five user-supplied course-page captures**
- Capture boundaries preserved: Me, Output, Wealth, Authority and Input categories.
- Terminology role: **primary ordinary user-facing Ten God terminology** for Self, Rival, Creator, Rebel, Entrepreneur, Provider, Wild Card, Official, Mystic and Nurturer God. Technical English, Hangul and Hanja remain attached to the same canonical concepts.

## Public web sources configured for runtime retrieval

### SRC-QIORA-001 — Qiora Learn

- Priority: HIGH — 4/5
- Build-time Notion ingestion status: **Pending deployment/import**
- Runtime behaviour: retrieves the root Learn book and a bounded set of same-origin Learn/Reference pages, preserves document boundaries and reports linked-page failures for manual review.

### SRC-WMS-001 — What's My Saju: What Is Saju?

- Priority: STANDARD — 3/5
- Build-time Notion ingestion status: **Pending deployment/import**
- Runtime behaviour: retrieves readable page content, keeps source identity and treats source imagery/metaphors as aliases/metaphors rather than silently converting them into formal translations.

### SRC-ATELIER-001 — Saju Atelier Library

- Priority: HIGH — 4/5
- Parent record: collection only
- Child article records configured: **36**
- Build-time Notion ingestion status: **Pending deployment/import**
- Runtime behaviour: each article is retrieved and indexed separately so it remains independently citable/retrievable. The Special Stars URL is present only once in the manifest.

## Runtime import report

After deployment, open **Research → Initial Knowledge Source Pack → Import / Refresh Pack**. The live progress report records per-source success, failure/manual-review status and alias counts. A page whose actual readable content cannot be retrieved remains failed/not-imported rather than being reported as successfully ingested.
