> **Historical Phase 1 document.** Superseded by v1.7 Complete and the offline lunar hotfix. For current setup and methodology, use `BEGINNER_UPDATE_V1_7_COMPLETE.md` and `METHODOLOGY_V1_7_COMPLETE.md`.

# Enchanted Saju Journal v1.7 — Phase 1 Changelog

## Added

- Lunar birth-date input with explicit ordinary/leap-month selection.
- KASI/Public Data Portal lunar → Gregorian normalisation before the unchanged Four Pillars engine.
- Separate preservation of original lunar input and normalised Gregorian date.
- Weighted Five Element Strength with fully auditable contributor records.
- Active Hidden Stem allocation toggle.
- Weighted Ten God Distribution using the same contributor weights as the element module.
- Deterministic Chart Strength based on the supplied Korean Saju Workbook Support/Drain method.
- Month Branch tiebreak for workbook-defined borderline `4/4` and `5/3` cases.
- `Strength Index` persistence to the existing Notion Charts property.
- Phase 1 method descriptions in the central registry.
- Expanded Calculation Audit and master result schema `2.1.0-phase1`.
- Compatibility Tests now include Lunar Conversion, Weighted Elements, Weighted Ten Gods and Chart Strength.
- Calculation-explanation panels in the existing Five Elements, Ten Gods and Advanced screens.

## Deliberately not implemented

Phase 1 stops before:

- Useful Element;
- Favourable Element;
- Unfavourable Element;
- Symbolic Stars;
- Twelve Stars.

Those remain Methodology Pending.

## Preserved

The v1.6.2 deterministic Four Pillars calculation body is unchanged for Gregorian input. Daily Luck, automatic Today, Workers AI Daily Reading, journal layout, solar terms and luck explorer modules are protected by regression hashes.
