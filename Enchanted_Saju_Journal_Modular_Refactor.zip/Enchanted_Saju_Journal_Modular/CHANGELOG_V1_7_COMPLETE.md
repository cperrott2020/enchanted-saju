# Enchanted Saju Journal v1.7 Complete — Changelog

## Phase 1 preserved exactly

- `korean-lunar-calendar-0.4.0-kari-offline-v1`
- `transparent-hidden-stem-equal-allocation-v1`
- `workbook-support-drain-monthbranch-v1`

Phase 2 includes a regression-hash guard for the Phase 1 lunar, weighted-analysis, Chart Strength and browser modules.

## Added in Phase 2

- Useful Element / 용신 · 用神 via `workbook-useful-god-simplified-v1`.
- Favourable Element / 희신 · 喜神 via the same workbook derivation.
- Unfavourable Element / 기신 · 忌神 via the same workbook derivation.
- Structured reasoning/factor records and provisional flag for borderline strength cases.
- `symbolic-stars-four-rule-set-v1` with only four enabled, independently versioned rules:
  - Peach Blossom
  - Travelling Horse
  - Flower Canopy
  - Heavenly Nobleman
- `year-branch-trine-12sinsal-v1` Twelve Stars / 십이신살.
- Explicit UI and schema separation between Twelve Stars and Twelve Growth Stages.
- Advanced screen calculation explanations and Saju Concept/research entry points.
- Compatibility Tests extended with Useful, Favourable, Unfavourable, Symbolic Stars and Twelve Stars.
- Natal Workers AI now receives Phase 2 values as explicitly LOCKED calculated input.
- Existing Notion Useful/Favourable/Unfavourable relations now populate on verified Chart save.
- Existing `Useful Element Method` and `Symbolic Star Method` properties now populate.
- Readable Advanced Deterministic Analysis summary added to saved Chart page body.
- Calculation Audit extended with Phase 2 methods, factors, enabled star rules and Twelve Stars method metadata.
- Result schema advanced to `2.2.0-complete`.

## Deliberately not added

The following Symbolic Stars remain uncalculated because this release does not have a separately validated trigger table for each:

- Heavenly Virtue
- Monthly Virtue
- Academic Hall
- Literary Star
- Red Charm
- Solitary Star
- Widow Star
- White Tiger
- Needle Star
- Yang Blade
- other unregistered 신살

They may remain in the research/glossary system without being treated as deterministic chart results.

## Unchanged

- Four Pillars engine
- historical timezone handling
- solar/local-time correction
- solar-term boundaries
- Major Luck
- Annual/Monthly/Daily Luck
- Daily Luck duplicate protection
- live Today replacement behaviour
- Daily journal protection
- Workers AI Daily Reading calculation boundary
- research/source ingestion architecture
- older Chart revision readability
