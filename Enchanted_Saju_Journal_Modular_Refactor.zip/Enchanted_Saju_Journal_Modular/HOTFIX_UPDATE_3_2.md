# Enchanted Saju Update 3.2 — Cloudflare Subrequest Hotfix

## Error fixed

`Too many subrequests by single Worker invocation.`

Cloudflare Workers Free permits at most 50 external subrequests per invocation. Update 3.1 still performed the complete Notion save, full Chart-page audit rendering, profile-default maintenance and eight Major Luck page creations inside one HTTP invocation. Depending on workspace/profile state and Notion retries, that could exceed 50.

## Update 3.2 architecture

Saving is now intentionally split across **two Worker invocations**:

1. `/api/save-chart` — core save only: Person + complete Chart properties + Technical Result JSON + Calculation Audit JSON + Primary Chart link.
2. `/api/save-chart/finalize` — idempotent secondary work: readable Chart-page audit + missing Major Luck pages + optional Reading.

Both invocations are designed to remain below the Free-plan ceiling without changing the account-level Cloudflare limit. The browser automatically calls the second step after the core save and retries the finalizer once as a new invocation if needed.

### Additional reductions

- Pinned Notion data-source IDs are trusted during ordinary requests; `/api/connection` remains the explicit access-validation path.
- Concept relation references loaded during the core save are passed into the finalizer, avoiding another full concept-database query.
- Stable profile IDs are PATCHed directly instead of GET + PATCH.
- Default Profile maintenance queries only currently-default profiles rather than scanning/patching every Person.
- The readable page audit is appended in one Notion block request and carries a marker so retries do not duplicate it.
- Existing Major Luck rows are queried before creation so finalize retries do not duplicate cycles.

No Saju calculation method was changed.
