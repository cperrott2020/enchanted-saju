from pathlib import Path
import json,re,html

OUT=Path('/mnt/data/esj_5_0/enchanted_saju_update5_0/public/assets/sjpj-types')
OUT.mkdir(parents=True,exist_ok=True)
STEMS=[
('甲','갑','Gap','Blue Tree','Yang','Wood'),('乙','을','Eul','Blue Vine','Yin','Wood'),('丙','병','Byeong','Red Sun','Yang','Fire'),('丁','정','Jeong','Red Moon','Yin','Fire'),('戊','무','Mu','Yellow Mountain','Yang','Earth'),('己','기','Gi','Yellow Garden','Yin','Earth'),('庚','경','Gyeong','White Sword','Yang','Metal'),('辛','신','Sin','White Jewel','Yin','Metal'),('壬','임','Im','Black Ocean','Yang','Water'),('癸','계','Gye','Black Mist','Yin','Water')]
BRANCHES=[
('子','자','Ja','Rat'),('丑','축','Chuk','Ox'),('寅','인','In','Tiger'),('卯','묘','Myo','Rabbit'),('辰','진','Jin','Dragon'),('巳','사','Sa','Snake'),('午','오','O','Horse'),('未','미','Mi','Goat'),('申','신','Sin','Monkey'),('酉','유','Yu','Rooster'),('戌','술','Sul','Dog'),('亥','해','Hae','Pig')]
PALETTES={
'Wood':('#eff1e5','#aab69d','#78846c','#d7a5af','#66564b'),
'Fire':('#f7e8df','#d7a5af','#b77f8b','#b99d69','#66564b'),
'Earth':('#f1e7d6','#a28d7b','#909579','#d7a5af','#66564b'),
'Metal':('#f3efe8','#c6b7cf','#aeb9d7','#b99d69','#66564b'),
'Water':('#eef0ef','#879cb7','#aab69d','#c6b7cf','#66564b')}

def slug(s):
    return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')

def animal_svg(animal, cx=160, cy=166, scale=1):
    # Original simplified line-art animal emblems. Intentionally diagrammatic rather than photorealistic.
    g=[]
    st='stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"'
    fill='fill="currentColor" opacity=".06" stroke="currentColor" stroke-width="5"'
    def tr(x,y): return f'translate({cx+x*scale} {cy+y*scale}) scale({scale})'
    if animal=='Rat':
        return f'''<g transform="{tr(-4,0)}" {st}><ellipse cx="0" cy="10" rx="45" ry="28" {fill}/><circle cx="39" cy="-2" r="20" {fill}/><circle cx="42" cy="-19" r="8" {fill}/><circle cx="48" cy="-5" r="2" fill="currentColor"/><path d="M-43 15 C-82 20 -92 57 -56 69 C-37 76 -20 67 -14 58"/><path d="M58 1 l15 6 -15 5"/></g>'''
    if animal=='Ox':
        return f'''<g transform="{tr(0,0)}" {st}><path d="M-38 -8 Q0 -42 38 -8 L32 36 Q0 52 -32 36 Z" {fill}/><path d="M-31 -15 Q-56 -42 -69 -18 Q-46 -22 -33 -5"/><path d="M31 -15 Q56 -42 69 -18 Q46 -22 33 -5"/><path d="M-18 23 Q0 34 18 23"/><circle cx="-16" cy="4" r="3" fill="currentColor"/><circle cx="16" cy="4" r="3" fill="currentColor"/></g>'''
    if animal=='Tiger':
        return f'''<g transform="{tr(0,0)}" {st}><circle cx="0" cy="4" r="46" {fill}/><path d="M-34 -28 L-50 -51 L-18 -42 M34 -28 L50 -51 L18 -42"/><path d="M0 -39 v18 M-13 -33 l8 16 M13 -33 l-8 16 M-31 -6 l17 8 M31 -6 l-17 8"/><circle cx="-17" cy="5" r="3" fill="currentColor"/><circle cx="17" cy="5" r="3" fill="currentColor"/><path d="M-10 21 Q0 30 10 21 M0 18 v9"/></g>'''
    if animal=='Rabbit':
        return f'''<g transform="{tr(0,3)}" {st}><ellipse cx="-15" cy="-50" rx="13" ry="42" transform="rotate(-10 -15 -50)" {fill}/><ellipse cx="17" cy="-50" rx="13" ry="42" transform="rotate(10 17 -50)" {fill}/><circle cx="0" cy="9" r="42" {fill}/><circle cx="-15" cy="2" r="3" fill="currentColor"/><circle cx="15" cy="2" r="3" fill="currentColor"/><path d="M-6 18 Q0 24 6 18 M0 20 v12"/></g>'''
    if animal=='Dragon':
        return f'''<g transform="{tr(0,0)}" {st}><path d="M-58 29 C-34 -46 22 -53 47 -9 C66 25 35 58 -1 42 C-30 29 -23 -3 4 -7 C29 -10 39 15 24 28"/><path d="M-12 -37 l-7 -26 M12 -37 l9 -25 M-21 -19 l-28 -8 M28 -15 l27 -11"/><path d="M-58 29 l-14 20 24 -3 M47 -9 l17 -16 -2 25"/><circle cx="31" cy="-15" r="3" fill="currentColor"/></g>'''
    if animal=='Snake':
        return f'''<g transform="{tr(0,0)}" {st}><path d="M-35 -50 C25 -65 49 -24 8 -3 C-26 14 -34 47 6 52 C35 56 54 35 40 18"/><path d="M-35 -50 l-14 -8 5 15 11 5"/><circle cx="-38" cy="-52" r="2" fill="currentColor"/><path d="M-48 -48 l-15 -4 M-48 -48 l-13 7"/></g>'''
    if animal=='Horse':
        return f'''<g transform="{tr(0,0)}" {st}><path d="M-28 48 C-35 8 -15 -35 8 -48 L37 -29 L25 -13 C42 5 40 28 24 43 Q1 58 -28 48 Z" {fill}/><path d="M-1 -43 l-17 -22 25 12 M18 -42 l15 -18 -2 28"/><path d="M12 -9 q15 4 18 18"/><circle cx="14" cy="-20" r="3" fill="currentColor"/></g>'''
    if animal=='Goat':
        return f'''<g transform="{tr(0,0)}" {st}><path d="M-34 -5 Q0 -40 34 -5 L27 38 Q0 55 -27 38 Z" {fill}/><path d="M-24 -17 C-59 -54 -63 -5 -37 7 M24 -17 C59 -54 63 -5 37 7"/><circle cx="-14" cy="6" r="3" fill="currentColor"/><circle cx="14" cy="6" r="3" fill="currentColor"/><path d="M-9 25 Q0 34 9 25 M0 28 l-7 20 M0 28 l7 20"/></g>'''
    if animal=='Monkey':
        return f'''<g transform="{tr(0,0)}" {st}><circle cx="-42" cy="4" r="18" {fill}/><circle cx="42" cy="4" r="18" {fill}/><circle cx="0" cy="4" r="45" {fill}/><ellipse cx="0" cy="12" rx="28" ry="25" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="-15" cy="1" r="3" fill="currentColor"/><circle cx="15" cy="1" r="3" fill="currentColor"/><path d="M-10 22 Q0 29 10 22"/></g>'''
    if animal=='Rooster':
        return f'''<g transform="{tr(-3,0)}" {st}><ellipse cx="0" cy="15" rx="37" ry="43" {fill}/><circle cx="17" cy="-28" r="20" {fill}/><path d="M8 -47 q4 -18 12 0 q7 -20 13 1 q9 -14 10 4"/><path d="M36 -27 l23 9 -22 8"/><path d="M-32 0 C-70 -25 -70 21 -41 24 C-73 17 -65 51 -31 38"/><path d="M-7 55 l-10 20 M13 55 l11 20"/><circle cx="23" cy="-31" r="2" fill="currentColor"/></g>'''
    if animal=='Dog':
        return f'''<g transform="{tr(0,0)}" {st}><circle cx="0" cy="7" r="43" {fill}/><path d="M-33 -18 Q-65 -31 -55 16 L-37 28 M33 -18 Q65 -31 55 16 L37 28" {fill}/><circle cx="-15" cy="2" r="3" fill="currentColor"/><circle cx="15" cy="2" r="3" fill="currentColor"/><path d="M-8 19 Q0 28 8 19 M0 21 v11"/></g>'''
    if animal=='Pig':
        return f'''<g transform="{tr(0,0)}" {st}><circle cx="0" cy="5" r="44" {fill}/><path d="M-30 -27 l-8 -24 27 14 M30 -27 l8 -24 -27 14"/><ellipse cx="0" cy="20" rx="22" ry="16" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="-8" cy="20" r="2" fill="currentColor"/><circle cx="8" cy="20" r="2" fill="currentColor"/><circle cx="-15" cy="0" r="3" fill="currentColor"/><circle cx="15" cy="0" r="3" fill="currentColor"/></g>'''
    return ''

def element_motif(element):
    if element=='Wood':
        return '''<g class="motif" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M42 208 C80 172 77 123 93 82"/><path d="M72 160 q-30 -18 -38 8 q24 8 38 -8 M79 139 q32 -20 42 4 q-24 13 -42 -4 M85 113 q-25 -18 -32 6 q18 12 32 -6"/></g>'''
    if element=='Fire':
        return '''<g class="motif" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="74" cy="111" r="24"/><path d="M74 69v-19 M74 172v-19 M32 111H13 M135 111h-19 M44 81 29 66 M119 156l-15-15 M104 81l15-15 M29 156l15-15"/><path d="M42 214 q32 -33 62 0"/></g>'''
    if element=='Earth':
        return '''<g class="motif" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M22 195 q52 -24 104 0"/><ellipse cx="48" cy="174" rx="19" ry="8"/><path d="M48 174v-36 M31 142 q17 -27 34 0"/><ellipse cx="102" cy="181" rx="14" ry="6"/><path d="M102 181v-25 M90 160 q12 -19 24 0"/></g>'''
    if element=='Metal':
        return '''<g class="motif" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="58" cy="118" r="18"/><path d="M76 118h47 M108 118v17 M118 118v10"/><circle cx="50" cy="190" r="5"/><circle cx="75" cy="202" r="3"/><circle cx="99" cy="187" r="4"/><path d="M37 54 l5 11 12 2-9 8 2 12-10-6-10 6 2-12-9-8 12-2z"/></g>'''
    if element=='Water':
        return '''<g class="motif" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M18 169 q20 -15 40 0 t40 0 t40 0 M18 188 q20 -15 40 0 t40 0 t40 0"/><path d="M50 102 a32 32 0 1 0 35 -45 a24 24 0 1 1 -35 45"/><path d="M103 116 q14 -31 28 0 q-14 7 -28 0"/></g>'''
    return ''

def build_svg(stem,branch,index,kind):
    sh,sk,sr,sname,yy,element=stem
    bh,bk,br,animal=branch
    bg,p1,p2,accent,ink=PALETTES[element]
    name=f'{sname} {animal}'
    technical=f'{yy} {element} {animal}'
    korean=f'{sk}{bk}'
    rom=f'{sr}-{br}'
    yang=yy=='Yang'
    if kind=='emblem':
        W=320;H=320
        border = f'<circle cx="160" cy="160" r="137" fill="none" stroke="{p2}" stroke-width="3"/><circle cx="160" cy="160" r="125" fill="none" stroke="{accent}" stroke-width="1.5" stroke-dasharray="2 8"/>' if not yang else f'<circle cx="160" cy="160" r="137" fill="none" stroke="{p2}" stroke-width="4"/><path d="M160 11v20M160 289v20M11 160h20M289 160h20M55 55l14 14M251 251l14 14M265 55l-14 14M69 251l-14 14" stroke="{accent}" stroke-width="2"/>'
        return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" role="img" aria-labelledby="t d"><title id="t">{html.escape(name)} emblem</title><desc id="d">Decorative symbolic artwork generated from {element}, {yy}, and {animal}. It is decorative UI art, not a traditional Saju claim.</desc><defs><filter id="grain"><feTurbulence baseFrequency=".8" numOctaves="2" seed="{index+7}"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .045"/></feComponentTransfer></filter><radialGradient id="g"><stop stop-color="{bg}"/><stop offset="1" stop-color="{p1}" stop-opacity=".35"/></radialGradient></defs><rect width="320" height="320" rx="52" fill="url(#g)"/><rect width="320" height="320" rx="52" filter="url(#grain)" opacity=".35"/>{border}<g style="color:{p2}" opacity=".55">{element_motif(element)}</g><g style="color:{ink}">{animal_svg(animal,160,154,.78)}</g><text x="160" y="245" text-anchor="middle" font-family="Cormorant Garamond, Georgia, serif" font-size="25" fill="{ink}">{html.escape(name)}</text><text x="160" y="272" text-anchor="middle" font-family="Georgia, serif" font-size="16" fill="{p2}">{sh}{bh} · {html.escape(korean)}</text><g fill="{accent}"><circle cx="74" cy="65" r="3"/><circle cx="244" cy="72" r="2"/><circle cx="261" cy="224" r="3"/><path d="M65 238 l4 8 8 4-8 4-4 8-4-8-8-4 8-4z"/></g></svg>'''
    # Card 480x640
    yin_orn='''<path d="M56 80 q16 -18 32 0 q16 18 32 0 q16 -18 32 0 q16 18 32 0 q16 -18 32 0 q16 18 32 0 q16 -18 32 0 q16 18 32 0 q16 -18 32 0 q16 18 32 0" fill="none" stroke="{accent}" stroke-width="2" opacity=".65"/>'''.format(accent=accent)
    yang_orn=f'''<g stroke="{accent}" stroke-width="2" opacity=".6"><path d="M240 44v30M240 566v30M54 320h30M396 320h30"/><path d="M108 115l20 20M352 505l20 20M372 115l-20 20M128 505l-20 20"/></g>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 640" role="img" aria-labelledby="t d"><title id="t">{html.escape(name)} card</title><desc id="d">A decorative enchanted-field-journal card for {name}, generated from its element family, branch animal and yin-yang polarity. Decorative only.</desc><defs><filter id="grain"><feTurbulence baseFrequency=".7" numOctaves="3" seed="{index+11}"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .06"/></feComponentTransfer></filter><linearGradient id="paper" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f8f1e5"/><stop offset=".48" stop-color="{bg}"/><stop offset="1" stop-color="#eee3d2"/></linearGradient><radialGradient id="halo"><stop stop-color="{accent}" stop-opacity=".2"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient></defs><rect width="480" height="640" rx="34" fill="url(#paper)"/><rect width="480" height="640" rx="34" filter="url(#grain)"/><rect x="20" y="20" width="440" height="600" rx="26" fill="none" stroke="{p2}" stroke-width="2" opacity=".75"/><rect x="30" y="30" width="420" height="580" rx="22" fill="none" stroke="{p1}" stroke-width="1" stroke-dasharray="2 7" opacity=".8"/>{yang_orn if yang else yin_orn}<circle cx="240" cy="304" r="150" fill="url(#halo)"/><g style="color:{p2}" opacity=".42" transform="translate(26 68) scale(1.45)">{element_motif(element)}</g><g style="color:{ink}">{animal_svg(animal,240,304,1.32)}</g><text x="240" y="92" text-anchor="middle" font-family="Cormorant Garamond, Georgia, serif" font-size="39" fill="{ink}">{html.escape(name)}</text><text x="240" y="125" text-anchor="middle" font-family="Georgia, serif" font-size="18" fill="{p2}">{sh}{bh} · {html.escape(korean)} · {html.escape(rom)}</text><path d="M112 148 H368" stroke="{accent}" stroke-width="1.5"/><text x="240" y="504" text-anchor="middle" font-family="Georgia, serif" font-size="21" fill="{ink}">{html.escape(technical)}</text><text x="240" y="536" text-anchor="middle" font-family="Nunito Sans, Arial, sans-serif" font-size="14" letter-spacing="2" fill="{p2}">SJPJ TYPE · {index+1:02d} / 60</text><g fill="{accent}" opacity=".8"><circle cx="92" cy="551" r="3"/><circle cx="388" cy="548" r="3"/><circle cx="77" cy="187" r="2"/><circle cx="401" cy="194" r="2"/><path d="M92 568 l5 10 10 5-10 5-5 10-5-10-10-5 10-5z"/><path d="M388 568 l4 8 8 4-8 4-4 8-4-8-8-4 8-4z"/></g><text x="42" y="602" font-family="Georgia, serif" font-size="11" fill="{ink}" opacity=".58">decorative field-journal artwork · calculation-neutral</text></svg>'''

manifest=[]
for i in range(60):
    stem=STEMS[i%10]; branch=BRANCHES[i%12]
    name=f'{stem[3]} {branch[3]}'
    folder=f'{i+1:02d}-{slug(name)}'
    d=OUT/folder; d.mkdir(exist_ok=True)
    (d/'emblem.svg').write_text(build_svg(stem,branch,i,'emblem'),encoding='utf-8')
    (d/'card.svg').write_text(build_svg(stem,branch,i,'card'),encoding='utf-8')
    manifest.append({
        'index':i,'number':i+1,'folder':folder,'name':name,'characters':stem[0]+branch[0],
        'korean':stem[1]+branch[1],'romanisation':stem[2]+'-'+branch[2],
        'element':stem[5],'yin_yang':stem[4],'animal':branch[3],
        'emblem':f'/assets/sjpj-types/{folder}/emblem.svg','card':f'/assets/sjpj-types/{folder}/card.svg',
        'asset_note':'Decorative symbolic UI artwork; not traditional doctrine.'
    })
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('generated',len(manifest),'types',sum(1 for _ in OUT.rglob('*.svg')),'svg files')
