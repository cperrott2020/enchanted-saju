#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
npm install
npm test
npx wrangler login
npx wrangler secret put NOTION_TOKEN
npx wrangler secret put SAJU_SAVE_KEY
npx wrangler deploy
echo "Deployed Enchanted Saju with Update 3. Lunar conversion remains offline."
