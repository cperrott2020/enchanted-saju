# Enchanted Saju Journal v1.7 Complete — Regression Test Report

Build date: 2026-09-25

## Result

**23 automated suites PASS.**

```text
daily_engine_test: PASS
ai_daily_test: PASS
journal_layout_test: PASS
today_dashboard_test: PASS
method_registry_test: PASS
luck_explorer_test: PASS
result_schema_test: PASS
frontend_contract_test: PASS
notion_target_hotfix_test: PASS
month_boundary_display_test: PASS
lunar_conversion_test: PASS
weighted_elements_test: PASS
weighted_ten_gods_test: PASS
chart_strength_test: PASS
phase1_regression_guard_test: PASS
phase1_frontend_test: PASS
gregorian_engine_guard_test: PASS
useful_element_test: PASS
symbolic_stars_test: PASS
twelve_stars_test: PASS
phase2_audit_compat_test: PASS
phase2_regression_guard_test: PASS
notion_phase2_contract_test: PASS
```

## Phase 2 requirements covered

| Requirement | Validation | Result |
|---|---|---|
| Identical chart + identical method gives identical Useful Element | `useful_element_test.mjs` deep-equality repeat | PASS |
| Useful Element does not depend on AI | deterministic Phase 2 source scan contains no Workers AI calls | PASS |
| Known Symbolic Star triggers detect correctly | Heavenly Nobleman, Peach Blossom, Travelling Horse and Flower Canopy fixtures | PASS |
| Non-trigger Symbolic Star cases remain absent | explicit negative branch fixture | PASS |
| Twelve Stars separate from Twelve Growth Stages | independent module/result object + source guard | PASS |
| Method versions appear in Calculation Audit | `phase2_audit_compat_test.mjs` | PASS |
| Older Phase 1-shaped records remain readable | old-payload master-schema fixture | PASS |
| All Phase 1 tests still pass | Lunar, weighted elements, weighted Ten Gods, Chart Strength + regression guards | PASS |
| Daily Luck still works | `daily_engine_test.mjs` + `luck_explorer_test.mjs` | PASS |
| Today page behaviour remains intact | `today_dashboard_test.mjs` + protected-module hash guards | PASS |
| Verified Chart Notion save contract remains valid | source contract test + live Charts schema inspection | PASS |
| Compatibility Tests include Phase 2 and method-aware differences | browser contract/audit test | PASS |

## Phase 1 preservation

The following exact Phase 1 method IDs remain active:

- Lunar conversion — `korean-lunar-calendar-0.4.0-kari-offline-v1`
- Weighted Five Elements — `transparent-hidden-stem-equal-allocation-v1`
- Weighted Ten Gods — `transparent-hidden-stem-equal-allocation-v1`
- Chart Strength — `workbook-support-drain-monthbranch-v1`

Phase 2 regression guards verify the core Phase 1 implementation files were not altered during Phase 2. Current hashes:

- `src/phase1/lunar_conversion.js` — `6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2`
- `src/phase1/weighted_analysis.js` — `d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca`
- `src/phase1/chart_strength.js` — `2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff`
- `public/phase1-browser.js` — `e1539a711184a908681730097e9d96d06cd7318adaa4af799009597c84b00a6d`

## Phase 2 deterministic modules

- `src/phase2/useful_elements.js` — `112d93135069292af6158eec9d9764a037f71d935a32749923d2b1c4086ef11c`
- `src/phase2/symbolic_stars.js` — `7a8866a5c0308b0abf554d6a02604483b9ec956ef3d527d0da571eeddd3343cc`
- `src/phase2/twelve_stars.js` — `aa9251f2e6d7ffe8107a3b8f2daccce4e9dbc26d87209d70fa83d0cd800dd08b`
- `src/phase2/phase2_analysis.js` — `2b64309789faf0ed03e82f89f6a5f1d29701a431e017c7b7bc94498851e95a39`
- `public/phase2-browser.js` — `d083d538c2d623451c25f5ff033daca051bb5cdb46b2d6e8e8d95a678b420b0a`

## Notion contract validation

The active Notion `Charts` data source was inspected during the build. It already contains the required existing properties:

- `Useful Element`
- `Favourable Element`
- `Unfavourable Element`
- `Useful Element Method`
- `Symbolic Star Method`
- `Technical Result JSON`
- `Calculation Audit JSON`

The three element fields are relations to the existing `Saju Concepts` data source. No large Symbolic-Star property set and no new Twelve-Stars property were created; full results remain in Technical Result JSON / Calculation Audit JSON and the readable Chart page body.

A disposable live Chart was **not** created merely for testing, so the user's Notion workspace was not polluted. The automated contract test verifies the save payload and the live schema inspection verifies that those mapped properties exist.

## AI boundary

The Phase 2 calculation files contain no Workers AI calls. Natal AI receives Phase 2 values as locked input and its system prompt explicitly prohibits changing, replacing, inventing or removing Useful/Favourable/Unfavourable Elements, Symbolic Stars or Twelve Stars.

## Lunar dependency build note

Runtime Lunar conversion is offline and no KASI API key is required. The project pins `korean-lunar-calendar` `0.4.0`. The build sandbox could not reach the npm registry, so the regression run used a **temporary API-compatible test double** only for the Lunar package import, covering the project's certified ordinary/leap fixtures. That temporary `node_modules` directory is excluded from the final ZIP. The public 0.4.0 package source and README were independently inspected and document the same offline API, leap-month validation and supported range. On the user's machine, `npm install` retrieves the real pinned dependency before tests/deployment.

## Static validation

- Worker/server JavaScript syntax: PASS
- Phase 1 module syntax: PASS
- Phase 2 module syntax: PASS
- browser Phase 1/2 module syntax: PASS
- inline browser JavaScript syntax: PASS
- HTML duplicate IDs: none
- active source has no `KASI_SERVICE_KEY` runtime dependency

## Deployment validation

A Cloudflare `wrangler deploy --dry-run` was not executed inside this build sandbox because Wrangler was not installed and registry access was unavailable. Both update/deploy helpers run `npm install` and the complete `npm test` suite **before** invoking Wrangler, so deployment stops automatically if dependency installation or regression tests fail.

## Methodological scope

The release intentionally calculates only the four registered Symbolic Star rules. Other named 신살 remain research/glossary concepts until their trigger tables are explicitly sourced, versioned and tested. No ForceTeller mismatch automatically changes the deterministic methods.
