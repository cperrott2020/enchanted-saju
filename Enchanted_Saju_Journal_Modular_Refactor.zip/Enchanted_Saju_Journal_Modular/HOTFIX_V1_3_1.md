# v1.3.1 AI Daily Reading hotfix

This hotfix fixes `Workers AI response is missing overall_theme`.

The deterministic Daily Luck engine was already working. The failure was caused by expecting a strict JSON-schema response from GLM-4.7-Flash. v1.3.1 now requests ordinary text and accepts the common Workers AI response envelopes.

## Update
1. Extract this ZIP.
2. Double-click `update_existing_windows.bat`.
3. Open the same workers.dev URL and press Ctrl+F5.
4. In Daily Luck + AI Reading, click **Regenerate AI Daily Reading**.

You do not need to regenerate the calculated Daily Luck record.

The AI write boundary is unchanged: the Worker PATCHes exactly one Notion property, `Daily Reading`.
