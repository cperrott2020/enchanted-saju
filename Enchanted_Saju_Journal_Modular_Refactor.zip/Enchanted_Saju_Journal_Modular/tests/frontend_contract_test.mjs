import { frontendSource } from './frontend_source.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const html = frontendSource;
const worker = fs.readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');

for (const page of ['today','my-saju','luck-calendar','calculator','people','research','glossary']) {
  assert.match(html, new RegExp(`id=["']page-${page}["']`), `missing page-${page}`);
}
for (const label of ['Research Inbox','Compatibility Tests','Lunar dates are converted offline','Chart Strength','Useful / Favourable / Unfavourable Elements','Wonjin · 원진']) {
  assert.ok(html.includes(label), `missing UI contract text: ${label}`);
}
for (const route of ['/api/people','/api/chart','/api/concepts','/api/luck/annual','/api/luck/monthly','/api/luck/calendar','/api/natal/interpret','/api/research/fetch-url','/api/research/youtube','/api/research/analyze','/api/research/upload-file','/api/research/save']) {
  assert.ok(worker.includes(route), `missing route: ${route}`);
}
assert.ok(worker.includes('Technical Result JSON'), 'chart Technical Result JSON persistence missing');
assert.ok(worker.includes('Calculation Audit JSON'), 'chart Calculation Audit JSON persistence missing');
assert.ok(worker.includes('Current Revision'), 'chart revision persistence missing');
assert.ok(worker.includes("video_id:videoId"), 'YouTube video_id metadata missing');

console.log('frontend_contract_test: PASS');
