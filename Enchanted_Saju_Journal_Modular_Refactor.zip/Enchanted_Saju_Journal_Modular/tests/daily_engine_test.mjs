import assert from 'node:assert/strict';
import { calculateDailyContext, parsePillarText, gregorianJDN, pillarLabel } from '../src/daily_engine.js';

const anchor=((gregorianJDN(1949,10,1)+49)%60+60)%60;
assert.equal(anchor,0);
assert.equal(pillarLabel(anchor%10,anchor%12),'Gap-Ja (甲子)');

const natal={
  year:parsePillarText('Gap-Ja (甲子)'),
  month:parsePillarText('Byeong-In (丙寅)'),
  day:parsePillarText('Eul-Mi (乙未)'),
  hour:parsePillarText('Jeong-Chuk (丁丑)')
};
const r=calculateDailyContext({date:'2026-09-25',timezone:'Asia/Seoul',natal});
assert.equal(r.year.label,'Byeong-O (丙午)');
assert.equal(r.month.label,'Jeong-Yu (丁酉)');
assert.equal(r.day.label,'Im-In (壬寅)');
assert.equal(r.day.ten_god.ko,'정인');
console.log('daily_engine_test: PASS');
