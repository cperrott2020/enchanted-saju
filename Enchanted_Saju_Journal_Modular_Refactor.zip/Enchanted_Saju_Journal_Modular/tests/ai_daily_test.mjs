import assert from 'node:assert/strict';
import { parsePillarText, calculateDailyContext } from '../src/daily_engine.js';
import {
  DEFAULT_AI_MODEL, lockedDailyFacts, buildDailyAiMessages,
  extractAiReadingText, formatDailyReadingText
} from '../src/ai_daily.js';

const natal={
  year:parsePillarText('Gap-Ja (甲子)'),
  month:parsePillarText('Byeong-In (丙寅)'),
  day:parsePillarText('Eul-Mi (乙未)'),
  hour:parsePillarText('Jeong-Chuk (丁丑)')
};
const calculated=calculateDailyContext({date:'2026-09-25',timezone:'Asia/Seoul',natal});
const currentMajor={properties:{
  'Cycle':{title:[{plain_text:'Major Luck 3 · Mu-Jin (戊辰)'}]},
  'Stem':{rich_text:[{plain_text:'戊 무 · Mu'}]},
  'Branch':{rich_text:[{plain_text:'辰 진 · Jin'}]},
  'Element':{select:{name:'Earth'}},
  'Ten God':{rich_text:[{plain_text:'Direct Wealth · 정재 正財'}]}
}};
const p={date:'2026-09-25',timezone:'Asia/Seoul',natal,calculated,currentMajor};

const facts=lockedDailyFacts(p);
assert.equal(facts.day_pillar,'Im-In (壬寅)');
assert.equal(facts.daily_ten_god.ko,'정인');
assert.equal(facts.year_pillar,'Byeong-O (丙午)');
assert.equal(facts.month_pillar,'Jeong-Yu (丁酉)');

const messages=buildDailyAiMessages(p,[]);
assert.equal(messages.length,2);
assert.match(messages[0].content,/NEVER recalculate/i);
assert.match(messages[0].content,/immutable/i);
assert.match(messages[1].content,/Im-In \(壬寅\)/);

const structuredResponse={response:{
  overall_theme:'Keep the day reflective and observant.',
  day_master_relationship:'Use the supplied relationship as a lens for pacing and receptivity.',
  ten_god_theme:'The supplied Ten God theme may foreground learning, support, or reflection.',
  cycle_context:'Notice how the day sits inside the broader stored luck-cycle context without treating it as fate.',
  interaction_context:'Use the listed interactions as symbolic points of attention rather than predictions.',
  practical_focus:'Prioritise one or two manageable tasks and leave room to review how the day actually felt.',
  reflection_prompt:'What did today make easier to notice?'
}};
const structuredText=extractAiReadingText(structuredResponse);
assert.match(structuredText,/Overall Theme/i);
assert.match(structuredText,/Keep the day reflective/);

const openAiShape={choices:[{message:{content:`Overall theme
Keep the day reflective and observant.

Day Master relationship
Use the supplied relationship as a lens for pacing and receptivity.

Ten God theme
The supplied Ten God theme may foreground learning, support, or reflection.

Luck-cycle context
Notice how the day sits inside the broader stored luck-cycle context without treating it as fate.

Natal interactions
Use the listed interactions as symbolic points of attention rather than predictions.

Practical focus
Prioritise one or two manageable tasks and leave room to review how the day actually felt.

Reflection prompt
What did today make easier to notice?`}}]};
const aiText=extractAiReadingText(openAiShape);
assert.match(aiText,/Reflection prompt/i);
const text=formatDailyReadingText(p,aiText,DEFAULT_AI_MODEL);
assert.match(text,/Day Pillar: Im-In \(壬寅\)/);
assert.match(text,/Ten God: Nurturer God · 정인 正印 · Direct Resource/);
assert.match(text,/Year Pillar: Byeong-O \(丙午\)/);
assert.match(text,/Month Pillar: Jeong-Yu \(丁酉\)/);
assert.match(text,/AI can write only this Daily Reading text/);
console.log('ai_daily_test: PASS');
