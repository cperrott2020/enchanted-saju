import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const expected={
  "src/daily_engine.js": "efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785",
  "src/journal_layout.js": "a846d78cf82651d1361180b64de859d9ce64f151b213455f3d0bc8f061ad1a90",
  "src/luck_explorer.js": "77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0",
  "src/solar_terms.js": "8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb"
};
for(const [file,hash] of Object.entries(expected)){const bytes=fs.readFileSync(new URL('../'+file, import.meta.url));const actual=crypto.createHash('sha256').update(bytes).digest('hex');assert.equal(actual,hash,`${file} changed during Phase 1`);}
for(const file of ['../src/phase1/lunar_conversion.js','../src/phase1/weighted_analysis.js','../src/phase1/chart_strength.js']){const text=fs.readFileSync(new URL(file,import.meta.url),'utf8');assert.ok(!/env\.AI|AI\.run|Workers AI/i.test(text),`${file} must not call AI`);}
console.log('phase1_regression_guard_test: PASS');
