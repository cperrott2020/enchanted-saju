import { frontendSource } from './frontend_source.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JEWEL_TEN_GOD_TERMS, decorateConcept, preferredTenGodName, INITIAL_SOURCE_MANIFEST } from '../src/knowledge_pack.js';
import { JEWEL_WHY_PART1_SOURCE_TEXT, JEWEL_WHY_PART2_SOURCE_TEXT } from '../src/knowledge_source_text.js';

const expected={
  '比肩':'Self God','劫財':'Rival God','食神':'Creator God','傷官':'Rebel God','偏財':'Entrepreneur God',
  '正財':'Provider God','偏官':'Wild Card God','正官':'Official God','偏印':'Mystic God','正印':'Nurturer God'
};
assert.deepEqual(Object.fromEntries(Object.entries(JEWEL_TEN_GOD_TERMS).map(([h,t])=>[h,t.preferred])),expected);
assert.deepEqual(Object.fromEntries(Object.entries(JEWEL_TEN_GOD_TERMS).map(([h,t])=>[h,t.category])),{
  '比肩':'Me','劫財':'Me','食神':'Output','傷官':'Output','偏財':'Wealth','正財':'Wealth','偏官':'Authority','正官':'Authority','偏印':'Input','正印':'Input'
});
const official=decorateConcept({id:'old-official',english:'Direct Officer',korean:'정관',hanja:'正官',romanisation:'Jeonggwan',category:'Ten Gods'});
assert.equal(official.preferred_display_name,'Official God');
assert.equal(official.technical_english_name,'Direct Officer');
assert.equal(official.jewel_sjpj_name,'Official God');
assert.equal(official.jewel_ten_god_category,'Authority');
assert(official.search_aliases.includes('Direct Officer'));
assert(official.search_aliases.includes('Official God'));
assert.equal(preferredTenGodName('Direct Officer'),'Official God');
assert.equal(preferredTenGodName({hanja:'偏印'}),'Mystic God');
assert(INITIAL_SOURCE_MANIFEST.some(x=>x.source_id==='SRC-JEWEL-003'&&x.embedded_key==='jewel_why_part1'));
assert(INITIAL_SOURCE_MANIFEST.some(x=>x.source_id==='SRC-JEWEL-004'&&x.embedded_key==='jewel_why_part2'&&x.priority===5));
assert(JEWEL_WHY_PART1_SOURCE_TEXT.includes('Five Elements Help Circle'));
assert(JEWEL_WHY_PART2_SOURCE_TEXT.includes('Self God'));
assert(JEWEL_WHY_PART2_SOURCE_TEXT.includes('Nurturer God'));
const ui=frontendSource;
for(const term of Object.values(expected))assert(ui.includes(term),`UI missing ${term}`);
assert(ui.includes('JewelSJPJ Ten Gods'));
assert(ui.includes('accessibleTenGodNameUI'));
const backend=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
assert(backend.includes("source.embedded_key==='jewel_why_part1'"));
assert(backend.includes("source.embedded_key==='jewel_why_part2'"));
assert(backend.includes('preferredTenGodName(d.ten_god)'));
console.log('jewel_ten_gods_update_test: PASS');
