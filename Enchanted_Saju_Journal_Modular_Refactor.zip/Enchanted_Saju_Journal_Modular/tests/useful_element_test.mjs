import assert from 'node:assert/strict';
import fs from 'node:fs';
import { deriveUsefulElements } from '../src/phase2/useful_elements.js';
import { PHASE2_METHODS } from '../src/phase2/methods.js';
import { fireDayMaster, forceReferencePillars } from './phase2_fixtures.mjs';

const weakOutput={status:'calculated',classification:'Weak',method:'workbook-support-drain-monthbranch-v1',support_score:2,drain_score:6,borderline:false,role_counts:{Companion:1,Resource:1,Output:4,Wealth:1,Authority:1}};
const a=deriveUsefulElements({day_master:fireDayMaster,pillars:forceReferencePillars,strength:weakOutput});
const b=deriveUsefulElements({day_master:fireDayMaster,pillars:forceReferencePillars,strength:weakOutput});
assert.deepEqual(a,b,'identical chart + method must give identical Useful Element');
assert.equal(a.useful_element.method,PHASE2_METHODS.useful_element);
assert.equal(a.useful_element.result.english,'Wood','weak Fire DM with clearly dominant Output uses Resource/Wood');
assert.equal(a.favourable_element.result.english,'Water','Water produces Wood');
assert.equal(a.unfavourable_element.result[0].english,'Metal','Metal controls Wood');

const weakDefault={...weakOutput,role_counts:{Companion:1,Resource:1,Output:2,Wealth:2,Authority:2}};
const w=deriveUsefulElements({day_master:fireDayMaster,pillars:forceReferencePillars,strength:weakDefault});
assert.equal(w.useful_element.result.english,'Fire','weak default uses Companion/own element');

const strongResource={status:'calculated',classification:'Strong',method:'workbook-support-drain-monthbranch-v1',support_score:6,drain_score:2,borderline:false,role_counts:{Companion:2,Resource:4,Output:1,Wealth:1,Authority:0}};
const s=deriveUsefulElements({day_master:fireDayMaster,pillars:forceReferencePillars,strength:strongResource});
assert.equal(s.useful_element.result.english,'Metal','strong Resource-heavy Fire DM uses Wealth/Metal');

const borderline={...strongResource,borderline:true,month_branch_effect:'Support'};
const p=deriveUsefulElements({day_master:fireDayMaster,pillars:forceReferencePillars,strength:borderline});
assert.equal(p.useful_element.confidence,'provisional');

const source=fs.readFileSync(new URL('../src/phase2/useful_elements.js',import.meta.url),'utf8');
assert.ok(!/env\.AI|AI\.run|Workers AI/i.test(source),'Useful Element module must not call AI');
console.log('useful_element_test: PASS');
