import assert from 'node:assert/strict';
import fs from 'node:fs';
import { calculateTwelveStars } from '../src/phase2/twelve_stars.js';
import { forceReferencePillars } from './phase2_fixtures.mjs';

const r=calculateTwelveStars(forceReferencePillars);
assert.equal(r.method,'year-branch-trine-12sinsal-v1');
assert.equal(r.reference_value,'午');
assert.equal(r.pillars.hour.korean,'겁살');
assert.equal(r.pillars.day.korean,'지살');
assert.equal(r.pillars.month.korean,'월살');
assert.equal(r.pillars.year.korean,'장성살');
assert.ok(!('growth_stage' in r),'Twelve Stars object must not contain Twelve Growth Stages');
for(const x of Object.values(r.pillars)){assert.equal(x.method_version,'year-branch-trine-12sinsal-v1');assert.ok(x.trigger);}
const source=fs.readFileSync(new URL('../src/phase2/twelve_stars.js',import.meta.url),'utf8');
assert.ok(!/growth_stage|growth_stages/i.test(source),'Twelve Stars implementation must be separate from growth-stage calculation');
assert.ok(!/env\.AI|AI\.run|Workers AI/i.test(source));
console.log('twelve_stars_test: PASS');
