import assert from 'node:assert/strict';
import { parsePillarText, relationshipEventsForPillar } from '../src/daily_engine.js';
import { annualLuckRange, monthlyLuckYear, dailyLuckMonth } from '../src/luck_explorer.js';
const natal={
  year:parsePillarText('Gap-Ja (甲子)'),
  month:parsePillarText('Byeong-In (丙寅)'),
  day:parsePillarText('Eul-Mi (乙未)'),
  hour:parsePillarText('Jeong-Chuk (丁丑)')
};
const annual=annualLuckRange({startYear:2026,endYear:2026,timezone:'Asia/Seoul',natal});
assert.equal(annual.length,1); assert.equal(annual[0].label,'Byeong-O (丙午)');
const monthly=monthlyLuckYear({year:2026,timezone:'Asia/Seoul',natal});
assert.equal(monthly.length,12);
assert.ok(monthly.some(x=>x.label==='Jeong-Yu (丁酉)'),'2026 solar months should include Jeong-Yu');
const days=dailyLuckMonth({year:2026,month:9,timezone:'Asia/Seoul',natal});
assert.equal(days.length,30); assert.equal(days[24].date,'2026-09-25'); assert.equal(days[24].day.label,'Im-In (壬寅)');
const wonjin=relationshipEventsForPillar(parsePillarText('Gap-In (甲寅)'),{test:parsePillarText('Eul-Yu (乙酉)')},'test-layer');
assert.ok(wonjin.some(x=>x.relationship==='Wonjin'));
assert.ok(wonjin.some(x=>x.method_version==='wonjin-pairs-v1'));
console.log('luck_explorer_test: PASS');
