import assert from 'node:assert/strict';
import {calculateChartStrength} from '../src/phase1/chart_strength.js';
import {samplePillars} from './fixtures.mjs';

const s=calculateChartStrength(samplePillars,'Wood');
assert.equal(s.status,'calculated');
assert.equal(s.support_score+s.drain_score,8);
assert.equal(s.strength_index,s.score*100);
assert.ok(['Strong','Weak'].includes(s.classification));
assert.equal(s.borderline,Math.abs(s.support_score-s.drain_score)<=2);
assert.equal(s.method,'workbook-support-drain-monthbranch-v1');
if(s.borderline){
  assert.ok(['Support','Drain'].includes(s.month_branch_effect));
  assert.match(s.decision_rule,/Month Branch/i);
}
const unknown={...samplePillars,hour:null};
const u=calculateChartStrength(unknown,'Wood');
assert.equal(u.status,'unavailable');
assert.equal(u.classification,null);
// The supplied sample itself is a 5/3 borderline case; Month Branch 寅 main qi 甲 supports a Wood Day Master.
assert.equal(s.support_score,5);
assert.equal(s.drain_score,3);
assert.equal(s.month_branch_effect,'Support');
assert.equal(s.classification,'Strong');
console.log('chart_strength_test: PASS');
