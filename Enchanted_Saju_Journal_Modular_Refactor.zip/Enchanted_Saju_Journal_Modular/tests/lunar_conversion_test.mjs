import assert from 'node:assert/strict';
import { convertLunarToSolarOffline, LUNAR_CONVERSION_METHOD, OFFLINE_LUNAR_RANGE } from '../src/phase1/lunar_conversion.js';

assert.equal(LUNAR_CONVERSION_METHOD,'korean-lunar-calendar-0.4.0-kari-offline-v1');
assert.equal(OFFLINE_LUNAR_RANGE.max,'2050-11-18');

const ordinary=await convertLunarToSolarOffline({lunar_year:1956,lunar_month:1,lunar_day:21,lunar_leap_month:false});
assert.equal(ordinary.normalised_gregorian_date,'1956-03-03');
assert.equal(ordinary.network_required,false);

const modern=await convertLunarToSolarOffline({lunar_year:2023,lunar_month:1,lunar_day:20,lunar_leap_month:false});
assert.equal(modern.normalised_gregorian_date,'2023-02-10');

const leap=await convertLunarToSolarOffline({lunar_year:2017,lunar_month:5,lunar_day:1,lunar_leap_month:true});
assert.equal(leap.normalised_gregorian_date,'2017-06-24');
assert.equal(leap.lunar_leap_month,true);

await assert.rejects(()=>convertLunarToSolarOffline({lunar_year:1799,lunar_month:12,lunar_day:1,lunar_leap_month:false}),/Unsupported Lunar date/);
await assert.rejects(()=>convertLunarToSolarOffline({lunar_year:2017,lunar_month:3,lunar_day:1,lunar_leap_month:true}),/leap|preserve|invalid|nonexistent/i);

console.log('lunar_conversion_test: PASS');
