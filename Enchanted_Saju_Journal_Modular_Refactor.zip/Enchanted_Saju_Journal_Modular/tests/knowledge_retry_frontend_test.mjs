import { frontendSource } from './frontend_source.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=frontendSource;
for(const needle of ['Retry Failed Sources','Pause Import','Import / Resume Pack','KNOWLEDGE_QUEUE_STATE_KEY','enchantedSajuKnowledgeQueueV2','const backoff=[5,15,30]','queueWait(60000','queueWait(4000','Three consecutive temporary Saju Atelier failures','already saved as Ready / Needs Review and will be skipped','currently missing source records','temporarily unavailable','saved retry queue']) assert(s.includes(needle),`missing ${needle}`);
assert(s.includes("!!x?.notion_source_id||['Ready','Needs Review'].includes"),'already-imported skip predicate missing');
assert(s.includes('storageSetJson(KNOWLEDGE_QUEUE_STATE_KEY'),'resume persistence missing');
console.log('knowledge_retry_frontend_test: PASS');
