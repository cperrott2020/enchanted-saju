import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const expected={
  "src/phase1/lunar_conversion.js": "6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2",
  "src/phase1/weighted_analysis.js": "d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca",
  "src/phase1/chart_strength.js": "2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff",
  "public/phase1-browser.js": "e1539a711184a908681730097e9d96d06cd7318adaa4af799009597c84b00a6d"
};
for(const [file,hash] of Object.entries(expected)){const bytes=fs.readFileSync(new URL('../'+file,import.meta.url));const actual=crypto.createHash('sha256').update(bytes).digest('hex');assert.equal(actual,hash,`Phase 1 implementation changed during Phase 2: ${file}`);}
const registry=fs.readFileSync(new URL('../src/method_registry.js',import.meta.url),'utf8');
for(const id of ['korean-lunar-calendar-0.4.0-kari-offline-v1','transparent-hidden-stem-equal-allocation-v1','workbook-support-drain-monthbranch-v1']) assert.ok(registry.includes(id),`Phase 1 method ID missing: ${id}`);
console.log('phase2_regression_guard_test: PASS');
