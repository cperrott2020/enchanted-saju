import { frontendSource } from './frontend_source.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=frontendSource;
for(const needle of ['JEWEL_STEM_NAMES','Blue Tree','Black Mist','conceptSearchKey','preferred_display_name','Source-specific terminology','Source metaphors','Initial Knowledge Source Pack','importInitialKnowledgePack','/api/knowledge-pack/ensure-concepts','/api/knowledge-pack/import-source']) assert(s.includes(needle),`missing ${needle}`);
assert(s.includes('Search accepts English, Hangul, Hanja, romanisation and verified aliases.'));
console.log('update4_frontend_test: PASS');
