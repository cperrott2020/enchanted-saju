import fs from 'node:fs';import assert from 'node:assert/strict';
const s=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
for(const route of ['/api/journal/day','/api/journal/save','/api/journal/analytics','/api/life-events','/api/life-events/save','/api/timeline','/api/jiazi'])assert.ok(s.includes(route),route);
for(const prop of ['Social Energy','Stress','Resonance','Highlights','Challenges','Custom Tags'])assert.ok(s.includes(`'${prop}'`),prop);
assert.ok(s.includes("{ property: 'Date', date: { equals: p.date } }, { property: 'Person', relation: { contains: p.person.id } }"),'Profile+Date Daily Luck isolation must remain');
assert.ok(s.includes("'Person':relation([selected.person.id])"),'Life events must relate to Person ID');
assert.ok(s.includes('Personal Journal Observation')||s.includes("type:'descriptive_correlation'"));
assert.ok(s.includes('Array.from({length:60}'),'60-Jiazi reference must have 60 entries');
console.log('update2_backend_contract_test: PASS');
