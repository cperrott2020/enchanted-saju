import assert from 'node:assert/strict';
import { monthlyLuckYear } from '../src/luck_explorer.js';
import { parsePillarText, localDateTimeString } from '../src/daily_engine.js';

const natal={
  year:parsePillarText('Im-O (壬午)'),
  month:parsePillarText('Gap-Jin (甲辰)'),
  day:parsePillarText('Byeong-In (丙寅)'),
  hour:parsePillarText('Jeong-Chuk (丁丑)')
};
const rows=monthlyLuckYear({year:2026,timezone:'Asia/Seoul',natal});
assert.equal(rows.length,12);
assert.deepEqual(rows.map(x=>x.label),[
  'Gyeong-In (庚寅)','Sin-Myo (辛卯)','Im-Jin (壬辰)','Gye-Sa (癸巳)',
  'Gap-O (甲午)','Eul-Mi (乙未)','Byeong-Sin (丙申)','Jeong-Yu (丁酉)',
  'Mu-Sul (戊戌)','Gi-Hae (己亥)','Gyeong-Ja (庚子)','Sin-Chuk (辛丑)'
]);
assert.equal(localDateTimeString(Date.parse(rows[0].start_utc),'Asia/Seoul'),'2026-02-04 05:02');
assert.equal(localDateTimeString(Date.parse(rows[0].start_utc),'Europe/Dublin'),'2026-02-03 20:02');
console.log('month_boundary_display_test: PASS');
