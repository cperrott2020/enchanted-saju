import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=[
  'public/index.html','public/css/styles.css','public/phase1-browser.js','public/phase2-browser.js',
  ...fs.readdirSync(path.join(root,'public/data')).filter(x=>x.endsWith('.js')).sort().map(x=>`public/data/${x}`),
  ...fs.readdirSync(path.join(root,'public/js')).filter(x=>x.endsWith('.js')).sort().map(x=>`public/js/${x}`)
];
export const frontendSource=files
  .map(rel=>`/* FILE: ${rel} */\n${fs.readFileSync(path.join(root,rel),'utf8')}`)
  .join('\n\n');
export const frontendHtml=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
