import assert from 'node:assert/strict';
import {
  splitAiSections,
  extractAiBodyFromStoredReading,
  blockPlainText,
  generatedContainerBlock,
  calculatedContextBlock,
  aiReadingBlock,
  journalScaffoldBlocks,
  todayHeaderBlock,
  aiUnavailableBlock,
  savedDailyLuckBlocks,
  TODAY_DASHBOARD_VERSION,
  GENERATED_CONTAINER_MARKER,
  CALCULATED_CONTEXT_MARKER,
  AI_READING_MARKER,
  JOURNAL_MARKER
} from '../src/journal_layout.js';

const ai = `Overall theme\nA calm but purposeful day.\n\nDay Master relationship\nBalance initiative with flexibility.\n\nTen God theme\nUse pressure constructively.\n\nLuck-cycle context\nStay grounded in the longer cycle.\n\nNatal interactions\nNotice both connection and friction.\n\nPractical focus\nFinish one important task.\n\nReflection prompt\nWhat deserves your clearest attention today?`;
const sections = splitAiSections(ai);
assert.equal(sections.length, 7);
assert.equal(sections[0].heading, '🌿 Overall Theme');
assert.match(sections[6].text, /clearest attention/);

const stored = `🌸 Daily Saju Reflection · 2026-09-25\n\nLOCKED CALCULATED CONTEXT\nDay Pillar: Im-In (壬寅)\n\n${ai}\n\nAI interpretation: @cf/test · Calculated facts supplied by deterministic.`;
const extracted = extractAiBodyFromStoredReading(stored);
assert.ok(extracted.startsWith('Overall theme'));
assert.ok(!extracted.includes('LOCKED CALCULATED CONTEXT'));
assert.ok(!extracted.includes('AI interpretation:'));

assert.equal(blockPlainText({type:'callout',callout:{rich_text:[{plain_text:GENERATED_CONTAINER_MARKER}]}}), GENERATED_CONTAINER_MARKER);
assert.equal(generatedContainerBlock().callout.rich_text[0].text.content, GENERATED_CONTAINER_MARKER);
assert.equal(calculatedContextBlock().callout.rich_text[0].text.content, CALCULATED_CONTEXT_MARKER);
assert.equal(aiReadingBlock().callout.rich_text[0].text.content, AI_READING_MARKER);
assert.ok(journalScaffoldBlocks().some(b => b.type === 'heading_2' && b.heading_2.rich_text[0].text.content === JOURNAL_MARKER));

const mockP={date:'2026-09-25'};
assert.match(todayHeaderBlock(mockP).callout.rich_text[0].text.content,/2026-09-25/);
assert.equal(aiUnavailableBlock().type,'callout');
const saved=savedDailyLuckBlocks('https://www.notion.so/example','2026-09-25 · Im-In (壬寅)','Asia/Seoul');
assert.ok(saved.some(b=>b.type==='callout'));
assert.ok(saved.some(b=>b.type==='paragraph'));
assert.match(TODAY_DASHBOARD_VERSION,/live-today-dashboard/);

console.log('journal_layout_test: PASS');
