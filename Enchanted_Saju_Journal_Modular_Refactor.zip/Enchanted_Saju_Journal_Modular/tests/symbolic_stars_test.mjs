import assert from 'node:assert/strict';
import fs from 'node:fs';
import { calculateSymbolicStars } from '../src/phase2/symbolic_stars.js';
import { forceReferencePillars } from './phase2_fixtures.mjs';

const base=calculateSymbolicStars(forceReferencePillars);
assert.equal(base.method,'symbolic-stars-four-rule-set-v1');
assert.equal(base.enabled_rules.length,4);
assert.ok(base.detected.some(x=>x.star==='Heavenly Nobleman'&&x.detected_in.includes('hour Branch')),'丙 Day Stem should detect 亥 Heavenly Nobleman');
assert.ok(!base.detected.some(x=>x.star==='Peach Blossom'),'fixture has no 卯 Peach Blossom target');

function withHourBranch(index,hanja){return {...forceReferencePillars,hour:{...forceReferencePillars.hour,branch:{...forceReferencePillars.hour.branch,index,hanja}}};}
for(const [index,hanja,name] of [[3,'卯','Peach Blossom'],[8,'申','Travelling Horse'],[10,'戌','Flower Canopy']]){
  const r=calculateSymbolicStars(withHourBranch(index,hanja));
  assert.ok(r.detected.some(x=>x.star===name&&x.detected_in.includes('hour Branch')),`${name} trigger should detect`);
}
const none=calculateSymbolicStars(withHourBranch(1,'丑'));
assert.ok(!none.detected.some(x=>['Peach Blossom','Travelling Horse','Flower Canopy'].includes(x.star)&&x.detected_in.includes('hour Branch')),'non-target branch must not create false trine star');
for(const hit of base.detected){assert.ok(hit.method_version);assert.ok(hit.trigger);assert.ok(hit.reference_pillar);assert.ok(Array.isArray(hit.detected_in));}
const source=fs.readFileSync(new URL('../src/phase2/symbolic_stars.js',import.meta.url),'utf8');
assert.ok(!/env\.AI|AI\.run|Workers AI/i.test(source));
console.log('symbolic_stars_test: PASS');
