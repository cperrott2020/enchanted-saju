import assert from 'node:assert/strict';
import {
  todayHeaderBlock,
  savedDailyLuckBlocks,
  aiUnavailableBlock,
  TODAY_DASHBOARD_VERSION
} from '../src/journal_layout.js';

const p = { date: '2026-09-25' };
const header = todayHeaderBlock(p);
assert.equal(header.type, 'callout');
assert.match(header.callout.rich_text[0].text.content, /Today · 2026-09-25/);

const saved = savedDailyLuckBlocks(
  'https://www.notion.so/abcdef',
  '2026-09-25 · Im-In (壬寅)',
  'Asia/Seoul'
);
assert.equal(saved[0].type, 'divider');
assert.equal(saved[1].type, 'callout');
assert.match(saved[2].paragraph.rich_text[0].text.content, /replaced automatically/);

assert.equal(aiUnavailableBlock().type, 'callout');
assert.match(TODAY_DASHBOARD_VERSION, /live-today-dashboard/);
console.log('today_dashboard_test: PASS');
