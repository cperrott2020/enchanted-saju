import fs from 'node:fs';
import assert from 'node:assert/strict';
const src=fs.readFileSync(new URL('../src/index.js', import.meta.url),'utf8');
const wrangler=fs.readFileSync(new URL('../wrangler.toml', import.meta.url),'utf8');
const loop=src.slice(src.indexOf('for (const [key, titleName] of Object.entries(TARGET_TITLES))'), src.indexOf('if (missing.length)', src.indexOf('for (const [key, titleName] of Object.entries(TARGET_TITLES))')));
assert.ok(loop.indexOf('const candidate = configured[key]') < loop.indexOf('const exact = byTitle.get'), 'Configured data-source IDs must be preferred before title discovery');
for (const id of ['809d7190-6e92-83cb-a0a2-870acced4b32','03bd7190-6e92-82e8-a221-872314de70bb','3afd7190-6e92-8334-ba46-075fb5f99099','c97d7190-6e92-826c-aa6f-07fb0a455e64','7cfd7190-6e92-83a7-939a-071e83a28769','770d7190-6e92-82c7-b954-070647d8ea4f']) assert.ok(wrangler.includes(id), `Missing pinned data source ${id}`);
assert.ok(src.includes("'Birth Time Status': select(birthStatus)"));
console.log('notion_target_hotfix_test: PASS');
