import fs from 'node:fs';
import assert from 'node:assert/strict';
const worker=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
for(const prop of ["'Useful Element': relation","'Favourable Element': relation","'Unfavourable Element': relation","'Useful Element Method'","'Symbolic Star Method'","'Technical Result JSON'","'Calculation Audit JSON'"]) assert.ok(worker.includes(prop),`Missing Notion Chart mapping: ${prop}`);
assert.ok(worker.includes('Advanced Deterministic Analysis'));
assert.ok(worker.includes('Twelve Stars · 십이신살'));
assert.ok(worker.includes('This is separate from Twelve Growth Stages'));
assert.ok(worker.includes('Phase 2 deterministic results are LOCKED INPUT'));
console.log('notion_phase2_contract_test: PASS');
