import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
for(const needle of ['/api/knowledge-pack','/api/knowledge-pack/ensure-concepts','/api/knowledge-pack/import-source','loadGlossaryConceptIndex','ESJ_SOURCE_META:','Terminology Aliases','knowledge_pack_version','relevantSourceSnippet','source_retrieval_context','day_pillar']) assert(s.includes(needle),`missing ${needle}`);
assert(s.includes("mergeGlossaryConcepts(await loadConceptIndex"));
assert(s.includes("parent_only"));
console.log('update4_backend_contract_test: PASS');
