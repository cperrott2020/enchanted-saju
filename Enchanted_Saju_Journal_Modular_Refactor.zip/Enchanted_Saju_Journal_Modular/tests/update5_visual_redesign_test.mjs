import { frontendSource } from './frontend_source.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=frontendSource;
for(const needle of [
  'UPDATE 5 — ENCHANTED BOTANICAL FIELD JOURNAL VISUAL SYSTEM',
  '--cream:#F5EFE3','--sage:#AAB69D','--moss:#5F6955','--dusty-pink:#D7A5AF',
  '/assets/images/decorative/fairy-ring.svg','/assets/images/decorative/botanical-corner.svg',
  'sjpjTypeRecordUI','sjpjTypeArtMarkup','sjpjTypeArtFromConceptUI',
  'jiazi-cabinet','profile-library-card','compare-type-heroes',
  'a personal four-pillars field journal','Decorative SJPJ identity artwork · not a calculation rule',
  '@media (prefers-reduced-motion:reduce)'
]) assert(html.includes(needle),`missing visual-system contract: ${needle}`);
const manifest=JSON.parse(fs.readFileSync(path.join(root,'public/assets/images/avatars/manifest.json'),'utf8'));
assert.equal(manifest.length,60,'all 60 SJPJ types must have manifest entries');
assert.equal(new Set(manifest.map(x=>x.number)).size,60);
assert.equal(new Set(manifest.map(x=>x.name)).size,60);
let svgCount=0;
for(const type of manifest){
  for(const key of ['emblem','card']){
    const rel=type[key].replace(/^\//,'public/');
    const f=path.join(root,rel);
    assert(fs.existsSync(f),`missing ${key} asset for ${type.name}`);
    const svg=fs.readFileSync(f,'utf8');
    assert(svg.includes('<svg'),`${f} is not SVG`);
    assert(/decorative|Decoration|Decorative/i.test(svg),`${f} must label the art as decorative`);
    svgCount++;
  }
}
assert.equal(svgCount,120);
for(const ornament of ['fairy-ring.svg','botanical-corner.svg','lace-strip.svg','pressed-flower.svg','star-divider.svg']) assert(fs.existsSync(path.join(root,'public/assets/images/decorative',ornament)),`missing ornament ${ornament}`);
const publicFiles=[];
function walk(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,ent.name);if(ent.isDirectory())walk(p);else publicFiles.push(p);}}
walk(path.join(root,'public'));
assert.equal(publicFiles.filter(f=>/\.(jpe?g|png)$/i.test(f)).length,0,'reference mood-board raster images must not be copied into public assets');
console.log('update5_visual_redesign_test: PASS');
