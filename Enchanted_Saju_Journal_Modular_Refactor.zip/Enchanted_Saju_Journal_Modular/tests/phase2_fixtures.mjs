export const forceReferencePillars={
  hour:{stem:{index:5,hanja:'己',element:'Earth',yin_yang:'Yin'},branch:{index:11,hanja:'亥',hidden_stems:[{index:8,hanja:'壬',element:'Water',yin_yang:'Yang'},{index:0,hanja:'甲',element:'Wood',yin_yang:'Yang'}]}},
  day:{stem:{index:2,hanja:'丙',element:'Fire',yin_yang:'Yang'},branch:{index:2,hanja:'寅',hidden_stems:[{index:0,hanja:'甲',element:'Wood',yin_yang:'Yang'},{index:2,hanja:'丙',element:'Fire',yin_yang:'Yang'},{index:4,hanja:'戊',element:'Earth',yin_yang:'Yang'}]}},
  month:{stem:{index:0,hanja:'甲',element:'Wood',yin_yang:'Yang'},branch:{index:4,hanja:'辰',hidden_stems:[{index:4,hanja:'戊',element:'Earth',yin_yang:'Yang'},{index:1,hanja:'乙',element:'Wood',yin_yang:'Yin'},{index:9,hanja:'癸',element:'Water',yin_yang:'Yin'}]}},
  year:{stem:{index:8,hanja:'壬',element:'Water',yin_yang:'Yang'},branch:{index:6,hanja:'午',hidden_stems:[{index:3,hanja:'丁',element:'Fire',yin_yang:'Yin'},{index:5,hanja:'己',element:'Earth',yin_yang:'Yin'}]}}
};
export const fireDayMaster={index:2,hanja:'丙',element:'Fire',yin_yang:'Yang'};
