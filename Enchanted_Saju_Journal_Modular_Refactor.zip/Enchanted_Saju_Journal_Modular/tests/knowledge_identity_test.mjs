import assert from 'node:assert/strict';
import {
  JEWEL_STEM_TERMS, JEWEL_TEN_GOD_TERMS, INITIAL_SOURCE_MANIFEST, jiaziRecords,
  normaliseAliasKey, decorateConcept, mergeGlossaryConcepts, KNOWLEDGE_PACK_VERSION
} from '../src/knowledge_pack.js';
import { JEWEL_GUIDE_SOURCE_TEXT, JEWEL_CELEBRITIES_SOURCE_TEXT } from '../src/knowledge_source_text.js';

assert.match(KNOWLEDGE_PACK_VERSION,/jewel-ten-gods/);
assert.deepEqual(Object.fromEntries(Object.entries(JEWEL_STEM_TERMS).map(([k,v])=>[k,v.preferred])),{
  '甲':'Blue Tree','乙':'Blue Vine','丙':'Red Sun','丁':'Red Moon','戊':'Yellow Mountain','己':'Yellow Garden','庚':'White Sword','辛':'White Jewel','壬':'Black Ocean','癸':'Black Mist'
});
const cycle=jiaziRecords();
assert.equal(cycle.length,60);
assert.equal(new Set(cycle.map(x=>x.concept_id)).size,60);
assert.equal(new Set(cycle.map(x=>x.characters)).size,60);
assert.equal(cycle[0].preferred,'Blue Tree Rat');
assert.equal(cycle[3].preferred,'Red Moon Rabbit');
assert.equal(cycle[20].preferred,'Blue Tree Monkey');
assert.equal(cycle[59].preferred,'Black Mist Pig');
assert.equal(normaliseAliasKey('Jeong-Myo'),normaliseAliasKey('jeong myo'));
assert.equal(normaliseAliasKey('Red Moon Rabbit'),normaliseAliasKey('red-moon rabbit'));
const dm=decorateConcept({id:'n1',english:'Yin Water',korean:'계수',hanja:'癸',romanisation:'Gyesu'});
assert.equal(dm.preferred_display_name,'Black Mist');
assert(dm.search_aliases.includes('Yin Water'));
assert(dm.search_aliases.includes('Black Mist'));
const merged=mergeGlossaryConcepts([{id:'n1',english:'Yin Water',korean:'계수',hanja:'癸'}]);
assert.equal(merged.filter(x=>x.category==='60 Jiazi').length,60);
assert.equal(merged.filter(x=>x.category==='Ten Gods').length,10);
assert.equal(merged.find(x=>x.hanja==='正官').preferred_display_name,'Official God');
assert.equal(JEWEL_TEN_GOD_TERMS['比肩'].preferred,'Self God');
assert.equal(JEWEL_TEN_GOD_TERMS['偏官'].preferred,'Wild Card God');
const urls=INITIAL_SOURCE_MANIFEST.map(x=>x.url).filter(Boolean);
assert.equal(new Set(urls).size,urls.length,'source URLs must be de-duplicated');
assert.equal(INITIAL_SOURCE_MANIFEST.filter(x=>x.parent_source_id==='SRC-ATELIER-001').length,36);
assert(JEWEL_GUIDE_SOURCE_TEXT.includes('Blue Tree Rat'));
assert(JEWEL_GUIDE_SOURCE_TEXT.includes('Red Moon Rabbit'));
assert(JEWEL_CELEBRITIES_SOURCE_TEXT.includes('Blue Tree'));
console.log('knowledge_identity_test: PASS');
