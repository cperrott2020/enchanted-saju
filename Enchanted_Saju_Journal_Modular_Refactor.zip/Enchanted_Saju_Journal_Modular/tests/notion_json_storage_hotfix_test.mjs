import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compactJsonForNotion, technicalResultForNotion, NOTION_JSON_STORAGE_MAX_CHARS} from '../src/notion_json_storage.js';

const repeated=Array.from({length:600},(_,i)=>({i,label:`field-${i}`,reason:'Deterministic calculation evidence with repeated descriptive keys and values.'}));
const big={schema_version:'2.2.0-complete',calculation_audit:{repeated},technical:{repeated}};
const pretty=JSON.stringify(big,null,2);
assert.ok(pretty.length>150000,'fixture must reproduce the old pretty-JSON failure class');
const storage=technicalResultForNotion(big);
assert.equal(storage.calculation_audit,undefined,'Technical Result JSON must not duplicate the full audit');
assert.equal(storage.calculation_audit_storage.property,'Calculation Audit JSON');
const compact=compactJsonForNotion(storage,'Technical Result JSON');
assert.ok(compact.length<NOTION_JSON_STORAGE_MAX_CHARS);
assert.equal(JSON.parse(compact).schema_version,'2.2.0-complete');
const audit=compactJsonForNotion(big.calculation_audit,'Calculation Audit JSON');
assert.deepEqual(JSON.parse(audit).repeated[100].i,100);
assert.throws(()=>compactJsonForNotion({x:'x'.repeat(NOTION_JSON_STORAGE_MAX_CHARS+1000)},'Oversize'),/No truncation was performed/);

const worker=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
assert.ok(worker.includes("compactJsonForNotion(technicalResultForNotion(master), 'Technical Result JSON')"));
assert.ok(worker.includes("compactJsonForNotion(master.calculation_audit, 'Calculation Audit JSON')"));
assert.ok(worker.includes('.slice(0, 95)'),'rich-text storage should allow the compact JSON budget');
assert.ok(!worker.includes('chunkText(text, 1850).slice(0, 70)'),'page-body audit must no longer silently truncate at 70 chunks');
assert.ok(worker.includes('children.slice(i,i+90)'),'large audit blocks must be appended in safe batches');
console.log('notion_json_storage_hotfix_test: PASS');
