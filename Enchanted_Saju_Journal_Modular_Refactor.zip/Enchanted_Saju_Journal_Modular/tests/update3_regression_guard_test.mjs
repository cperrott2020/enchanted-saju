import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const expected={
  "src/daily_engine.js": "efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785",
  "src/solar_terms.js": "8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb",
  "src/luck_explorer.js": "77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0",
  "src/journal_layout.js": "a846d78cf82651d1361180b64de859d9ce64f151b213455f3d0bc8f061ad1a90",
  "src/method_registry.js": "26fc3f70ecaf7406b63e635f03a2ec224cbc80fb98b3483533aef242391dd15b",
  "src/result_schema.js": "1e32aca812202b223dae3553ae118bf7833d9e2a45c3eb7515640549926dc866",
  "src/phase1/lunar_conversion.js": "6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2",
  "src/phase1/weighted_analysis.js": "d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca",
  "src/phase1/chart_strength.js": "2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff",
  "src/phase1/methods.js": "fb2221bedc07e652586165d82c015b0068714e0ff9ce52893e32d00fb584be24",
  "src/phase2/useful_elements.js": "112d93135069292af6158eec9d9764a037f71d935a32749923d2b1c4086ef11c",
  "src/phase2/symbolic_stars.js": "7a8866a5c0308b0abf554d6a02604483b9ec956ef3d527d0da571eeddd3343cc",
  "src/phase2/twelve_stars.js": "aa9251f2e6d7ffe8107a3b8f2daccce4e9dbc26d87209d70fa83d0cd800dd08b",
  "src/phase2/phase2_analysis.js": "2b64309789faf0ed03e82f89f6a5f1d29701a431e017c7b7bc94498851e95a39",
  "src/phase2/methods.js": "13bc5fe62b3e6cb81d03d3574eb9a69bab5d952937065ed298caca2fa0b8d5bd",
  "public/phase1-browser.js": "e1539a711184a908681730097e9d96d06cd7318adaa4af799009597c84b00a6d",
  "public/phase2-browser.js": "d083d538c2d623451c25f5ff033daca051bb5cdb46b2d6e8e8d95a678b420b0a"
};
for(const [file,hash] of Object.entries(expected)){const bytes=fs.readFileSync(new URL('../'+file,import.meta.url));const actual=crypto.createHash('sha256').update(bytes).digest('hex');assert.equal(actual,hash,`${file} changed during Update 3`);}
const feature=fs.readFileSync(new URL('../src/update3_features.js',import.meta.url),'utf8');assert.ok(!/env\.AI|AI\.run|Workers AI/i.test(feature),'Update 3 structural comparison/inspector must not call AI');
console.log('update3_regression_guard_test: PASS');
