import assert from 'node:assert/strict';
import {parsePillarText} from '../src/daily_engine.js';
import {compareCharts,buildCalculationInspector} from '../src/update3_features.js';
function tech(day,year='Gap-Ja (甲子)',month='Byeong-In (丙寅)',hour='Mu-Jin (戊辰)'){const p={year:parsePillarText(year),month:parsePillarText(month),day:parsePillarText(day),hour:parsePillarText(hour)};return{pillars:p,day_master:p.day.stem};}
const a=tech('Jeong-Yu (丁酉)'),b=tech('Eul-Myo (乙卯)','Eul-Chuk (乙丑)','Jeong-Sa (丁巳)','Gi-Mi (己未)');
const c=compareCharts({personA:{id:'a',name:'A'},personB:{id:'b',name:'B'},technicalA:a,technicalB:b});
assert.equal(c.method,'deterministic-cross-chart-structural-v1');
assert.equal('compatibility_percentage' in c,false);
assert.ok(c.day_branch_relationships.some(x=>x.relationship==='Clash'),'酉↔卯 Day Branch clash should be detected');
assert.ok(c.earthly_branch_interactions.length>0);
assert.ok(c.ten_god_relationships.a_components_relative_to_b_day_master.length>0);
const i=buildCalculationInspector({technical:{pillars:a.pillars,birth:{resolved_utc:'2026-02-04T01:00:00Z'},boundary_checks:{},method_registry:{year_boundary:'ipchun-swiss-v1',month_boundary:'sectional-terms-swiss-v1'}},audit:{astronomy:{li_chun_utc:'2026-02-03T20:00:00Z',month_boundaries:{previous:{target:315},next:{target:345}}}},chart:{year_pillar:'丙午',month_pillar:'庚寅',day_pillar:'丁酉',hour_pillar:'戊辰'}});
assert.equal(i.year.after_ipchun,true);assert.equal(i.year.result,'丙午');assert.equal(i.month.result,'庚寅');
console.log('update3_compare_test: PASS');
