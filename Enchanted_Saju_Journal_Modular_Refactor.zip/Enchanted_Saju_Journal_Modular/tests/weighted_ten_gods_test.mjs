import assert from 'node:assert/strict';
import {weightedTenGods,rawVisibleTenGodDistribution} from '../src/phase1/weighted_analysis.js';
import {samplePillars} from './fixtures.mjs';

const dm=samplePillars.day.stem.index;
const raw=rawVisibleTenGodDistribution(samplePillars,dm);
assert.equal(raw.total,8);
assert.equal(Object.values(raw.counts).reduce((a,b)=>a+b,0),8);
const w=weightedTenGods(samplePillars,dm,{hidden_stem_weighting:true});
const pct=Object.values(w.distribution).reduce((s,x)=>s+x.percentage,0);
assert.ok(Math.abs(pct-100)<0.001,`weighted Ten God percentages total ${pct}`);
assert.equal(w.total_weight,8);
for(const row of Object.values(w.distribution)){
  assert.ok('raw_occurrences' in row);
  assert.ok('weighted_score' in row);
  assert.ok(Array.isArray(row.contributors));
}
const again=weightedTenGods(samplePillars,dm,{hidden_stem_weighting:true});
assert.deepEqual(w,again);
console.log('weighted_ten_gods_test: PASS');
