import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
for(const needle of ['temporary_unavailable','Temporarily Unavailable','retry_after_seconds','upstream_status','Retry-After','[429,500,502,503,504]','source_url:error?.source_url']) assert(s.includes(needle),`missing ${needle}`);
assert(s.includes("Date.parse(retryAfterRaw)"),'Retry-After HTTP-date parsing missing');
console.log('knowledge_retry_backend_test: PASS');
