export const samplePillars={
  year:{stem:{index:2,hanja:'丙',element:'Fire',yin_yang:'Yang'},branch:{hanja:'午',hidden_stems:[{index:3,hanja:'丁',element:'Fire',yin_yang:'Yin'},{index:5,hanja:'己',element:'Earth',yin_yang:'Yin'}]}},
  month:{stem:{index:6,hanja:'庚',element:'Metal',yin_yang:'Yang'},branch:{hanja:'寅',hidden_stems:[{index:0,hanja:'甲',element:'Wood',yin_yang:'Yang'},{index:2,hanja:'丙',element:'Fire',yin_yang:'Yang'},{index:4,hanja:'戊',element:'Earth',yin_yang:'Yang'}]}},
  day:{stem:{index:1,hanja:'乙',element:'Wood',yin_yang:'Yin'},branch:{hanja:'卯',hidden_stems:[{index:1,hanja:'乙',element:'Wood',yin_yang:'Yin'}]}},
  hour:{stem:{index:8,hanja:'壬',element:'Water',yin_yang:'Yang'},branch:{hanja:'子',hidden_stems:[{index:9,hanja:'癸',element:'Water',yin_yang:'Yin'}]}}
};
