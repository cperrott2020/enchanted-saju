# v1.7.1 — Offline Lunar Conversion

The Phase 1 Lunar converter no longer depends on a live KASI API call or KASI_SERVICE_KEY.

Primary method: **korean-lunar-calendar-0.4.0-kari-offline-v1**.

The npm library is pinned to version 0.4.0, uses bundled Korean lunar-calendar conversion data, is leap-month aware, performs validation, has zero runtime dependencies, and follows the Korean KARI/KASI standard.

Enchanted Saju deliberately guards Lunar input to 1800-01-01 through 2050-11-18 so it does not silently expand the historical range of the surrounding v1.6/v1.7 Saju engine.

A live KASI request is no longer required for runtime certification. It may still be used manually as an optional compatibility cross-check.
