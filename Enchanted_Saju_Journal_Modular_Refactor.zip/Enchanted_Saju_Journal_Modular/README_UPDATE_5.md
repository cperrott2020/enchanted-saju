# Enchanted Saju — Update 5
## Enchanted Botanical Field Journal visual redesign

Update 5 is a presentation/UX overhaul built directly on Update 4.2. It keeps the same Cloudflare Worker, Notion databases, saved profiles, calculation pipeline, JewelSJPJ terminology layer, research library, source-pack importer and retry/backoff hotfix.

## Visual direction

The application now combines:

- enchanted botanical scrapbook / storybook
- old-internet personal web shrine
- vintage illustrated field guide
- personal paper journal / almanac
- soft celestial dreaminess
- a restrained contemporary usability layer

The supplied mood-board images were used only as visual reference. They are **not copied into the application**. The shipped decorative art is newly generated vector artwork and CSS decoration.

## Major interface changes

- warm cream, faded paper, dusty pink, sage, moss, mushroom brown, lilac and moon-blue design tokens
- storybook serif + decorative accent + readable UI typography
- desktop journal-directory sidebar inspired by personal websites; clean compact navigation on mobile
- recurring original fairy-ring / spiral motif
- original botanical corner, lace, pressed-flower and star-divider ornaments
- scrapbook-style Journal and source cards
- enchanted-almanac Today and Luck Calendar surfaces
- winding-path Timeline treatment
- mirrored/orbit Compare treatment without compatibility scoring
- illustrated field-guide Learn area
- scholar's-scrapbook Research area with provenance boundaries preserved
- restrained technical styling in Settings, Audit and calculation areas

## 60 SJPJ / Jiazi visual identities

All 60 types have a modular visual identity generated from:

1. one of five element art families
2. one of twelve original storybook-style branch-animal emblems
3. subtle Yin/Yang framing differences
4. JewelSJPJ accessible SJPJ type naming

Each type ships with:

- `emblem.svg`
- `card.svg`
- permanent manifest metadata

There are **120 original type SVG assets** in `public/assets/sjpj-types/` plus a 60-record manifest.

These graphics are explicitly labelled as decorative UI artwork. They do not add or modify Saju doctrine and do not affect calculations.

## Where type art is used

Type identity is integrated into:

- Today
- My Saju profile hero
- People profile cards
- Compare
- Learn entries for 60 Jiazi concepts
- the 60 Jiazi Reference / SJPJ Type Cabinet

The cabinet displays all 60 collectible type emblems and opens the existing technical/source-backed reference entry for the selected type.

## Deploy

### Windows

Run:

`update_existing_windows.bat`

### macOS / Linux

Run:

`./update_existing_mac_linux.sh`

Both scripts install dependencies, run the full automated regression suite and deploy to the **same Cloudflare Worker**.

After deployment, hard-refresh the existing `workers.dev` URL. This update is visual/presentation-focused, so existing charts do **not** need recalculation and the Research source pack does not need re-importing merely because of Update 5.
