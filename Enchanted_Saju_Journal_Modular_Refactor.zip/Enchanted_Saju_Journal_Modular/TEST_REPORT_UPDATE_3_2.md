# Enchanted Saju Update 3.2 — Subrequest Hotfix Test Report

## Result

**35 automated suites passed.**

```text
daily_engine_test: PASS
ai_daily_test: PASS
journal_layout_test: PASS
today_dashboard_test: PASS
method_registry_test: PASS
luck_explorer_test: PASS
result_schema_test: PASS
frontend_contract_test: PASS
notion_target_hotfix_test: PASS
month_boundary_display_test: PASS
lunar_conversion_test: PASS
weighted_elements_test: PASS
weighted_ten_gods_test: PASS
chart_strength_test: PASS
phase1_regression_guard_test: PASS
phase1_frontend_test: PASS
gregorian_engine_guard_test: PASS
useful_element_test: PASS
symbolic_stars_test: PASS
twelve_stars_test: PASS
phase2_audit_compat_test: PASS
phase2_regression_guard_test: PASS
notion_phase2_contract_test: PASS
profile_system_test: PASS
update1_frontend_test: PASS
update1_regression_guard_test: PASS
update2_backend_contract_test: PASS
update2_frontend_test: PASS
update2_regression_guard_test: PASS
update3_compare_test: PASS
update3_backend_contract_test: PASS
update3_frontend_test: PASS
update3_regression_guard_test: PASS
notion_json_storage_hotfix_test: PASS
subrequest_budget_hotfix_test: PASS
```

## New regression coverage

`subrequest_budget_hotfix_test.mjs` verifies that:

- `/api/save-chart` performs the core save without page-audit or Major Luck writes;
- `/api/save-chart/finalize` performs secondary writes in a separate Worker invocation;
- configured Notion data-source IDs use the zero-discovery fast path;
- concept relation references are reused by the finalizer instead of re-querying the Concepts database;
- Chart-page audit finalization is idempotent;
- Major Luck finalization checks existing rows before creating missing rows;
- the browser retries finalization as a new HTTP invocation rather than continuing the same subrequest budget.

## Expected external-subrequest budget

With the shipped pinned data-source IDs and a normal saved profile:

- **Core save:** typically about 5–10 Notion requests, depending on whether the profile is new/default and whether a prior Primary Chart exists.
- **Finalize:** normally about 11 Notion requests for audit + existing-cycle query + eight Major Luck rows; optional Reading can add up to two.

This is designed for the Workers Free ceiling of 50 external subrequests per invocation. It does not require increasing the Cloudflare account limit.

## Deterministic engine regression guard

- `src/daily_engine.js` — **UNCHANGED** — `efe4bf4ce3b19f522fcbb9e0e6fe262806dbe164f41f887c362771c5b79ef785`
- `src/solar_terms.js` — **UNCHANGED** — `8683b67bf8d50e62bf04f85d483c9c8e95e36324f86cad307a3e4d4e83ad38cb`
- `src/luck_explorer.js` — **UNCHANGED** — `77309235543e9c197c96e05ec641d114ac2a68a5a186cd3734f6685afd4efff0`
- `src/ai_daily.js` — **UNCHANGED** — `c6791b165107bd6419b5d4a1f61aa661bf6e5e49199bc6c2f81e319d99a33083`
- `src/journal_layout.js` — **UNCHANGED** — `a846d78cf82651d1361180b64de859d9ce64f151b213455f3d0bc8f061ad1a90`
- `src/method_registry.js` — **UNCHANGED** — `26fc3f70ecaf7406b63e635f03a2ec224cbc80fb98b3483533aef242391dd15b`
- `src/result_schema.js` — **UNCHANGED** — `1e32aca812202b223dae3553ae118bf7833d9e2a45c3eb7515640549926dc866`
- `src/phase1/lunar_conversion.js` — **UNCHANGED** — `6617f257178b9218aef7a0f733090ef9a424fcd0f7e6c697f8c4a6d95d53eac2`
- `src/phase1/weighted_analysis.js` — **UNCHANGED** — `d7483a7fe2bffdcfd971bb399ffe98fef098c0be84eb99a4bdc16e9a086d50ca`
- `src/phase1/chart_strength.js` — **UNCHANGED** — `2bef96bc3963d4dbae46dc2aa5c0d45577a9618cbd451bd37f6ec0bbbee43cff`
- `src/phase2/useful_elements.js` — **UNCHANGED** — `112d93135069292af6158eec9d9764a037f71d935a32749923d2b1c4086ef11c`
- `src/phase2/symbolic_stars.js` — **UNCHANGED** — `7a8866a5c0308b0abf554d6a02604483b9ec956ef3d527d0da571eeddd3343cc`
- `src/phase2/twelve_stars.js` — **UNCHANGED** — `aa9251f2e6d7ffe8107a3b8f2daccce4e9dbc26d87209d70fa83d0cd800dd08b`
- `public/phase1-browser.js` — **UNCHANGED** — `e1539a711184a908681730097e9d96d06cd7318adaa4af799009597c84b00a6d`
- `public/phase2-browser.js` — **UNCHANGED** — `d083d538c2d623451c25f5ff033daca051bb5cdb46b2d6e8e8d95a678b420b0a`


## Build-environment note

The build sandbox does not have npm-registry access. As in the previous release build, the inherited lunar test was run with a temporary API-compatible test fixture for the certified lunar dates. That temporary `node_modules` directory is removed before packaging. The deploy/update script runs `npm install` and the project continues to pin `korean-lunar-calendar@0.4.0`.
