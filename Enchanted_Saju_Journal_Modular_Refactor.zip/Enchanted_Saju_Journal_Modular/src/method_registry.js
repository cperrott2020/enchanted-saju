export const RESULT_SCHEMA_VERSION = '2.2.0-complete';
export const ANALYSIS_VERSION = '1.7-complete';

export const METHOD_REGISTRY = Object.freeze({
  year_boundary: 'ipchun-swiss-v1',
  month_boundary: 'sectional-terms-swiss-v1',
  day_boundary: 'configurable-midnight-or-zi-v1',
  hour_boundary: 'double-hour-v1',
  hidden_stems: 'standard-hidden-stems-v1',
  relationships: 'relationship-table-v2-wonjin',
  growth_stages: 'twelve-growth-daymaster-v1',
  void: 'xun-void-v1',
  major_luck: 'sectional-term-3days-v1',
  weighted_elements: 'transparent-hidden-stem-equal-allocation-v1',
  ten_god_weighting: 'transparent-hidden-stem-equal-allocation-v1',
  chart_strength: 'workbook-support-drain-monthbranch-v1',
  useful_element: 'workbook-useful-god-simplified-v1',
  favourable_element: 'workbook-useful-god-simplified-v1',
  unfavourable_element: 'workbook-useful-god-simplified-v1',
  symbolic_stars: 'symbolic-stars-four-rule-set-v1',
  twelve_stars: 'year-branch-trine-12sinsal-v1',
  lunar_conversion: 'korean-lunar-calendar-0.4.0-kari-offline-v1'
});

export const DEFAULT_ANALYSIS_SETTINGS = Object.freeze({
  apply_combination_transformations: false,
  seasonal_adjustment: false,
  palace_weighting: false,
  hidden_stem_weighting: true,
  symbolic_stars_enabled: true,
  twelve_stars_enabled: true
});

export function methodologyStatus(registry = METHOD_REGISTRY) {
  const pending = Object.entries(registry).filter(([, value]) => !value).map(([key]) => key);
  return { registry, descriptions: METHOD_DESCRIPTIONS, pending, ready: Object.keys(registry).filter(key => !pending.includes(key)) };
}

export const METHOD_DESCRIPTIONS = Object.freeze({
  lunar_conversion: 'Offline Korean lunisolar conversion using korean-lunar-calendar 0.4.0 data following the Korean KARI/KASI standard, with explicit ordinary/leap-month selection.',
  weighted_elements: 'Visible stem weight 1; each branch totals 1; branch weight is divided equally across encoded Hidden Stems when enabled. No unvalidated seasonal, palace or combination multiplier is applied.',
  ten_god_weighting: 'Same contributor weights as weighted Five Elements; each contributor is mapped to a Ten God relative to the Day Master.',
  chart_strength: 'Korean Saju Workbook Support/Drain method. Clear cases use Support versus Drain; borderline 4/4 or 5/3 cases are decided by Month Branch main qi support versus drain.',
  useful_element: 'Korean Saju Workbook simplified Useful God method: Weak defaults to Companion except a clearly dominant Output drain uses Resource; Strong compares Resource and Companion to select Wealth, Authority or Output.',
  favourable_element: 'Same workbook method: Favourable God is the element that generates the selected Useful God.',
  unfavourable_element: 'Same workbook method: Unfavourable God is the element that controls the selected Useful God.',
  symbolic_stars: 'Four-rule symbolic-star set only: Peach Blossom, Travelling Horse and Flower Canopy from Year/Day-Branch trine references, plus Heavenly Nobleman from the Day Stem. Other stars remain unimplemented.',
  twelve_stars: 'Year-Branch-reference 삼합 Twelve Stars / 십이신살 sequence, stored independently from Twelve Growth Stages / 십이운성.'
});
