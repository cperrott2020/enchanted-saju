export const JOURNAL_LAYOUT_VERSION = '1.6.0-expanded-notion-journal';
export const TODAY_DASHBOARD_VERSION = '1.6.0-live-today-dashboard';
export const GENERATED_CONTAINER_MARKER = '🌸 Daily Saju';
export const CALCULATED_CONTEXT_MARKER = '🔒 Calculated Context';
export const AI_READING_MARKER = '🌸 AI Daily Reading';
export const JOURNAL_MARKER = '☕ Daily Journal';

const HEADING_MAP = [
  ['Overall Theme', '🌿 Overall Theme'],
  ["Today's Day Master Relationship", '🔥 Today\'s Day Master Relationship'],
  ['Elemental Influence', '🌱 Elemental Influence'],
  ['Ten God Influence', '🎴 Ten God Influence'],
  ['Natal Interactions', '🪷 Natal Interactions'],
  ['Major Luck Context', '🧭 Major Luck Context'],
  ['Annual Context', '🗓️ Annual Context'],
  ['Monthly Context', '🌙 Monthly Context'],
  ['Work & Study', '📚 Work & Study'],
  ['Relationships', '🤝 Relationships'],
  ['Money & Resources', '💰 Money & Resources'],
  ['Creativity', '🎨 Creativity'],
  ['Energy & Pace', '🍃 Energy & Pace'],
  ['Things to Notice', '🔎 Things to Notice'],
  ['Reflection Prompt', '💭 Reflection Prompt'],
  // v1.3-v1.5 compatibility aliases
  ['Overall theme', '🌿 Overall Theme'],
  ['Day Master relationship', '🔥 Today\'s Day Master Relationship'],
  ['Ten God theme', '🎴 Ten God Influence'],
  ['Luck-cycle context', '🧭 Major Luck Context'],
  ['Natal interactions', '🪷 Natal Interactions'],
  ['Practical focus', '📝 Practical Focus'],
  ['Reflection prompt', '💭 Reflection Prompt']
];

export function splitAiSections(aiText) {
  const src = String(aiText || '').replace(/\r\n/g, '\n').trim();
  if (!src) return [];

  const canonical = new Map(HEADING_MAP.map(([raw, display]) => [normaliseHeading(raw), { raw, display }]));
  const sections = [];
  let current = null;

  for (const line of src.split('\n')) {
    const stripped = line.trim().replace(/^#{1,6}\s*/, '').replace(/^\*\*(.*?)\*\*$/, '$1').replace(/:$/, '').trim();
    const found = canonical.get(normaliseHeading(stripped));
    if (found) {
      if (current) sections.push({ ...current, text: current.lines.join('\n').trim() });
      current = { key: found.raw, heading: found.display, lines: [] };
      continue;
    }
    if (current) current.lines.push(line);
  }
  if (current) sections.push({ ...current, text: current.lines.join('\n').trim() });

  const useful = sections.filter(s => s.text);
  if (useful.length) return useful;
  return [{ key: 'Interpretation', heading: '🌿 Interpretation', text: src }];
}

export function extractAiBodyFromStoredReading(reading) {
  const src = String(reading || '').replace(/\r\n/g, '\n');
  if (!src.trim()) return '';
  const start = src.search(/^\s*(?:#{1,6}\s*)?Overall theme\s*:?[ \t]*$/im);
  if (start < 0) return '';
  let body = src.slice(start).trim();
  const footer = body.search(/^\s*AI interpretation:\s*/im);
  if (footer >= 0) body = body.slice(0, footer).trim();
  return body;
}

export function blockPlainText(block) {
  if (!block || typeof block !== 'object') return '';
  const payload = block[block.type];
  const rich = payload?.rich_text;
  if (!Array.isArray(rich)) return '';
  return rich.map(x => x?.plain_text || x?.text?.content || '').join('').trim();
}

export function generatedContainerBlock() {
  return {
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: richText(GENERATED_CONTAINER_MARKER, { bold: true }),
      icon: { type: 'emoji', emoji: '🌸' },
      color: 'pink_background'
    }
  };
}

export function calculatedContextBlock() {
  return {
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: richText(CALCULATED_CONTEXT_MARKER, { bold: true }),
      icon: { type: 'emoji', emoji: '🔒' },
      color: 'brown_background'
    }
  };
}

export function aiReadingBlock() {
  return {
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: richText(AI_READING_MARKER, { bold: true }),
      icon: { type: 'emoji', emoji: '🌸' },
      color: 'pink_background'
    }
  };
}

export function calculatedContextChildren(p) {
  const f = p.calculated;
  const major = p.currentMajor ? plainTitle(p.currentMajor.properties?.['Cycle']) || 'Current Major Luck' : 'No active Major Luck record found';
  const rows = [
    ['Day Pillar', f.day.label],
    ['Ten God', `${f.day.ten_god.en} · ${f.day.ten_god.ko} ${f.day.ten_god.hanja}`],
    ['Year Pillar', f.year.label],
    ['Month Pillar', f.month.label],
    ['Major Luck', major],
    ['Element', `${f.day.stem.element} · ${f.day.stem.yin_yang}`],
    ['Animal', f.day.branch.animal]
  ];
  const blocks = [heading3('Today\'s Saju')];
  for (const [label, value] of rows) blocks.push(labelValueParagraph(label, value));
  blocks.push(heading3('Interactions'));
  blocks.push(...paragraphBlocks(f.interactions_text || 'No supplied natal interactions detected for this day.'));
  if (Array.isArray(f.boundary_warnings) && f.boundary_warnings.length) {
    blocks.push(heading3('Boundary notes'));
    for (const warning of f.boundary_warnings) blocks.push(paragraph(`⚠ ${warning}`));
  }
  blocks.push(paragraph(`Calculated by ${f.engine?.version || 'deterministic Saju engine'} · ${p.timezone}`, { italic: true, color: 'gray' }));
  return blocks;
}

export function aiReadingChildren(aiText, model, readingVersion) {
  const sections = splitAiSections(aiText);
  const blocks = [];
  for (const section of sections) {
    blocks.push(heading3(section.heading));
    blocks.push(...paragraphBlocks(section.text));
  }
  blocks.push(paragraph(`AI interpretation: ${model}${readingVersion ? ` · ${readingVersion}` : ''}. Calculated facts remain authoritative and are not editable by the AI.`, { italic: true, color: 'gray' }));
  return blocks;
}

export function journalScaffoldBlocks() {
  return [
    { object: 'block', type: 'divider', divider: {} },
    { object: 'block', type: 'heading_2', heading_2: { rich_text: richText(JOURNAL_MARKER, { bold: true }), color: 'green' } },
    paragraph('This is the permanent personal layer for this date. Generated Saju sections can refresh without replacing anything you write below.', { color: 'gray' }),
    heading3('✎ What actually happened today?'), paragraph(''),
    heading3('🙂 Mood'), paragraph(''),
    heading3('⚡ Energy'), paragraph(''),
    heading3('✓ Productivity'), paragraph(''),
    heading3('🤝 Relationships'), paragraph(''),
    heading3('📚 Work / Study'), paragraph(''),
    heading3('💰 Money'), paragraph(''),
    heading3('🎨 Creativity'), paragraph(''),
    heading3('✦ Unexpected Events'), paragraph(''),
    heading3('🔍 Did the reading resonate?'), paragraph(''),
    heading3('↻ Retrospective'), paragraph('')
  ];
}


export function todayHeaderBlock(p) {
  return {
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: richText(`🌸 Today · ${p.date}`, { bold: true }),
      icon: { type: 'emoji', emoji: '🌸' },
      color: 'pink_background'
    }
  };
}

export function aiUnavailableBlock(message = 'AI Daily Reading is not available yet. The calculated Saju context above is still valid and saved.') {
  return {
    object: 'block',
    type: 'callout',
    callout: {
      rich_text: richText(`☁️ ${message}`),
      icon: { type: 'emoji', emoji: '☁️' },
      color: 'gray_background'
    }
  };
}

export function savedDailyLuckBlocks(pageUrl, title, timezone) {
  const label = title || 'Open today\'s saved Daily Luck entry';
  return [
    { object: 'block', type: 'divider', divider: {} },
    {
      object: 'block',
      type: 'callout',
      callout: {
        rich_text: [
          ...richText('📚 Saved historical record: ', { bold: true }),
          ...linkedRichText(label, pageUrl)
        ],
        icon: { type: 'emoji', emoji: '📚' },
        color: 'green_background'
      }
    },
    paragraph(`This Today page is a live dashboard and is replaced automatically at local midnight (${timezone}). Write journal notes in the saved Daily Luck entry above so they remain permanently attached to that date.`, { color: 'gray' })
  ];
}

function linkedRichText(text, href) {
  const pieces = chunk(String(text ?? ''), 1900);
  return pieces.map(piece => ({
    type: 'text',
    text: { content: piece, link: href ? { url: href } : null },
    annotations: {
      bold: false,
      italic: false,
      strikethrough: false,
      underline: true,
      code: false,
      color: 'default'
    }
  }));
}

export function richText(text, annotations = {}) {
  const content = String(text ?? '');
  if (!content) return [];
  return chunk(content, 1900).map(piece => ({
    type: 'text',
    text: { content: piece },
    annotations: {
      bold: !!annotations.bold,
      italic: !!annotations.italic,
      strikethrough: false,
      underline: false,
      code: false,
      color: annotations.color || 'default'
    }
  }));
}

function labelValueParagraph(label, value) {
  const rich_text = [
    ...richText(`${label}: `, { bold: true }),
    ...richText(String(value || '—'))
  ];
  return { object: 'block', type: 'paragraph', paragraph: { rich_text, color: 'default' } };
}

function heading3(text) {
  return { object: 'block', type: 'heading_3', heading_3: { rich_text: richText(text, { bold: true }), color: 'default' } };
}

function paragraph(text, annotations = {}) {
  return { object: 'block', type: 'paragraph', paragraph: { rich_text: richText(text, annotations), color: 'default' } };
}

function paragraphBlocks(text) {
  const src = String(text || '').trim();
  if (!src) return [paragraph('')];
  const paragraphs = src.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
  const blocks = [];
  for (const p of paragraphs) {
    const pieces = chunk(p, 1800);
    for (const piece of pieces) blocks.push(paragraph(piece));
  }
  return blocks.length ? blocks : [paragraph(src)];
}

function normaliseHeading(value) {
  return String(value || '').toLowerCase().replace(/[\u2010-\u2015]/g, '-').replace(/\s+/g, ' ').trim();
}

function chunk(text, max) {
  const s = String(text || '');
  if (!s) return [];
  const out = [];
  let rest = s;
  while (rest.length > max) {
    let cut = rest.lastIndexOf(' ', max);
    if (cut < Math.floor(max * 0.55)) cut = max;
    out.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  if (rest) out.push(rest);
  return out;
}

function plainTitle(prop) {
  return (prop?.title || []).map(x => x?.plain_text || x?.text?.content || '').join('').trim();
}
