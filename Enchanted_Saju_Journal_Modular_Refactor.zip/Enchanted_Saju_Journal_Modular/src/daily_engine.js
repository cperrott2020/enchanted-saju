import { SWISS_TERMS } from './solar_terms.js';

export const DAILY_ENGINE_VERSION = '1.0.0-swiss-deterministic';

export const STEMS = [
  {index:0,ko:'갑',hanja:'甲',roman:'Gap',element:'Wood',yin_yang:'Yang'},
  {index:1,ko:'을',hanja:'乙',roman:'Eul',element:'Wood',yin_yang:'Yin'},
  {index:2,ko:'병',hanja:'丙',roman:'Byeong',element:'Fire',yin_yang:'Yang'},
  {index:3,ko:'정',hanja:'丁',roman:'Jeong',element:'Fire',yin_yang:'Yin'},
  {index:4,ko:'무',hanja:'戊',roman:'Mu',element:'Earth',yin_yang:'Yang'},
  {index:5,ko:'기',hanja:'己',roman:'Gi',element:'Earth',yin_yang:'Yin'},
  {index:6,ko:'경',hanja:'庚',roman:'Gyeong',element:'Metal',yin_yang:'Yang'},
  {index:7,ko:'신',hanja:'辛',roman:'Sin',element:'Metal',yin_yang:'Yin'},
  {index:8,ko:'임',hanja:'壬',roman:'Im',element:'Water',yin_yang:'Yang'},
  {index:9,ko:'계',hanja:'癸',roman:'Gye',element:'Water',yin_yang:'Yin'}
];

export const BRANCHES = [
  {index:0,ko:'자',hanja:'子',roman:'Ja',animal:'Rat',element:'Water',yin_yang:'Yang'},
  {index:1,ko:'축',hanja:'丑',roman:'Chuk',animal:'Ox',element:'Earth',yin_yang:'Yin'},
  {index:2,ko:'인',hanja:'寅',roman:'In',animal:'Tiger',element:'Wood',yin_yang:'Yang'},
  {index:3,ko:'묘',hanja:'卯',roman:'Myo',animal:'Rabbit',element:'Wood',yin_yang:'Yin'},
  {index:4,ko:'진',hanja:'辰',roman:'Jin',animal:'Dragon',element:'Earth',yin_yang:'Yang'},
  {index:5,ko:'사',hanja:'巳',roman:'Sa',animal:'Snake',element:'Fire',yin_yang:'Yin'},
  {index:6,ko:'오',hanja:'午',roman:'O',animal:'Horse',element:'Fire',yin_yang:'Yang'},
  {index:7,ko:'미',hanja:'未',roman:'Mi',animal:'Goat',element:'Earth',yin_yang:'Yin'},
  {index:8,ko:'신',hanja:'申',roman:'Sin',animal:'Monkey',element:'Metal',yin_yang:'Yang'},
  {index:9,ko:'유',hanja:'酉',roman:'Yu',animal:'Rooster',element:'Metal',yin_yang:'Yin'},
  {index:10,ko:'술',hanja:'戌',roman:'Sul',animal:'Dog',element:'Earth',yin_yang:'Yang'},
  {index:11,ko:'해',hanja:'亥',roman:'Hae',animal:'Pig',element:'Water',yin_yang:'Yin'}
];

const TEN_GODS={
  friend:{en:'Friend / Companion',ko:'비견',hanja:'比肩'},
  rob_wealth:{en:'Rob Wealth',ko:'겁재',hanja:'劫財'},
  eating_god:{en:'Eating God',ko:'식신',hanja:'食神'},
  hurting_officer:{en:'Hurting Officer',ko:'상관',hanja:'傷官'},
  indirect_wealth:{en:'Indirect Wealth',ko:'편재',hanja:'偏財'},
  direct_wealth:{en:'Direct Wealth',ko:'정재',hanja:'正財'},
  seven_killings:{en:'Seven Killings / Indirect Officer',ko:'편관',hanja:'偏官'},
  direct_officer:{en:'Direct Officer',ko:'정관',hanja:'正官'},
  indirect_resource:{en:'Indirect Resource',ko:'편인',hanja:'偏印'},
  direct_resource:{en:'Direct Resource',ko:'정인',hanja:'正印'}
};

const GENERATES={Wood:'Fire',Fire:'Earth',Earth:'Metal',Metal:'Water',Water:'Wood'};
const CONTROLS={Wood:'Earth',Fire:'Metal',Earth:'Water',Metal:'Wood',Water:'Fire'};
const STEM_COMBINATIONS={'0,5':'Earth','1,6':'Metal','2,7':'Water','3,8':'Wood','4,9':'Fire'};
const SIX_COMBINATIONS={'0,1':'Earth','2,11':'Wood','3,10':'Fire','4,9':'Metal','5,8':'Water','6,7':'Earth'};
const CLASHES=new Set(['0,6','1,7','2,8','3,9','4,10','5,11']);
const HARMS=new Set(['0,7','1,6','2,5','3,4','8,11','9,10']);
const BREAKS=new Set(['0,9','3,6','1,4','7,10','2,11','5,8']);
const WONJIN=new Set(['0,7','1,6','2,9','3,8','4,11','5,10']);
const THREE_HARMONY=[[[0,4,8],'Water'],[[3,7,11],'Wood'],[[2,6,10],'Fire'],[[1,5,9],'Metal']];
const DIRECTIONAL=[[[2,3,4],'Wood'],[[5,6,7],'Fire'],[[8,9,10],'Metal'],[[0,1,11],'Water']];
const PUNISHMENT_TRIADS=[[2,5,8],[1,7,10]];
const PUNISHMENT_PAIR='0,3';
const SELF_PUNISHMENT=new Set([4,6,9,11]);

function mod(a,n){return ((a%n)+n)%n;}
function key2(a,b){return [a,b].sort((x,y)=>x-y).join(',');}

export function gregorianJDN(y,m,d){
  const a=Math.floor((14-m)/12), yy=y+4800-a, mm=m+12*a-3;
  return d+Math.floor((153*mm+2)/5)+365*yy+Math.floor(yy/4)-Math.floor(yy/100)+Math.floor(yy/400)-32045;
}

export function pillarLabel(stemIndex,branchIndex){
  return `${STEMS[stemIndex].roman}-${BRANCHES[branchIndex].roman} (${STEMS[stemIndex].hanja}${BRANCHES[branchIndex].hanja})`;
}

export function tenGod(dayMasterStemIndex,targetStemIndex){
  const dm=STEMS[dayMasterStemIndex],t=STEMS[targetStemIndex],same=dm.yin_yang===t.yin_yang;
  let key;
  if(dm.element===t.element) key=same?'friend':'rob_wealth';
  else if(GENERATES[dm.element]===t.element) key=same?'eating_god':'hurting_officer';
  else if(CONTROLS[dm.element]===t.element) key=same?'indirect_wealth':'direct_wealth';
  else if(CONTROLS[t.element]===dm.element) key=same?'seven_killings':'direct_officer';
  else if(GENERATES[t.element]===dm.element) key=same?'indirect_resource':'direct_resource';
  else throw new Error('Unreachable Five Element relation');
  return {key,...TEN_GODS[key]};
}

function validTimeZone(tz){
  try{new Intl.DateTimeFormat('en-US',{timeZone:tz}).format();return true;}catch{return false;}
}

function tzParts(ms,tz){
  const f=new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  const o={};
  for(const p of f.formatToParts(new Date(ms))) if(p.type!=='literal') o[p.type]=p.value;
  return {y:+o.year,m:+o.month,d:+o.day,h:+o.hour,min:+o.minute,s:+o.second};
}

function tzOffsetMinutes(ms,tz){
  const p=tzParts(ms,tz); const asUTC=Date.UTC(p.y,p.m-1,p.d,p.h,p.min,p.s); return (asUTC-ms)/60000;
}

function zonedToUtc(y,m,d,h,min,tz){
  const wall=Date.UTC(y,m-1,d,h,min,0); let utc=wall;
  for(let i=0;i<6;i++){
    const off=tzOffsetMinutes(utc,tz); const next=wall-off*60000;
    if(Math.abs(next-utc)<500){utc=next;break;} utc=next;
  }
  return utc;
}

export function localDateString(ms,tz){
  const p=tzParts(ms,tz);
  return `${String(p.y).padStart(4,'0')}-${String(p.m).padStart(2,'0')}-${String(p.d).padStart(2,'0')}`;
}

export function localDateTimeString(ms,tz){
  const p=tzParts(ms,tz);
  return `${String(p.y).padStart(4,'0')}-${String(p.m).padStart(2,'0')}-${String(p.d).padStart(2,'0')} ${String(p.h).padStart(2,'0')}:${String(p.min).padStart(2,'0')}`;
}

export function localHour(ms,tz){return tzParts(ms,tz).h;}

function getTermEventsAround(year){
  const out=[];
  for(const y of [year-1,year,year+1]){
    const a=SWISS_TERMS[String(y)]; if(!a) continue;
    for(let i=0;i<12;i++) out.push({baseYear:y,index:i,target:mod(315+30*i,360),ms:a[i]*1000});
  }
  return out.sort((a,b)=>a.ms-b.ms);
}

function liChunMs(year){
  const a=SWISS_TERMS[String(year)];
  if(!a) throw new Error('Embedded Swiss solar-term table supports years 1799–2201.');
  return a[0]*1000;
}

function monthBoundaryInfo(referenceMs, localYear){
  const events=getTermEventsAround(localYear);
  let previous=null,next=null;
  for(const e of events){if(e.ms<=referenceMs) previous=e; else {next=e;break;}}
  if(!previous||!next) throw new Error('Could not resolve solar-term month boundary.');
  return {month_index:previous.index,previous,next};
}

function pillar(stemIndex,branchIndex){
  return {label:pillarLabel(stemIndex,branchIndex),stem:{...STEMS[stemIndex]},branch:{...BRANCHES[branchIndex]}};
}

export function parsePillarText(text){
  const s=String(text||'');
  let stemIndex=-1,branchIndex=-1;
  for(const st of STEMS){if(s.includes(st.hanja)){stemIndex=st.index;break;}}
  for(const br of BRANCHES){if(s.includes(br.hanja)){branchIndex=br.index;break;}}
  if(stemIndex<0||branchIndex<0) return null;
  if(stemIndex%2!==branchIndex%2) return null;
  return pillar(stemIndex,branchIndex);
}

function relationEvents(day,natal){
  const out=[];
  const natalEntries=Object.entries(natal).filter(([,p])=>p);
  for(const [position,p] of natalEntries){
    const sk=key2(day.stem.index,p.stem.index);
    if(STEM_COMBINATIONS[sk]) out.push({type:'Stem combination',positions:['daily',position],members:[day.stem.hanja,p.stem.hanja],element:STEM_COMBINATIONS[sk]});

    const bk=key2(day.branch.index,p.branch.index);
    if(SIX_COMBINATIONS[bk]) out.push({type:'Six combination',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja],element:SIX_COMBINATIONS[bk]});
    if(CLASHES.has(bk)) out.push({type:'Clash',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja]});
    if(HARMS.has(bk)) out.push({type:'Harm',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja]});
    if(BREAKS.has(bk)) out.push({type:'Break',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja]});
    if(WONJIN.has(bk)) out.push({type:'Wonjin',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja],method_version:'wonjin-pairs-v1'});
    if(bk===PUNISHMENT_PAIR) out.push({type:'Punishment',subtype:'Zi-Mao punishment',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja]});
    if(day.branch.index===p.branch.index && SELF_PUNISHMENT.has(day.branch.index)) out.push({type:'Punishment',subtype:'Self-punishment',positions:['daily',position],members:[day.branch.hanja,p.branch.hanja]});
  }

  const branchSet=new Set(natalEntries.map(([,p])=>p.branch.index));
  branchSet.add(day.branch.index);
  for(const [tri,element] of THREE_HARMONY){
    if(tri.every(x=>branchSet.has(x)) && tri.includes(day.branch.index)) out.push({type:'Three Harmony',members:tri.map(i=>BRANCHES[i].hanja),element});
  }
  for(const [tri,element] of DIRECTIONAL){
    if(tri.every(x=>branchSet.has(x)) && tri.includes(day.branch.index)) out.push({type:'Directional combination',members:tri.map(i=>BRANCHES[i].hanja),element});
  }
  for(const tri of PUNISHMENT_TRIADS){
    if(tri.every(x=>branchSet.has(x)) && tri.includes(day.branch.index)) out.push({type:'Punishment',subtype:'Three-branch punishment group',members:tri.map(i=>BRANCHES[i].hanja)});
  }
  return dedupeEvents(out);
}

function dedupeEvents(events){
  const seen=new Set();
  return events.filter(e=>{const k=JSON.stringify([e.type,e.subtype||'',(e.members||[]).slice().sort(),e.element||'']);if(seen.has(k))return false;seen.add(k);return true;});
}

export function formatInteractions(events){
  if(!events?.length) return 'No configured daily-to-natal stem/branch interactions detected.';
  return events.map(e=>{
    const members=(e.members||[]).join('·');
    const subtype=e.subtype?` (${e.subtype})`:'';
    const element=e.element?` → ${e.element}`:'';
    const pos=e.positions?` [${e.positions.join(' ↔ ')}]`:'';
    return `${e.type}${subtype}: ${members}${element}${pos}`;
  }).join('\n');
}


export const GROWTH_STAGES = [
  {index:0,en:'Birth / Long Life',ko:'장생',hanja:'長生'},
  {index:1,en:'Bath',ko:'목욕',hanja:'沐浴'},
  {index:2,en:'Crown and Belt',ko:'관대',hanja:'冠帶'},
  {index:3,en:'Establishment',ko:'건록',hanja:'建祿'},
  {index:4,en:'Imperial Prosperity',ko:'제왕',hanja:'帝旺'},
  {index:5,en:'Decline',ko:'쇠',hanja:'衰'},
  {index:6,en:'Illness',ko:'병',hanja:'病'},
  {index:7,en:'Death',ko:'사',hanja:'死'},
  {index:8,en:'Tomb',ko:'묘',hanja:'墓'},
  {index:9,en:'Extinction',ko:'절',hanja:'絶'},
  {index:10,en:'Conception',ko:'태',hanja:'胎'},
  {index:11,en:'Nurture',ko:'양',hanja:'養'}
];
const GROWTH_BIRTH_BRANCH={0:11,1:6,2:2,3:9,4:2,5:9,6:5,7:0,8:8,9:3};

export function growthStage(dayMasterStemIndex, branchIndex){
  const start=GROWTH_BIRTH_BRANCH[dayMasterStemIndex];
  const dir=STEMS[dayMasterStemIndex].yin_yang==='Yang'?1:-1;
  const idx=mod((branchIndex-start)*dir,12);
  return {...GROWTH_STAGES[idx]};
}

export function relationshipEventsForPillar(currentPillar,natal,sourceLayer='current'){
  if(!currentPillar?.stem||!currentPillar?.branch) return [];
  return relationEvents(currentPillar,natal).map(e=>({
    relationship:e.type,
    subtype:e.subtype||null,
    participants:[...(e.members||[])],
    positions:[...(e.positions||[])],
    source_layer:sourceLayer,
    resulting_element:e.element||null,
    transformation_possible:!!e.element && ['Stem combination','Six combination','Three Harmony','Directional combination'].includes(e.type),
    transformation_applied:false,
    method_version:e.method_version||'relationship-table-v1'
  }));
}

export function calculateDailyContext({date,timezone,natal}){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date||''))) throw new Error('Daily date must be YYYY-MM-DD.');
  if(!validTimeZone(timezone)) throw new Error(`Invalid IANA timezone: ${timezone}`);
  const [Y,M,D]=date.split('-').map(Number);
  if(Y<1800||Y>2200) throw new Error('Daily engine supports years 1800–2200.');
  if(!natal?.day?.stem) throw new Error('Natal Day Pillar is required for Daily Ten God calculation.');

  // Noon is the representative instant for a one-record-per-calendar-day journal.
  // Exact solar-term transitions occurring within the local date are separately flagged.
  const referenceMs=zonedToUtc(Y,M,D,12,0,timezone);
  const liCurrent=liChunMs(Y);
  const effectiveYear=referenceMs>=liCurrent?Y:Y-1;
  const yearStem=mod(effectiveYear-4,10), yearBranch=mod(effectiveYear-4,12);
  const yearPillar=pillar(yearStem,yearBranch);

  const bounds=monthBoundaryInfo(referenceMs,Y);
  const monthIndex=bounds.month_index;
  const monthBranch=mod(2+monthIndex,12);
  const monthStem=mod(2*yearStem+2+monthIndex,10);
  const monthPillar=pillar(monthStem,monthBranch);

  const dayIndex=mod(gregorianJDN(Y,M,D)+49,60);
  const dayStem=dayIndex%10, dayBranch=dayIndex%12;
  const dayPillar=pillar(dayStem,dayBranch);
  const tg=tenGod(natal.day.stem.index,dayStem);
  const interactions=relationEvents(dayPillar,natal);

  const dayStart=zonedToUtc(Y,M,D,0,0,timezone);
  const nextDate=new Date(Date.UTC(Y,M-1,D)+86400000);
  const dayEnd=zonedToUtc(nextDate.getUTCFullYear(),nextDate.getUTCMonth()+1,nextDate.getUTCDate(),0,0,timezone);
  const allTerms=getTermEventsAround(Y).filter(e=>e.ms>=dayStart&&e.ms<dayEnd);
  const boundaryWarnings=[];
  if(allTerms.some(e=>e.target===315)) boundaryWarnings.push('Ipchun/year boundary occurs during this local calendar day.');
  if(allTerms.length) boundaryWarnings.push(`Solar-term month boundary occurs during this local calendar day at ${allTerms.map(e=>new Date(e.ms).toISOString()).join(', ')} UTC.`);

  return {
    engine:{version:DAILY_ENGINE_VERSION,reference_local_time:'12:00',year_boundary:'exact embedded Swiss Ipchun',month_boundary:'embedded Swiss sectional terms',day_anchor:'(Gregorian JDN + 49) mod 60; 1949-10-01 = 甲子'},
    date,
    timezone,
    reference_utc:new Date(referenceMs).toISOString(),
    year:{effective_saju_year:effectiveYear,...yearPillar,start_utc:new Date(liChunMs(effectiveYear)).toISOString(),end_utc:new Date(liChunMs(effectiveYear+1)).toISOString()},
    month:{month_index:monthIndex,...monthPillar,start_utc:new Date(bounds.previous.ms).toISOString(),end_utc:new Date(bounds.next.ms).toISOString(),start_longitude:bounds.previous.target},
    day:{sexagenary_index:dayIndex,...dayPillar,ten_god:tg,growth_stage:growthStage(natal.day.stem.index,dayBranch)},
    natal_interactions:interactions,
    structured_interactions:relationshipEventsForPillar(dayPillar,natal,'daily'),
    interactions_text:formatInteractions(interactions),
    boundary_warnings:boundaryWarnings
  };
}
