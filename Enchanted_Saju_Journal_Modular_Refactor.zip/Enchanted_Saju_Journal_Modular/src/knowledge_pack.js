export const KNOWLEDGE_PACK_VERSION = '1.7.4.2-jewel-ten-gods-v1';

export const JEWEL_STEM_TERMS = {
  '甲': { preferred:'Blue Tree', technical:'Yang Wood', korean:'갑목', romanisation:'Gap', source_id:'SRC-JEWEL-001' },
  '乙': { preferred:'Blue Vine', technical:'Yin Wood', korean:'을목', romanisation:'Eul', source_id:'SRC-JEWEL-001' },
  '丙': { preferred:'Red Sun', technical:'Yang Fire', korean:'병화', romanisation:'Byeong', source_id:'SRC-JEWEL-001' },
  '丁': { preferred:'Red Moon', technical:'Yin Fire', korean:'정화', romanisation:'Jeong', source_id:'SRC-JEWEL-001' },
  '戊': { preferred:'Yellow Mountain', technical:'Yang Earth', korean:'무토', romanisation:'Mu', source_id:'SRC-JEWEL-001' },
  '己': { preferred:'Yellow Garden', technical:'Yin Earth', korean:'기토', romanisation:'Gi', source_id:'SRC-JEWEL-001' },
  '庚': { preferred:'White Sword', technical:'Yang Metal', korean:'경금', romanisation:'Gyeong', source_id:'SRC-JEWEL-001' },
  '辛': { preferred:'White Jewel', technical:'Yin Metal', korean:'신금', romanisation:'Sin', source_id:'SRC-JEWEL-001' },
  '壬': { preferred:'Black Ocean', technical:'Yang Water', korean:'임수', romanisation:'Im', source_id:'SRC-JEWEL-001' },
  '癸': { preferred:'Black Mist', technical:'Yin Water', korean:'계수', romanisation:'Gye', source_id:'SRC-JEWEL-001' }
};

export const BRANCH_META = [
  ['子','자','Ja','Rat','Water','Yang'],['丑','축','Chuk','Ox','Earth','Yin'],['寅','인','In','Tiger','Wood','Yang'],['卯','묘','Myo','Rabbit','Wood','Yin'],
  ['辰','진','Jin','Dragon','Earth','Yang'],['巳','사','Sa','Snake','Fire','Yin'],['午','오','O','Horse','Fire','Yang'],['未','미','Mi','Goat','Earth','Yin'],
  ['申','신','Sin','Monkey','Metal','Yang'],['酉','유','Yu','Rooster','Metal','Yin'],['戌','술','Sul','Dog','Earth','Yang'],['亥','해','Hae','Pig','Water','Yin']
].map(([hanja,korean,romanisation,animal,element,yin_yang],index)=>({index,hanja,korean,romanisation,animal,element,yin_yang}));

export const STEM_META = Object.entries(JEWEL_STEM_TERMS).map(([hanja,v],index)=>({index,hanja,korean:hanja==='甲'?'갑':hanja==='乙'?'을':hanja==='丙'?'병':hanja==='丁'?'정':hanja==='戊'?'무':hanja==='己'?'기':hanja==='庚'?'경':hanja==='辛'?'신':hanja==='壬'?'임':'계',...v}));

export const JEWEL_TEN_GOD_TERMS = {
  '比肩': {concept_id:'CONCEPT-TENGOD-BIGYEON', preferred:'Self God', technical:'Friend / Companion', korean:'비견', jewel_romanisation:'Bi Gyeon', technical_romanisation:'Bigyeon', category:'Me', source_id:'SRC-JEWEL-004', aliases:['Friend','Companion','Peer','Bi Gyeon','Bigyeon']},
  '劫財': {concept_id:'CONCEPT-TENGOD-GYEOPJAE', preferred:'Rival God', technical:'Rob Wealth', korean:'겁재', jewel_romanisation:'Geop Jae', technical_romanisation:'Gyeopjae', category:'Me', source_id:'SRC-JEWEL-004', aliases:['Rob Wealth','Geop Jae','Gyeopjae']},
  '食神': {concept_id:'CONCEPT-TENGOD-SIKSIN', preferred:'Creator God', technical:'Eating God', korean:'식신', jewel_romanisation:'Sik Shin', technical_romanisation:'Siksin', category:'Output', source_id:'SRC-JEWEL-004', aliases:['Eating God','Sik Shin','Siksin']},
  '傷官': {concept_id:'CONCEPT-TENGOD-SANGGWAN', preferred:'Rebel God', technical:'Hurting Officer', korean:'상관', jewel_romanisation:'Sang Gwan', technical_romanisation:'Sanggwan', category:'Output', source_id:'SRC-JEWEL-004', aliases:['Hurting Officer','Sang Gwan','Sanggwan']},
  '偏財': {concept_id:'CONCEPT-TENGOD-PYEONJAE', preferred:'Entrepreneur God', technical:'Indirect Wealth', korean:'편재', jewel_romanisation:'Pyeon Jae', technical_romanisation:'Pyeonjae', category:'Wealth', source_id:'SRC-JEWEL-004', aliases:['Indirect Wealth','Pyeon Jae','Pyeonjae']},
  '正財': {concept_id:'CONCEPT-TENGOD-JEONGJAE', preferred:'Provider God', technical:'Direct Wealth', korean:'정재', jewel_romanisation:'Jeong Jae', technical_romanisation:'Jeongjae', category:'Wealth', source_id:'SRC-JEWEL-004', aliases:['Direct Wealth','Jeong Jae','Jeongjae']},
  '偏官': {concept_id:'CONCEPT-TENGOD-PYEONGWAN', preferred:'Wild Card God', technical:'Seven Killings / Indirect Officer', korean:'편관', jewel_romanisation:'Pyeon Gwan', technical_romanisation:'Pyeongwan', category:'Authority', source_id:'SRC-JEWEL-004', aliases:['Seven Killings','Indirect Officer','Pyeon Gwan','Pyeongwan']},
  '正官': {concept_id:'CONCEPT-TENGOD-JEONGGWAN', preferred:'Official God', technical:'Direct Officer', korean:'정관', jewel_romanisation:'Jeong Gwan', technical_romanisation:'Jeonggwan', category:'Authority', source_id:'SRC-JEWEL-004', aliases:['Direct Officer','Jeong Gwan','Jeonggwan']},
  '偏印': {concept_id:'CONCEPT-TENGOD-PYEONIN', preferred:'Mystic God', technical:'Indirect Resource', korean:'편인', jewel_romanisation:'Pyeon In', technical_romanisation:'Pyeonin', category:'Input', source_id:'SRC-JEWEL-004', aliases:['Indirect Resource','Pyeon In','Pyeonin']},
  '正印': {concept_id:'CONCEPT-TENGOD-JEONGIN', preferred:'Nurturer God', technical:'Direct Resource', korean:'정인', jewel_romanisation:'Jeong In', technical_romanisation:'Jeongin', category:'Input', source_id:'SRC-JEWEL-004', aliases:['Direct Resource','Jeong In','Jeongin']}
};

export const TEN_GOD_CANONICAL = JEWEL_TEN_GOD_TERMS;

function sourceTitleFromUrl(url){const slug=String(url||'').split('/').filter(Boolean).pop()||'source';return slug.split('-').map(w=>w?`${w[0].toUpperCase()}${w.slice(1)}`:'').join(' ');}

export const INITIAL_SOURCE_MANIFEST = [
  {source_id:'SRC-JEWEL-001',title:'Complete SJPJ Types Guide',creator:'Jewelriet Lee / JewelSJPJ',source_type:'Book',priority:5,priority_label:'CORE',embedded_key:'jewel_guide',uses:['default accessible terminology','60 SJPJ Types','Day Stem accessible names','Day Pillar accessible names','personality/type interpretation','glossary aliases','Learn pages']},
  {source_id:'SRC-JEWEL-002',title:'SJPJ Type Celebrities',creator:'Jewelriet Lee / JewelSJPJ',source_type:'PDF',priority:3,priority_label:'SUPPORTING',embedded_key:'jewel_celebrities',uses:['SJPJ terminology verification','60 Type examples','celebrity examples','Learn/reference material']},
  {source_id:'SRC-JEWEL-003',title:'How to Read Your SJPJ — The Why Part 1',creator:'Jewelriet Lee / JewelSJPJ',source_type:'Course Lesson Capture',priority:5,priority_label:'CORE',embedded_key:'jewel_why_part1',url:'https://jewelsjpj.thinkific.com/courses/take/how-to-read-your-sjpj/lessons/75909096-the-why-part-1',uses:['Ten Gods chart context','Five Elements help cycle','Five Elements hurt/control cycle','Peach Blossom Star','Light Canopy Star','Traveling Horse Star','Learn pages']},
  {source_id:'SRC-JEWEL-004',title:'How to Read Your SJPJ — The Why Part 2',creator:'Jewelriet Lee / JewelSJPJ',source_type:'Course Lesson Capture',priority:5,priority_label:'CORE',embedded_key:'jewel_why_part2',url:'https://jewelsjpj.thinkific.com/courses/take/how-to-read-your-sjpj/lessons/75909098-the-why-part-2',uses:['preferred Ten God terminology','five Ten God categories','beginner-facing Ten God language','glossary aliases','Learn pages','AI-readable terminology']},
  {source_id:'SRC-QIORA-001',title:'Qiora Learn',creator:'Qiora',source_type:'Website',priority:4,priority_label:'HIGH',url:'https://qiora.app/learn/book',crawl_same_site:true,uses:['glossary','Korean/Hanja/English terminology','Five Elements','Yin/Yang','Heavenly Stems','Earthly Branches','Hidden Stems','Ten Gods','interactions','Day Master','Day Master strength','Useful God','Special Stars','Major Luck','timing concepts','Learn content']},
  {source_id:'SRC-WMS-001',title:'What Is Saju?',creator:"What's My Saju",source_type:'Website',priority:3,priority_label:'STANDARD',url:'https://www.whatsmysaju.app/blog/what-is-saju',uses:['beginner explanations','elemental metaphors','Day Master imagery','Four Pillars introduction','Five Elements','glossary aliases','Learn pages']},
  {source_id:'SRC-ATELIER-001',title:'Saju Atelier Library',creator:'Saju Atelier',source_type:'Website Collection',priority:4,priority_label:'HIGH',parent_only:true,uses:['educational/practitioner reference']},
  ...[
    'https://sajuatelier.com/about-saju',
    'https://sajuatelier.com/library/journal/saju-special-stars-guide',
    'https://sajuatelier.com/library/journal/read-saju-chart',
    'https://sajuatelier.com/library/journal/what-is-saju',
    'https://sajuatelier.com/library/journal/korean-zodiac-animals',
    'https://sajuatelier.com/library/journal/ten-year-luck-cycle-saju',
    'https://sajuatelier.com/library/journal/peach-blossom-saju-guide',
    'https://sajuatelier.com/library/journal/baekho-white-tiger-star-saju',
    'https://sajuatelier.com/library/journal/lunar-birthday-saju-which-date',
    'https://sajuatelier.com/library/journal/hurting-officer-sanggwan-saju',
    'https://sajuatelier.com/library/journal/sixty-gapja-cycle-saju',
    'https://sajuatelier.com/library/journal/twenty-four-solar-terms-jeolgi-saju',
    'https://sajuatelier.com/library/journal/annual-luck-seun-yearly-pillar-saju',
    'https://sajuatelier.com/library/journal/spouse-palace-marriage-star-saju',
    'https://sajuatelier.com/library/journal/munchang-academic-star-saju',
    'https://sajuatelier.com/library/journal/cheoneul-gwiin-nobleman-star-saju',
    'https://sajuatelier.com/library/journal/hwagae-canopy-artistic-star-saju',
    'https://sajuatelier.com/library/journal/yangin-blade-star-saju',
    'https://sajuatelier.com/library/journal/wonjin-clash-star-saju',
    'https://sajuatelier.com/library/journal/four-pillars-year-month-day-hour-saju',
    'https://sajuatelier.com/library/journal/yeongma-travel-star-saju',
    'https://sajuatelier.com/library/journal/missing-element-saju',
    'https://sajuatelier.com/library/journal/gongmang-void-saju',
    'https://sajuatelier.com/library/journal/yongsin-useful-god-saju',
    'https://sajuatelier.com/library/journal/samjae-three-disasters-saju',
    'https://sajuatelier.com/library/journal/saju-clashes-and-combinations',
    'https://sajuatelier.com/library/journal/saju-lucky-colors-five-elements',
    'https://sajuatelier.com/library/journal/day-master-strength-saju',
    'https://sajuatelier.com/library/journal/yin-yang-polarity-saju',
    'https://sajuatelier.com/library/journal/hidden-stems-saju',
    'https://sajuatelier.com/library/journal/12-stages-of-energy-saju',
    'https://sajuatelier.com/library/journal/ten-gods-saju-guide',
    'https://sajuatelier.com/library/journal/birth-hour-saju-meaning',
    'https://sajuatelier.com/library/journal/day-master-explained',
    'https://sajuatelier.com/library/journal/five-elements-saju',
    'https://sajuatelier.com/library/journal/saju-compatibility-all-pairings'
  ].map((url,i)=>({source_id:`SRC-ATELIER-001-${String(i+1).padStart(2,'0')}`,parent_source_id:'SRC-ATELIER-001',title:sourceTitleFromUrl(url),creator:'Saju Atelier',source_type:'Article',priority:4,priority_label:'HIGH',url}))
];

export function normaliseAliasKey(value){
  return String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\-_–—·.()/'’]+/g,'');
}

export function jiaziRecords(){
  return Array.from({length:60},(_,i)=>{
    const stem=STEM_META[i%10], branch=BRANCH_META[i%12], characters=`${stem.hanja}${branch.hanja}`, korean=`${stem.korean}${branch.korean}`;
    const preferred=`${stem.preferred} ${branch.animal}`, technical=`${stem.technical} ${branch.animal}`, romanisation=`${stem.romanisation}-${branch.romanisation}`;
    return {index:i,number:i+1,characters,korean,romanisation,preferred,technical,stem,branch,concept_id:`CONCEPT-JIAZI-${String(i+1).padStart(2,'0')}-${stem.romanisation.toUpperCase()}-${branch.romanisation.toUpperCase()}`,
      aliases:[characters,korean,romanisation,romanisation.replace('-',' '),technical,preferred]};
  });
}

export function canonicalConceptId(concept={}){
  if(concept.concept_id)return concept.concept_id;
  const hanja=String(concept.hanja||'').trim();
  const j=jiaziRecords().find(x=>x.characters===hanja); if(j)return j.concept_id;
  if(JEWEL_STEM_TERMS[hanja])return `CONCEPT-STEM-${JEWEL_STEM_TERMS[hanja].romanisation.toUpperCase()}`;
  if(TEN_GOD_CANONICAL[hanja])return TEN_GOD_CANONICAL[hanja].concept_id;
  const slug=String(concept.english||concept.korean||hanja||concept.id||'concept').normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu,'-').replace(/^-|-$/g,'').toUpperCase();
  return `CONCEPT-${slug||'UNKNOWN'}`;
}

export function decorateConcept(concept={}){
  const c={...concept}; const hanja=String(c.hanja||'').trim(); const stem=JEWEL_STEM_TERMS[hanja]; const tg=TEN_GOD_CANONICAL[hanja]; const j=jiaziRecords().find(x=>x.characters===hanja);
  const aliases=[]; const source_specific_names=[];
  for(const v of [c.english,c.korean,c.hanja,c.romanisation])if(v)aliases.push(v);
  let preferred=c.english||c.korean||c.hanja||'Concept',technical=c.english||'';
  if(stem){preferred=stem.preferred;technical=stem.technical;aliases.push(stem.preferred,stem.technical,stem.korean,stem.romanisation,`${hanja}${stem.technical.split(' ')[1]||''}`);source_specific_names.push({term:stem.preferred,source_id:'SRC-JEWEL-001',alias_type:'preferred UI label',language:'English'});}
  if(tg){preferred=tg.preferred;technical=c.english||tg.technical;aliases.push(tg.preferred,tg.technical,tg.korean,tg.jewel_romanisation,tg.technical_romanisation,...tg.aliases);source_specific_names.push({term:tg.preferred,source_id:tg.source_id,alias_type:'preferred UI label',language:'English'},{term:tg.jewel_romanisation,source_id:tg.source_id,alias_type:'romanisation',language:'Korean romanisation'});for(const a of tg.aliases.filter(a=>a!==tg.preferred&&a!==tg.jewel_romanisation))source_specific_names.push({term:a,source_id:'STATIC-VERIFIED',alias_type:'alternative translation',language:'English'});}
  if(j){preferred=j.preferred;technical=j.technical;aliases.push(...j.aliases);source_specific_names.push({term:j.preferred,source_id:'SRC-JEWEL-001',alias_type:'preferred UI label',language:'English'});}
  for(const a of c.source_specific_names||[]) { if(a?.term){aliases.push(a.term);source_specific_names.push(a);} }
  for(const a of c.search_aliases||[])aliases.push(typeof a==='string'?a:a?.term);
  const unique=[...new Map(aliases.filter(Boolean).map(x=>[normaliseAliasKey(x),String(x)])).values()];
  const byType=type=>[...new Set(source_specific_names.filter(x=>x.alias_type===type).map(x=>x.term).filter(Boolean))];
  return {...c,notion_id:c.notion_id||c.id||null,concept_id:canonicalConceptId({...c,hanja}),preferred_display_name:preferred,jewel_sjpj_name:stem?.preferred||tg?.preferred||j?.preferred||null,jewel_ten_god_category:tg?.category||null,technical_english_name:technical,korean_hangul:c.korean||stem?.korean||j?.korean||'',hanja:c.hanja||j?.characters||'',korean_romanisation:c.romanisation||stem?.romanisation||j?.romanisation||'',chinese_pinyin:c.chinese_pinyin||'',alternative_translations:[...(c.alternative_translations||[]),...byType('alternative translation')],source_specific_names,abbreviations:[...(c.abbreviations||[]),...byType('abbreviation')],metaphors:[...(c.metaphors||[]),...byType('metaphor')],legacy_names:[...(c.legacy_names||[]),...byType('legacy terminology')],search_aliases:unique,related_concepts:c.related_concepts||[]};
}

export function virtualJiaziConcepts(){
  return jiaziRecords().map(j=>decorateConcept({id:j.concept_id,notion_id:null,concept_id:j.concept_id,english:j.preferred,korean:j.korean,hanja:j.characters,romanisation:j.romanisation,category:'60 Jiazi',element:j.stem.technical.split(' ')[1],yin_yang:j.stem.technical.split(' ')[0],animal:j.branch.animal,definition:'One of the sixty stem-branch combinations in the sexagenary cycle. The accessible SJPJ Type name follows JewelSJPJ terminology.',interpretation_notes:'Interpretive source material is linked through the Research Library and should not be treated as a calculation rule.',search_aliases:j.aliases,source_specific_names:[{term:j.preferred,source_id:'SRC-JEWEL-001',alias_type:'preferred UI label',language:'English'}]}));
}

export function virtualTenGodConcepts(){
  return Object.entries(JEWEL_TEN_GOD_TERMS).map(([hanja,t])=>decorateConcept({id:t.concept_id,notion_id:null,concept_id:t.concept_id,english:t.technical,korean:t.korean,hanja,romanisation:t.technical_romanisation,category:'Ten Gods',definition:`${t.preferred} is JewelSJPJ's preferred accessible label for ${t.korean} ${hanja}, conventionally labelled ${t.technical} in this application's technical English.`,interpretation_notes:`JewelSJPJ groups this God in the ${t.category} category. Interpretive meaning should remain source-attributed and must not alter deterministic Ten God calculation.`,search_aliases:[t.preferred,t.technical,t.korean,t.jewel_romanisation,t.technical_romanisation,...t.aliases],source_specific_names:[{term:t.preferred,source_id:'SRC-JEWEL-004',alias_type:'preferred UI label',language:'English'},{term:t.jewel_romanisation,source_id:'SRC-JEWEL-004',alias_type:'romanisation',language:'Korean romanisation'}]}));
}

export function mergeGlossaryConcepts(base=[]){
  const decorated=base.map(x=>decorateConcept(x)); const existing=new Set(decorated.map(x=>String(x.hanja||'').trim()).filter(Boolean));
  for(const tg of virtualTenGodConcepts())if(!existing.has(tg.hanja)){decorated.push(tg);existing.add(tg.hanja);}
  for(const j of virtualJiaziConcepts())if(!existing.has(j.hanja)){decorated.push(j);existing.add(j.hanja);}
  return decorated;
}

export function preferredStemName(hanja){return JEWEL_STEM_TERMS[String(hanja||'').trim()]?.preferred||null;}
export function preferredJiaziName(stemHanja,branchAnimal){const s=preferredStemName(stemHanja);return s&&branchAnimal?`${s} ${branchAnimal}`:null;}

export function preferredTenGodName(value){const raw=String(value?.hanja||value?.ko||value?.korean||value?.en||value?.key||value||'').trim();if(!raw)return null;const byHanja=JEWEL_TEN_GOD_TERMS[raw];if(byHanja)return byHanja.preferred;const norm=normaliseAliasKey(raw);for(const [hanja,t] of Object.entries(JEWEL_TEN_GOD_TERMS)){if([hanja,t.preferred,t.technical,t.korean,t.jewel_romanisation,t.technical_romanisation,...t.aliases].some(x=>normaliseAliasKey(x)===norm))return t.preferred;}return null;}
export function tenGodTermRecord(value){const raw=String(value?.hanja||value?.ko||value?.korean||value?.en||value?.key||value||'').trim();if(!raw)return null;const norm=normaliseAliasKey(raw);for(const [hanja,t] of Object.entries(JEWEL_TEN_GOD_TERMS)){if([hanja,t.preferred,t.technical,t.korean,t.jewel_romanisation,t.technical_romanisation,...t.aliases].some(x=>normaliseAliasKey(x)===norm))return {hanja,...t};}return null;}

export function sourceById(id){return INITIAL_SOURCE_MANIFEST.find(x=>x.source_id===id)||null;}
export function sourceManifestForUi(){return INITIAL_SOURCE_MANIFEST.map(({embedded_key,...x})=>({...x,embedded:!!embedded_key}));}
