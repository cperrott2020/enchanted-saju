import {
  calculateDailyContext, parsePillarText, tenGod, localDateString, localDateTimeString, localHour,
  DAILY_ENGINE_VERSION, STEMS, BRANCHES, relationshipEventsForPillar, growthStage
} from './daily_engine.js';
import {
  DEFAULT_AI_MODEL, AI_READING_VERSION,
  buildDailyAiMessages, extractAiReadingText, formatDailyReadingText
} from './ai_daily.js';
import {
  JOURNAL_LAYOUT_VERSION, TODAY_DASHBOARD_VERSION, GENERATED_CONTAINER_MARKER, CALCULATED_CONTEXT_MARKER, AI_READING_MARKER, JOURNAL_MARKER,
  blockPlainText, generatedContainerBlock, calculatedContextBlock, aiReadingBlock,
  calculatedContextChildren, aiReadingChildren, journalScaffoldBlocks, extractAiBodyFromStoredReading,
  todayHeaderBlock, aiUnavailableBlock, savedDailyLuckBlocks
} from './journal_layout.js';
import { masterResultFromPayload } from './result_schema.js';
import { compactJsonForNotion, technicalResultForNotion } from './notion_json_storage.js';
import { METHOD_REGISTRY, DEFAULT_ANALYSIS_SETTINGS, ANALYSIS_VERSION, RESULT_SCHEMA_VERSION, methodologyStatus } from './method_registry.js';
import { annualLuckRange, monthlyLuckYear, dailyLuckMonth } from './luck_explorer.js';
import { convertLunarToGregorian } from './phase1/lunar_conversion.js';
import { compareCharts, conceptMatchesTechnical, buildCalculationInspector, UPDATE3_VERSION } from './update3_features.js';
import {
  KNOWLEDGE_PACK_VERSION, JEWEL_STEM_TERMS, JEWEL_TEN_GOD_TERMS, INITIAL_SOURCE_MANIFEST,
  decorateConcept, mergeGlossaryConcepts, normaliseAliasKey, jiaziRecords,
  preferredStemName, preferredJiaziName, preferredTenGodName, sourceManifestForUi, sourceById
} from './knowledge_pack.js';
import { JEWEL_GUIDE_SOURCE_TEXT, JEWEL_CELEBRITIES_SOURCE_TEXT, JEWEL_WHY_PART1_SOURCE_TEXT, JEWEL_WHY_PART2_SOURCE_TEXT } from './knowledge_source_text.js';

const NOTION_VERSION = '2026-03-11';
const NOTION_API = 'https://api.notion.com/v1';

const TARGET_TITLES = {
  people: 'People',
  charts: 'Charts',
  readings: 'Readings',
  luckCycles: 'Luck Cycles',
  concepts: 'Saju Concepts',
  dailyLuck: 'Daily Luck'
};

const OPTIONAL_TITLES = {
  researchSources: 'Research Sources',
  researchNotes: 'Research Notes',
  teachers: 'Teachers & Authors',
  lifeEvents: 'Life Events'
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith('/api/')) {
      if (request.method === 'OPTIONS') return cors(new Response(null, { status: 204 }), request, env);

      try {
        requireSaveKey(request, env);

        if (url.pathname === '/api/health' && request.method === 'GET') {
          return json({ ok: true, service: 'Enchanted Saju → Notion Bridge', version: UPDATE3_VERSION, daily_engine: DAILY_ENGINE_VERSION, ai_reading_version: AI_READING_VERSION, ai_daily_enabled: aiDailyEnabled(env), ai_binding_configured: !!env.AI, ai_model: aiModel(env), journal_layout_version: JOURNAL_LAYOUT_VERSION, today_dashboard_version: TODAY_DASHBOARD_VERSION, lunar_conversion_ready: true, save_pipeline_version:'update-3.2-split-save-v1', knowledge_pack_version:KNOWLEDGE_PACK_VERSION }, 200, request, env);
        }

        if (url.pathname === '/api/connection' && request.method === 'GET') {
          const me = await notionRequest('/users/me', {}, env);
          const resolved = await resolveTargets(null, env);
          await notionRequest(`/data_sources/${resolved.people}/query`, { method: 'POST', body: { page_size: 1 } }, env);
          await notionRequest(`/data_sources/${resolved.dailyLuck}/query`, { method: 'POST', body: { page_size: 1 } }, env);
          const dailySchema=await notionRequest(`/data_sources/${resolved.dailyLuck}`, {}, env);
          const requiredJournalFields=['Social Energy','Stress','Resonance','Highlights','Challenges','Custom Tags'];
          const journalFieldsReady=requiredJournalFields.every(name=>dailySchema?.properties?.[name]||dailySchema?.schema?.[name]);
          const lifeEventsId=await resolveLifeEventsTarget(env);
          await notionRequest(`/data_sources/${lifeEventsId}/query`, {method:'POST',body:{page_size:1}},env);
          const todayPageId = await resolveTodayPageId(env);
          if (!todayPageId) fail(404, 'The Notion Today page could not be found. Update 1 needs access to the main Today page.');
          try { await notionRequest(`/pages/${todayPageId}`, {}, env); }
          catch (error) { fail(404, 'The Saju Cloudflare Bridge cannot access the main Notion Today page. In Notion, open Today → ••• → Connections and add “Saju Cloudflare Bridge”.'); }
          return json({
            ok: true,
            notion_connected: true,
            bot_name: me?.name || 'Notion integration',
            people_data_source_access: true,
            daily_luck_data_source_access: true,
            update2_journal_fields_ready: journalFieldsReady,
            life_events_data_source_access: true,
            update3_features: ['people_library','chart_compare','learn_library','research_provenance','personal_notes','calculation_inspector','canonical_concept_identity','alias_search','initial_source_pack'],
            knowledge_pack_version: KNOWLEDGE_PACK_VERSION,
            life_events_data_source_id: lifeEventsId,
            daily_timezone: dailyTimezone(env),
            scheduled_generation_enabled: dailyEnabled(env),
            ai_daily_enabled: aiDailyEnabled(env),
            ai_binding_configured: !!env.AI,
            ai_model: aiModel(env),
            journal_layout_version: JOURNAL_LAYOUT_VERSION,
            today_dashboard_version: TODAY_DASHBOARD_VERSION,
            today_page_configured: !!env.SAJU_TODAY_PAGE_ID,
            today_page_access: true,
            today_page_id: todayPageId,
            resolved_data_sources: resolved,
            resolved_titles: TARGET_TITLES,
            result_schema_version: RESULT_SCHEMA_VERSION,
            analysis_version: ANALYSIS_VERSION,
            methodology: methodologyStatus(),
            lunar_conversion_ready: true
          }, 200, request, env);
        }

        if (url.pathname === '/api/people' && request.method === 'GET') {
          const result = await listPeopleAndCharts(env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/profiles' && request.method === 'GET') {
          const result = await listPeopleAndCharts(env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/compare' && request.method === 'GET') {
          const result = await compareSavedProfiles({ personA:url.searchParams.get('person_a')||'', personB:url.searchParams.get('person_b')||'' }, env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/learn/concept' && request.method === 'GET') {
          const result = await loadConceptLearningEntry({ id:url.searchParams.get('id')||'', personId:url.searchParams.get('person_id')||'' }, env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/notes' && request.method === 'GET') {
          const result = await listPersonalNotes({ subjectType:url.searchParams.get('subject_type')||'', subjectKey:url.searchParams.get('subject_key')||'' }, env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/notes/save' && request.method === 'POST') {
          const body=await parseOptionalJsonRequest(request);
          const result = await savePersonalNote(body,env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/research/library' && request.method === 'GET') {
          const result = await listResearchLibrary({ limit:Number(url.searchParams.get('limit')||100) }, env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/research/source' && request.method === 'GET') {
          const result = await loadResearchSourceDetail(url.searchParams.get('id')||'', env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/calculation/inspector' && request.method === 'GET') {
          const chartId=url.searchParams.get('chart_id')||'';
          if(!chartId) fail(400,'chart_id is required.');
          const app=await loadChartApplicationData(chartId,env);
          return json({ok:true,inspector:buildCalculationInspector({technical:app.technical_result,audit:app.calculation_audit,chart:app.chart})},200,request,env);
        }

        if (url.pathname === '/api/profile/default' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await setDefaultProfile(String(body.person_id || ''), env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/profile/update' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await updateSavedProfile(body, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/journal' && request.method === 'GET') {
          const result = await listJournalEntries({
            personId: url.searchParams.get('person_id') || '',
            limit: Number(url.searchParams.get('limit') || 60)
          }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/journal/day' && request.method === 'GET') {
          const result = await getJournalDay({ personId:url.searchParams.get('person_id')||'', chartId:url.searchParams.get('chart_id')||'', date:url.searchParams.get('date')||localDateString(Date.now(), dailyTimezone(env)), timezone:url.searchParams.get('timezone')||dailyTimezone(env) }, env);
          return json({ ok:true, ...result },200,request,env);
        }

        if (url.pathname === '/api/journal/save' && request.method === 'POST') {
          const body=await parseOptionalJsonRequest(request);
          const result=await saveJournalDay(body,env);
          return json({ok:true,...result},200,request,env);
        }

        if (url.pathname === '/api/journal/analytics' && request.method === 'GET') {
          const result=await journalAnalytics({personId:url.searchParams.get('person_id')||'',limit:Number(url.searchParams.get('limit')||90)},env);
          return json({ok:true,...result},200,request,env);
        }

        if (url.pathname === '/api/life-events' && request.method === 'GET') {
          const result=await listLifeEvents({personId:url.searchParams.get('person_id')||''},env);
          return json({ok:true,...result},200,request,env);
        }

        if (url.pathname === '/api/life-events/save' && request.method === 'POST') {
          const body=await parseOptionalJsonRequest(request);
          const result=await saveLifeEvent(body,env);
          return json({ok:true,...result},200,request,env);
        }

        if (url.pathname === '/api/timeline' && request.method === 'GET') {
          const result=await buildLifeTimeline({personId:url.searchParams.get('person_id')||'',chartId:url.searchParams.get('chart_id')||'',startYear:url.searchParams.get('start_year'),endYear:url.searchParams.get('end_year')},env);
          return json({ok:true,...result},200,request,env);
        }

        if (url.pathname === '/api/jiazi' && request.method === 'GET') {
          const idx=url.searchParams.get('index');
          const all=jiaziReference();
          const result=idx===null?all:all[Number(idx)];
          if(!result) fail(404,'60-Jiazi reference entry not found.');
          return json({ok:true,jiazi:result},200,request,env);
        }

        if (url.pathname === '/api/chart' && request.method === 'GET') {
          const chartId = url.searchParams.get('id');
          if (!chartId) fail(400, 'Chart id is required.');
          const result = await loadChartApplicationData(chartId, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/concepts' && request.method === 'GET') {
          const concepts = await loadGlossaryConceptIndex(env);
          return json({ ok: true, concepts, terminology_precedence:'jewel-accessible-first', knowledge_pack_version:KNOWLEDGE_PACK_VERSION }, 200, request, env);
        }

        if (url.pathname === '/api/knowledge-pack' && request.method === 'GET') {
          const report = await knowledgePackStatus(env);
          return json({ ok:true, version:KNOWLEDGE_PACK_VERSION, ...report }, 200, request, env);
        }

        if (url.pathname === '/api/knowledge-pack/ensure-concepts' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await ensureKnowledgeConcepts({ offset:Number(body.offset||0), batch_size:Number(body.batch_size||8) }, env);
          return json({ ok:true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/knowledge-pack/import-source' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await importKnowledgeSource(String(body.source_id||''), env);
          return json({ ok:true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/luck/annual' && request.method === 'GET') {
          const result = await exploreAnnualLuck(url.searchParams, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/luck/monthly' && request.method === 'GET') {
          const result = await exploreMonthlyLuck(url.searchParams, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/luck/calendar' && request.method === 'GET') {
          const result = await exploreDailyCalendar(url.searchParams, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/natal/interpret' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await generateNatalInterpretation(body, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/research/fetch-url' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await fetchResearchUrl(body.url);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/research/youtube' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await fetchYouTubeMetadata(body.url);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/research/analyze' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await analyzeResearchSource(body, env);
          return json({ ok: true, ...result }, 200, request, env);
        }


        if (url.pathname === '/api/research/upload-file' && request.method === 'POST') {
          const result = await uploadResearchFile(request, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/research/save' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const result = await saveResearchSource(body, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/calendar/lunar-to-solar' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const calendar_conversion = await convertLunarToGregorian({ year:body.year, month:body.month, day:body.day, leapMonth:body.leap_month === true });
          return json({ ok:true, calendar_conversion }, 200, request, env);
        }

        if (url.pathname === '/api/save-chart' && request.method === 'POST') {
          const payload = await parseJsonRequest(request);
          validatePayload(payload);
          // Update 3.2 deliberately saves the core Person + Chart in one small
          // invocation, then lets the browser finish page-body audit / Luck Cycle
          // records in a second invocation. This keeps Workers Free below the
          // 50 external-subrequest ceiling without weakening any calculation.
          const result = await saveSajuProfileCore(payload, env);
          return json({ ok: true, ...result, finalize_required: true }, 200, request, env);
        }

        if (url.pathname === '/api/save-chart/finalize' && request.method === 'POST') {
          const body = await parseJsonRequest(request);
          const payload = body?.payload;
          validatePayload(payload);
          if (!body?.chart_id) fail(400, 'chart_id is required to finalize a saved chart.');
          const result = await finalizeSavedChart({
            payload,
            chartId: String(body.chart_id),
            personId: String(body.person_id || ''),
            revision: Number(body.revision || 1),
            concepts: Array.isArray(body.concepts) ? body.concepts : []
          }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/daily/calculate' && request.method === 'GET') {
          const timezone = url.searchParams.get('timezone') || dailyTimezone(env);
          const date = url.searchParams.get('date') || localDateString(Date.now(), timezone);
          const result = await buildDailyContextFromNotion({ date, timezone, personId:url.searchParams.get('person_id')||'', chartId:url.searchParams.get('chart_id')||'' }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/daily/generate' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const timezone = body.timezone || dailyTimezone(env);
          const date = body.date || localDateString(Date.now(), timezone);
          const result = await generateDailyLuck({ date, timezone, personId:body.person_id||'', chartId:body.chart_id||'', trigger: 'manual', generateAi: body.generate_ai !== false }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/daily/interpret' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const timezone = body.timezone || dailyTimezone(env);
          const date = body.date || localDateString(Date.now(), timezone);
          const result = await regenerateDailyAiReading({ date, timezone, personId:body.person_id||'', chartId:body.chart_id||'' }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/daily/render' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const timezone = body.timezone || dailyTimezone(env);
          const date = body.date || localDateString(Date.now(), timezone);
          const result = await refreshDailyJournalLayout({ date, timezone, personId:body.person_id||'', chartId:body.chart_id||'' }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        if (url.pathname === '/api/today/refresh' && request.method === 'POST') {
          const body = await parseOptionalJsonRequest(request);
          const timezone = body.timezone || dailyTimezone(env);
          const date = body.date || localDateString(Date.now(), timezone);
          const result = await refreshTodayDashboard({ date, timezone, personId:body.person_id||'', chartId:body.chart_id||'' }, env);
          return json({ ok: true, ...result }, 200, request, env);
        }

        return json({ ok: false, error: 'Not found' }, 404, request, env);
      } catch (error) {
        const status = Number(error?.status) || 500;
        return json({ ok: false, error: error?.message || String(error), details: error?.details || null }, status, request, env);
      }
    }

    return env.ASSETS.fetch(request);
  },

  async scheduled(controller, env, ctx) {
    if (!dailyEnabled(env)) return;
    const timezone = dailyTimezone(env);
    const scheduledMs = Number(controller?.scheduledTime || Date.now());
    // The trigger runs hourly; only the local midnight occurrence writes a daily record.
    if (localHour(scheduledMs, timezone) !== 0) return;
    const date = localDateString(scheduledMs, timezone);
    ctx.waitUntil(
      generateDailyLuck({ date, timezone, trigger: 'cron', generateAi: true }, env)
        .then(r => console.log('Daily Luck generated', JSON.stringify({ date, page: r.daily_luck?.id, created: r.created, ai: r.ai_reading?.ok ?? null })))
        .catch(e => console.error('Daily Luck generation failed', e?.message || String(e)))
    );
  }
};

function requireSaveKey(request, env) {
  if (!env.SAJU_SAVE_KEY) {
    const e = new Error('SAJU_SAVE_KEY is not configured on this Worker.');
    e.status = 500;
    throw e;
  }
  const supplied = request.headers.get('X-Saju-Key') || '';
  if (!timingSafeEqual(supplied, env.SAJU_SAVE_KEY)) {
    const e = new Error('Connection key is missing or incorrect.');
    e.status = 401;
    throw e;
  }
}

function timingSafeEqual(a, b) {
  a = String(a); b = String(b);
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function parseJsonRequest(request) {
  const text = await request.text();
  try { return JSON.parse(text); }
  catch {
    const e = new Error('Request body was not valid JSON.');
    e.status = 400;
    throw e;
  }
}

async function parseOptionalJsonRequest(request) {
  const text = await request.text();
  if (!text.trim()) return {};
  try { return JSON.parse(text); }
  catch { fail(400, 'Request body was not valid JSON.'); }
}

function dailyTimezone(env) {
  return String(env.SAJU_DAILY_TIMEZONE || 'Asia/Seoul').trim();
}

function dailyEnabled(env) {
  return String(env.SAJU_DAILY_ENABLED ?? 'true').toLowerCase() !== 'false';
}

function aiDailyEnabled(env) {
  return String(env.SAJU_AI_DAILY_ENABLED ?? 'true').toLowerCase() !== 'false';
}

function aiModel(env) {
  return String(env.SAJU_AI_MODEL || DEFAULT_AI_MODEL).trim();
}

function validatePayload(p) {
  if (!p || p.action !== 'upsert_saju_profile') fail(400, 'Unsupported or missing action.');
  if (!p.person?.name) fail(400, 'Person name is required.');
  if (!p.person?.birth_date) fail(400, 'Birth date is required.');
  if (p.options?.create_chart && !p.chart) fail(400, 'Chart payload is missing.');
}

async function saveSajuProfileCore(payload, env) {
  const t = await resolveTargets(payload, env);
  const options = {
    upsert_person: payload.options?.upsert_person !== false,
    create_chart: payload.options?.create_chart !== false,
    create_major_luck_cycles: payload.options?.create_major_luck_cycles !== false,
    create_reading: payload.options?.create_reading === true
  };

  let person = null;
  let personReused = false;

  if (options.upsert_person) {
    const exactPersonId = String(payload.person?.id || payload.person?.person_id || '').trim();
    if (exactPersonId) {
      // PATCH returns the updated page, so a preliminary GET would only consume
      // an extra external subrequest. Stable profile IDs remain authoritative.
      person = await updatePerson(exactPersonId, payload.person, env);
      personReused = true;
    } else {
      const existing = await findPerson(t.people, payload.person, env);
      if (existing) {
        person = await updatePerson(existing.id, payload.person, env);
        personReused = true;
      } else {
        person = await createPerson(t.people, payload.person, env);
      }
    }
    if (person?.id && payload.person?.default_profile === true) {
      await setDefaultProfile(person.id, env, t.people);
      // updatePerson/createPerson already returned the selected profile. No
      // second GET is required merely to continue saving the Chart.
      if (person.properties?.['Default Profile']) person.properties['Default Profile'].checkbox = true;
    }
  }

  const conceptIndex = await loadConceptIndex(t.concepts, env);
  let chart = null;
  let revision = 1;

  if (options.create_chart) {
    const previousPrimaryId = person ? primaryChartId(person) : null;
    if (previousPrimaryId) {
      try {
        const previous = await notionRequest(`/pages/${previousPrimaryId}`, {}, env);
        revision = Math.max(1, Number(previous.properties?.['Current Revision']?.number || 1) + 1);
      } catch {}
    }
    chart = await createChart(t.charts, payload, person?.id || null, conceptIndex, revision, env);

    if (person?.id) {
      await notionRequest(`/pages/${person.id}`, {
        method: 'PATCH',
        body: { properties: { 'Primary Chart': relation([chart.id]) } }
      }, env);
    }
  }

  // Technical Result JSON and Calculation Audit JSON are already persisted by
  // createChart(). Heavy secondary Notion writes are finalized by a separate
  // Worker invocation to stay safely below Cloudflare Free's subrequest limit.
  return {
    person_reused: personReused,
    person: summarizePage(person),
    chart: summarizePage(chart),
    revision,
    finalize_context: {
      concepts: conceptIndex.map(c=>({id:c.id,english:c.english,korean:c.korean,hanja:c.hanja,category:c.category,element:c.element}))
    },
    finalize_plan: {
      append_page_audit: !!chart,
      create_major_luck_cycles: !!chart && options.create_major_luck_cycles && Array.isArray(payload.major_luck_cycles),
      create_reading: !!chart && options.create_reading && !!payload.reading
    },
    major_luck_cycles_created: 0,
    major_luck_cycles: [],
    reading: null
  };
}

async function finalizeSavedChart({payload, chartId, personId, revision, concepts=[]}, env) {
  const t = await resolveTargets(payload, env);
  const options = {
    create_major_luck_cycles: payload.options?.create_major_luck_cycles !== false,
    create_reading: payload.options?.create_reading === true
  };
  const conceptIndex = Array.isArray(concepts) && concepts.length ? concepts : await loadConceptIndex(t.concepts, env);

  const audit = await appendAudit(chartId, payload, revision, env);
  const createdCycles = [];
  let skippedCycles = 0;

  if (options.create_major_luck_cycles && Array.isArray(payload.major_luck_cycles)) {
    const existing = await notionRequest(`/data_sources/${t.luckCycles}/query`, {
      method:'POST',
      body:{
        page_size:100,
        filter:{and:[
          {property:'Chart',relation:{contains:chartId}},
          {property:'Cycle Type',select:{equals:'Major Luck'}}
        ]}
      }
    }, env);
    const existingKeys = new Set((existing.results || []).map(p => {
      const title = plainTitle(p.properties?.['Cycle']);
      const start = p.properties?.['Start Age']?.number;
      return `${title}|${Number.isFinite(start)?Number(start).toFixed(3):''}`;
    }));
    for (const cycle of payload.major_luck_cycles) {
      const key = `${cycle.label || `Major Luck ${cycle.cycle_number || ''}`.trim()}|${Number.isFinite(Number(cycle.start_age))?Number(cycle.start_age).toFixed(3):''}`;
      if (existingKeys.has(key)) { skippedCycles++; continue; }
      const created = await createLuckCycle(t.luckCycles, cycle, chartId, conceptIndex, env);
      createdCycles.push(created);
      existingKeys.add(key);
      await sleep(360);
    }
  }

  let reading = null;
  if (options.create_reading && payload.reading) {
    // Reading creation is optional and normally disabled. Avoid duplicate
    // readings when the browser retries the finalize invocation.
    const readingDate = payload.reading.reading_date || todayIso();
    const readingType = payload.reading.reading_type || 'Natal';
    const found = await notionRequest(`/data_sources/${t.readings}/query`, {
      method:'POST',
      body:{page_size:5,filter:{and:[
        {property:'Chart',relation:{contains:chartId}},
        {property:'Reading Type',select:{equals:readingType}},
        {property:'Reading Date',date:{equals:readingDate}}
      ]}}
    }, env);
    reading = found.results?.[0] || await createReading(t.readings, payload.reading, payload.person, personId || null, chartId, env);
  }

  return {
    finalized:true,
    audit_appended: audit.appended,
    audit_already_present: audit.already_present,
    major_luck_cycles_created: createdCycles.length,
    major_luck_cycles_skipped: skippedCycles,
    major_luck_cycles: createdCycles.map(summarizePage),
    reading: summarizePage(reading)
  };
}

async function resolveTargets(payload, env) {
  const hints = payload?.notion_targets || {};
  const configured = {
    people: env.NOTION_PEOPLE_DS || hints.people_data_source_id || null,
    charts: env.NOTION_CHARTS_DS || hints.charts_data_source_id || null,
    readings: env.NOTION_READINGS_DS || hints.readings_data_source_id || null,
    luckCycles: env.NOTION_LUCK_DS || hints.luck_cycles_data_source_id || null,
    concepts: env.NOTION_CONCEPTS_DS || hints.concepts_data_source_id || null,
    dailyLuck: env.NOTION_DAILY_LUCK_DS || hints.daily_luck_data_source_id || null
  };

  // Update 3.2 fast path: the shipped workspace pins all required data-source
  // IDs in wrangler.toml. Trust those stable IDs during normal API work and let
  // /api/connection perform explicit access validation. This avoids seven
  // redundant Notion subrequests on every chart save.
  const allConfigured = Object.keys(TARGET_TITLES).every(key => configured[key]);
  if (allConfigured) return { ...configured };

  // Portable/fallback installs without complete IDs still use discovery.
  const shared = await listSharedDataSources(env);
  const byTitle = new Map(shared.map(ds => [normalizeTitle(dataSourceTitle(ds)), ds]));

  const resolved = {};
  const missing = [];

  for (const [key, titleName] of Object.entries(TARGET_TITLES)) {
    // Prefer an explicit data-source ID over title discovery. The workspace can
    // contain unrelated databases with generic titles such as “People”. v1.6
    // previously resolved the title first, which could select the wrong database
    // and then fail on properties such as Birth Date.
    const candidate = configured[key];
    if (candidate) {
      try {
        const ds = await notionRequest(`/data_sources/${candidate}`, {}, env);
        resolved[key] = ds.id || candidate;
        continue;
      } catch (e) {
        // A stale override should not break portable installs; fall back to
        // title discovery only when the configured data source no longer exists.
        if (Number(e?.status) !== 404) throw e;
      }
    }

    const exact = byTitle.get(normalizeTitle(titleName));
    if (exact?.id) {
      resolved[key] = exact.id;
      continue;
    }

    // Search by title directly in case the first list was incomplete.
    const searched = await searchDataSourceByTitle(titleName, env);
    if (searched?.id) {
      resolved[key] = searched.id;
      continue;
    }
    missing.push(titleName);
  }

  if (missing.length) {
    const visible = shared.map(dataSourceTitle).filter(Boolean).sort();
    const e = new Error(
      `The Notion integration is connected, but it cannot see these required data sources: ${missing.join(', ')}.` +
      (visible.length ? ` It can currently see: ${visible.join(', ')}.` : ' It currently sees no shared data sources.') +
      ' In Notion, open each ORIGINAL database and add the “Saju Cloudflare Bridge” connection.'
    );
    e.status = 404;
    e.details = { missing, visible_data_sources: visible };
    throw e;
  }

  return resolved;
}

async function listSharedDataSources(env) {
  const out = [];
  let cursor;
  do {
    const body = { page_size: 100, filter: { property: 'object', value: 'data_source' } };
    if (cursor) body.start_cursor = cursor;
    const res = await notionRequest('/search', { method: 'POST', body }, env);
    out.push(...(res.results || []).filter(x => x.object === 'data_source'));
    cursor = res.has_more ? res.next_cursor : undefined;
  } while (cursor && out.length < 500);
  return out;
}

async function searchDataSourceByTitle(titleName, env) {
  const res = await notionRequest('/search', {
    method: 'POST',
    body: {
      query: titleName,
      page_size: 50,
      filter: { property: 'object', value: 'data_source' }
    }
  }, env);
  const results = (res.results || []).filter(x => x.object === 'data_source');
  const wanted = normalizeTitle(titleName);
  return results.find(x => normalizeTitle(dataSourceTitle(x)) === wanted) || results[0] || null;
}

function dataSourceTitle(ds) {
  return (ds?.title || []).map(x => x.plain_text || x.text?.content || '').join('').trim();
}

function normalizeTitle(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

async function findPerson(dataSourceId, person, env) {
  const body = {
    page_size: 10,
    filter: {
      and: [
        { property: 'Name', title: { equals: person.name } },
        { property: 'Birth Date', date: { equals: person.birth_date } }
      ]
    }
  };
  const res = await notionRequest(`/data_sources/${dataSourceId}/query`, { method: 'POST', body }, env);
  return res.results?.[0] || null;
}

async function createPerson(dataSourceId, person, env) {
  return notionRequest('/pages', {
    method: 'POST',
    body: {
      parent: { data_source_id: dataSourceId },
      properties: personProperties(person)
    }
  }, env);
}

async function updatePerson(pageId, person, env) {
  return notionRequest(`/pages/${pageId}`, {
    method: 'PATCH',
    body: { properties: personProperties(person) }
  }, env);
}

function personProperties(p) {
  const notes = [
    Number.isFinite(Number(p.latitude)) && Number.isFinite(Number(p.longitude)) ? `Coordinates: ${p.latitude}, ${p.longitude}` : null,
    p.timezone ? `Timezone: ${p.timezone}` : null,
    p.sex ? `Sex basis: ${p.sex}` : null,
    p.birth_time_status ? `Birth-time status: ${p.birth_time_status}` : null
  ].filter(Boolean).join(' · ');

  const birthStatus = ({ exact:'Exact', approximate:'Approximate', unknown:'Unknown' })[String(p.birth_time_status || '').toLowerCase()] || null;
  const props = {
    'Name': title(p.name),
    'Preferred Name': rich(p.preferred_name || ''),
    'Person Type': select(p.person_type || 'Friend'),
    'Birth Date': dateProp(p.birth_date),
    'Birth Time': rich(p.birth_time || ''),
    'Birth Time Status': select(birthStatus),
    'Birthplace': rich(p.birthplace || ''),
    'Sex / Luck Basis': select(({female:'Female',male:'Male',unspecified:'Unspecified'})[String(p.sex||'').toLowerCase()] || p.sex_basis || 'Unspecified'),
    'Profile Category': select(p.profile_category || (p.person_type==='Me'?'Me':p.person_type==='Family'?'Family':p.person_type==='Friend'?'Friend':'Other')),
    'Profile Notes': rich(p.profile_notes || ''),
    'Notes': rich(notes)
  };
  if(p.default_profile !== undefined) props['Default Profile']=checkbox(!!p.default_profile);
  return props;
}

async function createChart(dataSourceId, payload, personId, concepts, revision, env) {
  const c = payload.chart;
  const master = masterResultFromPayload(payload);
  master.revision.current = Number(revision || 1);
  master.revision.parent_revision = revision > 1 ? revision - 1 : null;
  const dmConcept = findConcept(concepts, { hanja: c.day_master?.hanja, korean: c.day_master?.ko || c.day_master?.korean, english: c.day_master?.roman || c.day_master?.english });
  const elementIds = collectElementRelations(c, concepts);
  const tenGodIds = collectTenGodRelations(c, concepts);
  const usefulName = master.useful_element?.result?.english || master.useful_element?.element || null;
  const favourableName = master.favourable_element?.result?.english || master.favourable_element?.element || null;
  const unfavourableNames = Array.isArray(master.unfavourable_element?.result)
    ? master.unfavourable_element.result.map(x => x?.english || x?.element || x).filter(Boolean)
    : [master.unfavourable_element?.result?.english || master.unfavourable_element?.element].filter(Boolean);
  const usefulConcept = usefulName ? findConcept(concepts, { english: usefulName }) : null;
  const favourableConcept = favourableName ? findConcept(concepts, { english: favourableName }) : null;
  const unfavourableConceptIds = unfavourableNames.map(name => findConcept(concepts, { english:name })).filter(Boolean).map(x=>x.id);

  const props = {
    'Chart Name': title(c.chart_name || `${payload.person.name} · Natal Saju`),
    'Status': select(c.status || 'Verified'),
    'Birth Date': dateProp(c.birth_date || payload.person.birth_date),
    'Recorded Birth Time': rich(c.recorded_birth_time || ''),
    'Corrected Time': rich(c.corrected_time || ''),
    'Birthplace': rich(c.birthplace || payload.person.birthplace || ''),
    'Timezone': rich(c.timezone || payload.person.timezone || ''),
    'Calendar Type': select(c.calendar_type || 'Gregorian'),
    'Year Pillar': rich(c.year_pillar || ''),
    'Month Pillar': rich(c.month_pillar || ''),
    'Day Pillar': rich(c.day_pillar || ''),
    'Hour Pillar': rich(c.hour_pillar || ''),
    'Chart Strength': select(master.strength?.classification || 'Methodology Pending'),
    'Strength Index': numberProp(master.strength?.strength_index),
    'Boundary Warning': checkbox(!!c.boundary_warning),
    'Calculation Version': rich(c.calculation_version || ''),
    'Calculation Reference': rich(c.calculation_reference || ''),
    'Analysis Version': rich(ANALYSIS_VERSION),
    'Analysis Settings': rich(JSON.stringify(master.analysis_settings)),
    'Strength Method': rich(master.strength?.method || METHOD_REGISTRY.chart_strength || 'Methodology Pending'),
    'Useful Element Method': rich(master.useful_element?.method || METHOD_REGISTRY.useful_element || 'Methodology Pending'),
    'Symbolic Star Method': rich(master.symbolic_stars?.method || METHOD_REGISTRY.symbolic_stars || 'Methodology Pending'),
    'Major Luck Method': rich(payload.raw_calculation?.daewoon?.method || c.major_luck_method || ''),
    'Daewoon Start Age': numberProp(payload.raw_calculation?.daewoon?.start_age_years),
    'Daewoon Number': numberProp((payload.major_luck_cycles || []).length),
    'Technical Result JSON': rich(compactJsonForNotion(technicalResultForNotion(master), 'Technical Result JSON')),
    'Calculation Audit JSON': rich(compactJsonForNotion(master.calculation_audit, 'Calculation Audit JSON')),
    'Current Revision': numberProp(revision || 1),
    'Person': relation(personId ? [personId] : []),
    'Day Master': relation(dmConcept ? [dmConcept.id] : []),
    'Elements': relation(elementIds),
    'Ten Gods': relation(tenGodIds),
    'Useful Element': relation(usefulConcept ? [usefulConcept.id] : []),
    'Favourable Element': relation(favourableConcept ? [favourableConcept.id] : []),
    'Unfavourable Element': relation(unfavourableConceptIds)
  };

  return notionRequest('/pages', {
    method: 'POST',
    body: { parent: { data_source_id: dataSourceId }, properties: props }
  }, env);
}

async function appendAudit(chartPageId, payload, revision, env) {
  const AUDIT_MARKER='ENCHANTED_SAJU_AUDIT_UPDATE_3_2';
  const existingChildren = await listAllBlockChildren(chartPageId, env);
  if(existingChildren.some(b => blockPlainText(b) === AUDIT_MARKER)){
    return {appended:false,already_present:true};
  }

  const master = masterResultFromPayload(payload);
  master.revision.current = Number(revision || 1);
  master.revision.parent_revision = revision > 1 ? revision - 1 : null;
  const u=master.useful_element, f=master.favourable_element, un=master.unfavourable_element;
  const uName=u?.result?.english||u?.element||'Unavailable';
  const fName=f?.result?.english||f?.element||'Unavailable';
  const unNames=Array.isArray(un?.result)?un.result.map(x=>x?.english||x?.element||x).join(', '):(un?.result?.english||un?.element||'Unavailable');
  const starText=(master.symbolic_stars?.detected||[]).map(x=>`${x.star} (${(x.detected_in||[]).join(', ')})`).join(' · ')||'None detected by enabled rules';
  const twelveText=Object.entries(master.twelve_stars?.pillars||{}).map(([p,x])=>`${p}: ${x.korean} ${x.hanja}`).join(' · ')||'Unavailable';
  const auditJson=JSON.stringify(master);
  const auditRich=chunkText(auditJson,1850).slice(0,95).map(content=>({type:'text',text:{content}}));
  if(auditRich.map(x=>x.text.content.length).reduce((a,b)=>a+b,0) < auditJson.length){
    fail(413,'Readable Chart-page audit exceeds one safe Notion code block. The complete audit is already preserved in Calculation Audit JSON; reduce audit payload before retrying page rendering.');
  }
  const children = [
    {object:'block',type:'paragraph',paragraph:{rich_text:[{type:'text',text:{content:AUDIT_MARKER}}]}},
    {object:'block',type:'heading_2',heading_2:{rich_text:[{type:'text',text:{content:'Advanced Deterministic Analysis'}}]}},
    {object:'block',type:'callout',callout:{icon:{type:'emoji',emoji:'🪷'},rich_text:[{type:'text',text:{content:`Useful Element · 용신 用神: ${uName}\nFavourable Element · 희신 喜神: ${fName}\nUnfavourable Element · 기신 忌神: ${unNames}\nMethod: ${u?.method||METHOD_REGISTRY.useful_element}`}}]}},
    {object:'block',type:'paragraph',paragraph:{rich_text:[{type:'text',text:{content:`Symbolic Stars · 신살 — ${starText}\nMethod: ${master.symbolic_stars?.method||METHOD_REGISTRY.symbolic_stars}`}}]}},
    {object:'block',type:'paragraph',paragraph:{rich_text:[{type:'text',text:{content:`Twelve Stars · 십이신살 — ${twelveText}\nMethod: ${master.twelve_stars?.method||METHOD_REGISTRY.twelve_stars}\nThis is separate from Twelve Growth Stages · 십이운성.`}}]}},
    {object:'block',type:'heading_2',heading_2:{rich_text:[{type:'text',text:{content:'Calculation Audit'}}]}},
    {object:'block',type:'paragraph',paragraph:{rich_text:[{type:'text',text:{content:`Revision ${revision || 1}. Full structured data is stored in Technical Result JSON and Calculation Audit JSON. The code block below is a readable mirror and does not drive calculation.`}}]}},
    {object:'block',type:'toggle',toggle:{rich_text:[{type:'text',text:{content:'Method Registry'}}],children:[{object:'block',type:'code',code:{language:'json',rich_text:[{type:'text',text:{content:JSON.stringify(METHOD_REGISTRY)}}]}}]}},
    {object:'block',type:'code',code:{language:'json',rich_text:auditRich}}
  ];
  for(let i=0;i<children.length;i+=90){
    await appendBlockChildren(chartPageId,children.slice(i,i+90),env);
  }
  return {appended:true,already_present:false};
}
async function createLuckCycle(dataSourceId, cycle, chartId, concepts, env) {
  const stemConcept = findConcept(concepts, {
    hanja: cycle.stem?.hanja,
    korean: cycle.stem?.ko || cycle.stem?.korean,
    english: cycle.stem?.roman || cycle.stem?.english
  });
  const branchConcept = findConcept(concepts, {
    hanja: cycle.branch?.hanja,
    korean: cycle.branch?.ko || cycle.branch?.korean,
    english: cycle.branch?.roman || cycle.branch?.english
  });
  const elementName = cycle.stem?.element || cycle.branch?.element || null;
  const elementConcept = elementName ? findConcept(concepts, { english: elementName }) : null;
  const tg = cycle.ten_god || cycle.stem?.ten_god || null;
  const tgConcept = findConcept(concepts, { hanja: tg?.hanja, korean: tg?.ko || tg?.korean, english: tg?.en || tg?.english });

  const props = {
    'Cycle': title(cycle.label || `Major Luck ${cycle.cycle_number || ''}`.trim()),
    'Cycle Type': select(cycle.cycle_type || 'Major Luck'),
    'Start Age': numberProp(cycle.start_age),
    'End Age': numberProp(cycle.end_age),
    'Stem': rich(cycle.stem?.hanja || cycle.stem?.ko || ''),
    'Branch': rich(cycle.branch?.hanja || cycle.branch?.ko || ''),
    'Element': select(elementName),
    'Animal': rich(cycle.branch?.animal || ''),
    'Ten God': rich(tg?.en || tg?.english || tg?.ko || ''),
    'Interpretation': rich(''),
    'Chart': relation([chartId]),
    'Stem Concept': relation(stemConcept ? [stemConcept.id] : []),
    'Branch Concept': relation(branchConcept ? [branchConcept.id] : []),
    'Element Concept': relation(elementConcept ? [elementConcept.id] : []),
    'Ten God Concept': relation(tgConcept ? [tgConcept.id] : [])
  };

  return notionRequest('/pages', {
    method: 'POST',
    body: { parent: { data_source_id: dataSourceId }, properties: props }
  }, env);
}

async function createReading(dataSourceId, reading, person, personId, chartId, env) {
  const props = {
    'Reading': title(`${person.name} · ${reading.reading_type || 'Natal'} Reading · ${reading.reading_date || todayIso()}`),
    'Reading Date': dateProp(reading.reading_date || todayIso()),
    'Reading Type': select(reading.reading_type || 'Natal'),
    'Status': select(reading.status || 'Draft'),
    'Main Themes': rich(reading.main_themes || reading.note || ''),
    'Person': relation(personId ? [personId] : []),
    'Chart': relation([chartId])
  };
  return notionRequest('/pages', {
    method: 'POST',
    body: { parent: { data_source_id: dataSourceId }, properties: props }
  }, env);
}

async function loadConceptIndex(dataSourceId, env) {
  const all = [];
  let cursor = undefined;
  do {
    const body = { page_size: 100 };
    if (cursor) body.start_cursor = cursor;
    const res = await notionRequest(`/data_sources/${dataSourceId}/query`, { method: 'POST', body }, env);
    all.push(...(res.results || []));
    cursor = res.has_more ? res.next_cursor : undefined;
  } while (cursor && all.length < 500);

  return all.map(page => decorateConcept({
    id: page.id,
    notion_id: page.id,
    url: page.url,
    english: plainTitle(page.properties?.['English Name']),
    korean: plainRich(page.properties?.['Korean']),
    hanja: plainRich(page.properties?.['Hanja']),
    category: page.properties?.['Category']?.select?.name || '',
    element: page.properties?.['Element Name']?.select?.name || '',
    yin_yang: page.properties?.['Yin Yang']?.select?.name || '',
    animal: plainRich(page.properties?.['Animal']),
    romanisation: plainRich(page.properties?.['Romanisation']),
    definition: plainRich(page.properties?.['Definition']),
    interpretation_notes: plainRich(page.properties?.['Interpretation Notes']),
    source_ids: (page.properties?.['Sources']?.relation || []).map(x => x.id),
    research_note_ids: (page.properties?.['Research Notes']?.relation || []).map(x => x.id)
  }));
}

function findConcept(concepts, q = {}) {
  const probes=[q.concept_id,q.hanja,q.korean,q.english,q.romanisation].filter(Boolean).map(normaliseAliasKey);
  if(!probes.length) return null;
  return concepts.find(c=>probes.includes(normaliseAliasKey(c.concept_id)))
    || concepts.find(c=>probes.some(p=>(c.search_aliases||[]).some(a=>normaliseAliasKey(typeof a==='string'?a:a?.term)===p)))
    || concepts.find(c=>probes.some(p=>[c.hanja,c.korean,c.english,c.romanisation,c.preferred_display_name,c.technical_english_name].filter(Boolean).some(v=>normaliseAliasKey(v)===p)))
    || null;
}

const SOURCE_META_MARKER='ESJ_SOURCE_META:';
function parseSourceMeta(notes=''){
  const raw=String(notes||''); const idx=raw.indexOf(SOURCE_META_MARKER); if(idx<0)return null;
  const line=raw.slice(idx+SOURCE_META_MARKER.length).split('\n')[0].trim();
  try{return JSON.parse(line);}catch{return null;}
}
function sourceMetaText(meta,conflicts=[]){
  const safe={source_id:meta.source_id||'',parent_source_id:meta.parent_source_id||null,priority:meta.priority||null,priority_label:meta.priority_label||'',aliases:(meta.aliases||[]).slice(0,120)};
  return `${SOURCE_META_MARKER}${JSON.stringify(safe)}${conflicts.length?`\nConflicts: ${conflicts.join(' | ')}`:''}`;
}

async function loadGlossaryConceptIndex(env){
  const core=await resolveTargets(null,env); const concepts=mergeGlossaryConcepts(await loadConceptIndex(core.concepts,env));
  try{
    const t=await resolveOptionalTargets(env); const pages=await queryAllDataSourcePages(t.researchSources,{},env,500);
    for(const page of pages){
      const source=researchSourceSummary(page); const meta=source.source_identity||{};
      for(const alias of meta.aliases||[]){
        const c=findConcept(concepts,{concept_id:alias.concept_id,english:alias.canonical_english});
        if(!c||!alias.term)continue;
        c.source_specific_names=[...(c.source_specific_names||[]),{term:alias.term,source_id:meta.source_id||source.id,alias_type:alias.alias_type||'source-specific terminology',language:alias.language||'English'}];
        c.search_aliases=[...(c.search_aliases||[]),alias.term];
        c.source_ids=[...new Set([...(c.source_ids||[]),source.id])];
      }
    }
    for(let i=0;i<concepts.length;i++) concepts[i]=decorateConcept(concepts[i]);
  }catch{}
  return concepts;
}

function collectElementRelations(chart, concepts) {
  const presence = chart?.five_elements?.combined_unweighted_presence || {};
  return Object.entries(presence)
    .filter(([, count]) => Number(count) > 0)
    .map(([name]) => findConcept(concepts, { english: name }))
    .filter(Boolean)
    .map(x => x.id);
}

function collectTenGodRelations(chart, concepts) {
  const ids = new Set();
  const add = tg => {
    if (!tg) return;
    const c = findConcept(concepts, { hanja: tg.hanja, korean: tg.ko || tg.korean, english: tg.en || tg.english });
    if (c) ids.add(c.id);
  };
  for (const pillar of Object.values(chart?.pillars || {})) {
    add(pillar?.stem?.ten_god);
    for (const hs of pillar?.hidden_stems || []) add(hs?.ten_god);
  }
  return [...ids];
}


async function buildDailyContextFromNotion({ date, timezone, personId='', chartId='' }, env) {
  const prepared = await prepareDailyContext({ date, timezone, personId, chartId }, env);
  return publicDailyContext(prepared);
}

async function prepareDailyContext({ date, timezone, personId='', chartId='' }, env) {
  const targets = await resolveTargets(null, env);
  const selected = await resolveProfileForContext(targets.people, { personId, chartId }, env);
  const person = selected.person;
  chartId = selected.chartId;
  if (!chartId) fail(404, 'The selected profile does not have a Primary Chart. Save/verify its natal chart first.');
  const chart = await notionRequest(`/pages/${chartId}`, {}, env);
  const natal = natalFromChartPage(chart);
  const birthDate = pageDateStart(person.properties?.['Birth Date']) || pageDateStart(chart.properties?.['Birth Date']);
  if (!birthDate) fail(422, 'The selected profile or Primary Chart needs a Birth Date before Daily Luck can be generated.');

  const calculated = calculateDailyContext({ date, timezone, natal });
  const currentMajor = await findCurrentMajorCycle(targets.luckCycles, chartId, birthDate, date, env);
  return { targets, person, chart, natal, birthDate, calculated, currentMajor, timezone, date };
}

function publicDailyContext(p) {
  return {
    date: p.date,
    timezone: p.timezone,
    person: { id: p.person.id, url: p.person.url || null, name: plainTitle(p.person.properties?.['Name']) },
    chart: { id: p.chart.id, url: p.chart.url || null, name: plainTitle(p.chart.properties?.['Chart Name']) },
    natal: {
      day_master: p.natal.day.stem,
      pillars: Object.fromEntries(Object.entries(p.natal).map(([k,v]) => [k, v ? v.label : null]))
    },
    cycles: {
      year: p.calculated.year,
      month: p.calculated.month,
      day: p.calculated.day,
      current_major_luck: p.currentMajor ? summarizeLuckPage(p.currentMajor) : null
    },
    daily_identity: {
      sexagenary_index:p.calculated.day.sexagenary_index,
      label:p.calculated.day.label,
      stem:p.calculated.day.stem,
      branch:p.calculated.day.branch,
      ten_god:p.calculated.day.ten_god,
      incoming_elements:[p.calculated.day.stem.element,p.calculated.day.branch.element]
    },
    interactions: p.calculated.natal_interactions,
    structured_interactions:p.calculated.structured_interactions||[],
    interactions_text: p.calculated.interactions_text,
    boundary_warnings: p.calculated.boundary_warnings,
    engine: p.calculated.engine
  };
}

async function resolveProfileForContext(dataSourceId, { personId='', chartId='' } = {}, env) {
  const cleanPersonId=String(personId||'').replace(/-/g,'');
  const cleanChartId=String(chartId||'').replace(/-/g,'');
  if (cleanPersonId) {
    const person=await notionRequest(`/pages/${cleanPersonId}`, {}, env);
    const allowed=(person.properties?.['Charts']?.relation||[]).map(x=>String(x.id).replace(/-/g,''));
    const primary=primaryChartId(person);
    const resolvedChart=cleanChartId || primary;
    if(cleanChartId && !allowed.includes(cleanChartId) && String(primary||'').replace(/-/g,'')!==cleanChartId) fail(409,'The selected chart does not belong to the selected profile.');
    return {person, chartId:resolvedChart};
  }
  if (cleanChartId) {
    const chart=await notionRequest(`/pages/${cleanChartId}`, {}, env);
    const pid=chart.properties?.['Person']?.relation?.[0]?.id;
    if(!pid) fail(409,'The selected chart is not linked to a profile.');
    const person=await notionRequest(`/pages/${pid}`, {}, env);
    return {person, chartId:cleanChartId};
  }
  const def=await notionRequest(`/data_sources/${dataSourceId}/query`, {method:'POST',body:{page_size:20,filter:{property:'Default Profile',checkbox:{equals:true}}}}, env);
  const preferred=(def.results||[]).find(p=>primaryChartId(p));
  if(preferred) return {person:preferred,chartId:primaryChartId(preferred)};
  try {
    const me=await findMePerson(dataSourceId,env);
    if(me) return {person:me,chartId:primaryChartId(me)};
  } catch {}
  const any=await notionRequest(`/data_sources/${dataSourceId}/query`, {method:'POST',body:{page_size:100}}, env);
  const first=(any.results||[]).find(p=>primaryChartId(p));
  if(!first) fail(404,'No saved profile with a verified Primary Chart was found.');
  return {person:first,chartId:primaryChartId(first)};
}

async function findMePerson(dataSourceId, env) {
  const res = await notionRequest(`/data_sources/${dataSourceId}/query`, {
    method: 'POST',
    body: { page_size: 20, filter: { property: 'Person Type', select: { equals: 'Me' } } }
  }, env);
  const people = res.results || [];
  if (!people.length) fail(404, 'No Person with Person Type = “Me” was found. Mark your own People record as Me first.');
  return people.find(p => primaryChartId(p)) || people[0];
}

function primaryChartId(personPage) {
  return personPage?.properties?.['Primary Chart']?.relation?.[0]?.id || null;
}

function pageDateStart(prop) { return prop?.date?.start ? String(prop.date.start).slice(0,10) : null; }

function natalFromChartPage(chart) {
  const fields = { year:'Year Pillar', month:'Month Pillar', day:'Day Pillar', hour:'Hour Pillar' };
  const natal = {};
  for (const [key,prop] of Object.entries(fields)) {
    const text = plainRich(chart.properties?.[prop]);
    natal[key] = text ? parsePillarText(text) : null;
  }
  if (!natal.day) fail(422, 'The Primary Chart Day Pillar could not be parsed. Re-save the verified natal chart from the calculator.');
  if (!natal.year || !natal.month) fail(422, 'The Primary Chart needs parseable Year, Month and Day Pillars for Daily Luck generation.');
  return natal;
}

async function findCurrentMajorCycle(dataSourceId, chartId, birthDate, targetDate, env) {
  const res = await notionRequest(`/data_sources/${dataSourceId}/query`, {
    method: 'POST',
    body: {
      page_size: 50,
      filter: { and: [
        { property: 'Cycle Type', select: { equals: 'Major Luck' } },
        { property: 'Chart', relation: { contains: chartId } }
      ] },
      sorts: [{ property: 'Start Age', direction: 'ascending' }]
    }
  }, env);
  const age = decimalAge(birthDate, targetDate);
  return (res.results || []).find(p => {
    const start = Number(p.properties?.['Start Age']?.number);
    const end = Number(p.properties?.['End Age']?.number);
    return Number.isFinite(start) && Number.isFinite(end) && age >= start && age < end;
  }) || null;
}

function decimalAge(birthDate, targetDate) {
  const [by,bm,bd]=birthDate.split('-').map(Number);
  const [ty,tm,td]=targetDate.split('-').map(Number);
  return (Date.UTC(ty,tm-1,td,12)-Date.UTC(by,bm-1,bd,12))/(365.2425*86400000);
}

function summarizeLuckPage(page) {
  if (!page) return null;
  return {
    id: page.id, url: page.url || null,
    cycle: plainTitle(page.properties?.['Cycle']),
    cycle_type: page.properties?.['Cycle Type']?.select?.name || '',
    start_age: page.properties?.['Start Age']?.number ?? null,
    end_age: page.properties?.['End Age']?.number ?? null,
    stem: plainRich(page.properties?.['Stem']),
    branch: plainRich(page.properties?.['Branch']),
    element: page.properties?.['Element']?.select?.name || '',
    animal: plainRich(page.properties?.['Animal']),
    ten_god: plainRich(page.properties?.['Ten God'])
  };
}

async function generateDailyLuck({ date, timezone, personId='', chartId='', trigger = 'manual', generateAi = true }, env) {
  const p = await prepareDailyContext({ date, timezone, personId, chartId }, env);
  const concepts = await loadConceptIndex(p.targets.concepts, env);
  const dm = p.natal.day.stem.index;

  const yearTG = tenGod(dm, p.calculated.year.stem.index);
  const monthTG = tenGod(dm, p.calculated.month.stem.index);

  const annual = await ensureTimeCycle(p.targets.luckCycles, {
    title: `${p.calculated.year.effective_saju_year} · Annual · ${p.calculated.year.label}`,
    cycleType: 'Annual',
    start: localDateString(Date.parse(p.calculated.year.start_utc), timezone),
    end: localDateString(Date.parse(p.calculated.year.end_utc), timezone),
    pillar: p.calculated.year,
    tenGod: yearTG,
    chartId: p.chart.id,
    interactions: ''
  }, concepts, env);

  const monthly = await ensureTimeCycle(p.targets.luckCycles, {
    title: `${localDateString(Date.parse(p.calculated.month.start_utc), timezone)} · Monthly · ${p.calculated.month.label}`,
    cycleType: 'Monthly',
    start: localDateString(Date.parse(p.calculated.month.start_utc), timezone),
    end: localDateString(Date.parse(p.calculated.month.end_utc), timezone),
    pillar: p.calculated.month,
    tenGod: monthTG,
    chartId: p.chart.id,
    interactions: ''
  }, concepts, env);

  const daily = await upsertDailyLuck(p.targets.dailyLuck, p, concepts, annual, monthly, env);

  // Page-body presentation is deliberately separate from the deterministic
  // database write. A layout problem must never roll back or invalidate the
  // calculated Daily Luck record.
  let journalLayout = { ok: false, version: JOURNAL_LAYOUT_VERSION };
  try {
    const rendered = await renderCalculatedContextSection(daily.page.id, p, env);
    journalLayout = { ok: true, version: JOURNAL_LAYOUT_VERSION, ...rendered };
  } catch (error) {
    journalLayout = { ok: false, version: JOURNAL_LAYOUT_VERSION, error: error?.message || String(error) };
  }

  let aiReading = { enabled: aiDailyEnabled(env), attempted: false, ok: false, model: aiModel(env) };
  if (generateAi && aiDailyEnabled(env)) {
    aiReading.attempted = true;
    try {
      aiReading = { ...aiReading, ...(await writeAiDailyReadingOnly(daily.page.id, p, concepts, env)), ok: true };
    } catch (error) {
      aiReading = { ...aiReading, ok: false, error: error?.message || String(error) };
    }
  }

  let todayDashboard = { attempted: false, ok: false, version: TODAY_DASHBOARD_VERSION };
  if (p.date === localDateString(Date.now(), timezone)) {
    todayDashboard.attempted = true;
    try {
      todayDashboard = { ...todayDashboard, ...(await syncTodayPage(daily.page.id, p, env)), ok: true };
    } catch (error) {
      todayDashboard = { ...todayDashboard, ok: false, error: error?.message || String(error) };
    }
  }

  return {
    trigger,
    created: daily.created,
    updated_existing: !daily.created,
    daily_luck: summarizePage(daily.page),
    annual_cycle: summarizePage(annual),
    monthly_cycle: summarizePage(monthly),
    current_major_luck: p.currentMajor ? summarizeLuckPage(p.currentMajor) : null,
    ai_reading: aiReading,
    journal_layout: journalLayout,
    today_dashboard: todayDashboard,
    context: publicDailyContext(p)
  };
}

async function regenerateDailyAiReading({ date, timezone, personId='', chartId='' }, env) {
  if (!aiDailyEnabled(env)) fail(409, 'AI Daily Reading is disabled by SAJU_AI_DAILY_ENABLED.');
  const p = await prepareDailyContext({ date, timezone, personId, chartId }, env);
  const found = await notionRequest(`/data_sources/${p.targets.dailyLuck}/query`, {
    method: 'POST',
    body: { page_size: 10, filter: { and: [{ property: 'Date', date: { equals: p.date } }, { property: 'Person', relation: { contains: p.person.id } }] } }
  }, env);
  const dailyPage = found.results?.[0] || null;
  if (!dailyPage) fail(404, `No Daily Luck record exists for ${p.date}. Generate the deterministic Daily Luck record first.`);
  const concepts = await loadConceptIndex(p.targets.concepts, env);
  const result = await writeAiDailyReadingOnly(dailyPage.id, p, concepts, env);
  let todayDashboard = null;
  if (p.date === localDateString(Date.now(), timezone)) {
    try { todayDashboard = { ok: true, ...(await syncTodayPage(dailyPage.id, p, env)) }; }
    catch (error) { todayDashboard = { ok: false, error: error?.message || String(error) }; }
  }
  return { date: p.date, timezone: p.timezone, daily_luck: summarizePage(dailyPage), ai_reading: { ok: true, attempted: true, enabled: true, ...result }, today_dashboard: todayDashboard, context: publicDailyContext(p) };
}

async function refreshDailyJournalLayout({ date, timezone, personId='', chartId='' }, env) {
  const p = await prepareDailyContext({ date, timezone, personId, chartId }, env);
  const found = await notionRequest(`/data_sources/${p.targets.dailyLuck}/query`, {
    method: 'POST',
    body: { page_size: 10, filter: { and: [{ property: 'Date', date: { equals: p.date } }, { property: 'Person', relation: { contains: p.person.id } }] } }
  }, env);
  const dailyPage = found.results?.[0] || null;
  if (!dailyPage) fail(404, `No Daily Luck record exists for ${p.date}. Generate the Daily Luck record first.`);

  await renderCalculatedContextSection(dailyPage.id, p, env);
  const fullPage = await notionRequest(`/pages/${dailyPage.id}`, {}, env);
  const storedReading = plainRich(fullPage.properties?.['Daily Reading']);
  const aiText = extractAiBodyFromStoredReading(storedReading);
  let aiRendered = false;
  if (aiText) {
    await renderAiReadingSection(dailyPage.id, aiText, aiModel(env), AI_READING_VERSION, env);
    aiRendered = true;
  }

  let todayDashboard = null;
  if (p.date === localDateString(Date.now(), timezone)) {
    try { todayDashboard = { ok: true, ...(await syncTodayPage(dailyPage.id, p, env)) }; }
    catch (error) { todayDashboard = { ok: false, error: error?.message || String(error) }; }
  }

  return {
    date: p.date,
    timezone: p.timezone,
    daily_luck: summarizePage(dailyPage),
    journal_layout: { ok: true, version: JOURNAL_LAYOUT_VERSION, calculated_context: true, ai_reading: aiRendered },
    today_dashboard: todayDashboard,
    context: publicDailyContext(p)
  };
}


async function refreshTodayDashboard({ date, timezone, personId='', chartId='' }, env) {
  const p = await prepareDailyContext({ date, timezone, personId, chartId }, env);
  const found = await notionRequest(`/data_sources/${p.targets.dailyLuck}/query`, {
    method: 'POST',
    body: { page_size: 10, filter: { and: [{ property: 'Date', date: { equals: p.date } }, { property: 'Person', relation: { contains: p.person.id } }] } }
  }, env);
  const dailyPage = found.results?.[0] || null;
  if (!dailyPage) fail(404, `No Daily Luck record exists for ${p.date}. Generate the Daily Luck record first.`);
  const synced = await syncTodayPage(dailyPage.id, p, env);
  return { date: p.date, timezone: p.timezone, daily_luck: summarizePage(dailyPage), today_dashboard: { ok: true, ...synced }, context: publicDailyContext(p) };
}

async function syncTodayPage(dailyPageId, p, env) {
  const todayPageId = await resolveTodayPageId(env);
  if (!todayPageId) fail(404, 'Today page could not be found. Set SAJU_TODAY_PAGE_ID in wrangler.toml.');

  const dailyPage = await notionRequest(`/pages/${dailyPageId}`, {}, env);
  const titleText = plainTitle(dailyPage.properties?.['Entry']) || `${p.date} · ${p.calculated.day.label}`;
  const storedReading = plainRich(dailyPage.properties?.['Daily Reading']);
  const aiText = extractAiBodyFromStoredReading(storedReading);

  // Today is intentionally ephemeral. Historical data lives in Daily Luck.
  // We clear only the Today page's child blocks; the source Daily Luck page
  // and its properties/content are never deleted or modified here.
  await clearPageChildren(todayPageId, env);

  await appendBlockChildren(todayPageId, [todayHeaderBlock(p)], env);
  const containerAppend = await appendBlockChildren(todayPageId, [generatedContainerBlock()], env);
  const container = containerAppend.results?.[0];
  if (!container?.id) fail(502, 'Notion did not return the Today dashboard container block ID.');

  const calcAppend = await appendBlockChildren(container.id, [calculatedContextBlock()], env);
  const calcRoot = calcAppend.results?.[0];
  if (calcRoot?.id) await appendBlockChildren(calcRoot.id, calculatedContextChildren(p), env);

  if (aiText) {
    const aiAppend = await appendBlockChildren(container.id, [aiReadingBlock()], env);
    const aiRoot = aiAppend.results?.[0];
    if (aiRoot?.id) await appendBlockChildren(aiRoot.id, aiReadingChildren(aiText, aiModel(env), AI_READING_VERSION), env);
  } else {
    await appendBlockChildren(container.id, [aiUnavailableBlock()], env);
  }

  await appendBlockChildren(todayPageId, savedDailyLuckBlocks(dailyPage.url, titleText, p.timezone), env);

  return {
    version: TODAY_DASHBOARD_VERSION,
    today_page_id: todayPageId,
    source_daily_luck_id: dailyPageId,
    source_daily_luck_url: dailyPage.url || null,
    ai_reading_shown: !!aiText
  };
}

async function clearPageChildren(pageId, env) {
  const children = await listAllBlockChildren(pageId, env);
  for (const block of children) {
    // Archiving/deleting a linked database *view* from Today does not touch
    // the Daily Luck source database. Child pages/databases are not expected
    // in the live Today dashboard after v1.5.
    await notionRequest(`/blocks/${block.id}`, { method: 'DELETE' }, env);
  }
  return children.length;
}

async function resolveTodayPageId(env) {
  const configured = String(env.SAJU_TODAY_PAGE_ID || '').trim();
  if (configured) return configured.replace(/-/g, '');

  const res = await notionRequest('/search', {
    method: 'POST',
    body: { query: 'Today', page_size: 20, filter: { property: 'object', value: 'page' } }
  }, env);
  const exact = (res.results || []).filter(page => notionPageTitle(page) === 'Today');
  return exact[0]?.id || null;
}

function notionPageTitle(page) {
  const props = page?.properties || {};
  for (const prop of Object.values(props)) {
    if (prop?.type === 'title' && Array.isArray(prop.title)) {
      return prop.title.map(x => x?.plain_text || x?.text?.content || '').join('').trim();
    }
  }
  return '';
}

async function writeAiDailyReadingOnly(dailyPageId, p, concepts, env) {
  if (!env.AI) fail(503, 'Workers AI binding is not configured. Deploy v1.4 with [ai] binding = "AI".');
  const model = aiModel(env);
  const messages = buildDailyAiMessages(p, concepts);
  const response = await env.AI.run(model, {
    messages,
    temperature: 0.35,
    max_completion_tokens: 1800,
    reasoning_effort: null,
    chat_template_kwargs: {
      enable_thinking: false,
      clear_thinking: true
    }
  });
  const aiText = extractAiReadingText(response);
  const reading = formatDailyReadingText(p, aiText, model);

  // SECURITY / DATA-INTEGRITY BOUNDARY:
  // The model has no Notion tools. This PATCH contains exactly one property:
  // Daily Reading. All deterministic calculation fields and user journal
  // properties are outside the model's write path.
  await notionRequest(`/pages/${dailyPageId}`, {
    method: 'PATCH',
    body: { properties: { 'Daily Reading': rich(reading) } }
  }, env);

  // Rendering is presentation-only. If Notion rejects a layout block, the
  // Daily Reading property is still safely stored and no calculated field is
  // affected.
  let pageLayout = { ok: false, version: JOURNAL_LAYOUT_VERSION };
  try {
    await renderAiReadingSection(dailyPageId, aiText, model, AI_READING_VERSION, env);
    pageLayout = { ok: true, version: JOURNAL_LAYOUT_VERSION };
  } catch (error) {
    pageLayout = { ok: false, version: JOURNAL_LAYOUT_VERSION, error: error?.message || String(error) };
  }

  return { model, reading_version: AI_READING_VERSION, characters: reading.length, page_layout: pageLayout };
}

async function renderCalculatedContextSection(pageId, p, env) {
  const { containerId, journalCreated } = await ensureGeneratedContainerAndJournal(pageId, env);
  await replaceSectionBlock(containerId, CALCULATED_CONTEXT_MARKER, calculatedContextBlock(), calculatedContextChildren(p), env);
  return { calculated_context: true, journal_scaffold_created: journalCreated };
}

async function renderAiReadingSection(pageId, aiText, model, readingVersion, env) {
  const { containerId, journalCreated } = await ensureGeneratedContainerAndJournal(pageId, env);
  await replaceSectionBlock(containerId, AI_READING_MARKER, aiReadingBlock(), aiReadingChildren(aiText, model, readingVersion), env);
  return { ai_reading: true, journal_scaffold_created: journalCreated };
}

async function ensureGeneratedContainerAndJournal(pageId, env) {
  let top = await listAllBlockChildren(pageId, env);
  let container = top.find(b => blockPlainText(b) === GENERATED_CONTAINER_MARKER) || null;
  if (!container) {
    const appended = await appendBlockChildren(pageId, [generatedContainerBlock()], env);
    container = appended.results?.[0] || null;
    if (!container?.id) fail(502, 'Notion created the Daily Saju container but did not return its block ID.');
    top = [...top, container];
  }

  const hasJournal = top.some(b => blockPlainText(b) === JOURNAL_MARKER);
  let journalCreated = false;
  if (!hasJournal) {
    await appendBlockChildren(pageId, journalScaffoldBlocks(), env);
    journalCreated = true;
  }
  return { containerId: container.id, journalCreated };
}

async function replaceSectionBlock(containerId, marker, rootBlock, childBlocks, env) {
  const children = await listAllBlockChildren(containerId, env);
  const old = children.filter(b => blockPlainText(b) === marker);
  for (const block of old) {
    await notionRequest(`/blocks/${block.id}`, { method: 'DELETE' }, env);
  }

  const appended = await appendBlockChildren(containerId, [rootBlock], env);
  const created = appended.results?.[0] || null;
  if (!created?.id) fail(502, `Notion did not return the new ${marker} block ID.`);
  if (Array.isArray(childBlocks) && childBlocks.length) {
    await appendBlockChildren(created.id, childBlocks, env);
  }
  return created;
}

async function listAllBlockChildren(blockId, env) {
  const out = [];
  let cursor = null;
  do {
    const qs = new URLSearchParams({ page_size: '100' });
    if (cursor) qs.set('start_cursor', cursor);
    const res = await notionRequest(`/blocks/${blockId}/children?${qs.toString()}`, {}, env);
    out.push(...(res.results || []));
    cursor = res.has_more ? res.next_cursor : null;
  } while (cursor);
  return out;
}

async function appendBlockChildren(blockId, children, env) {
  return notionRequest(`/blocks/${blockId}/children`, {
    method: 'PATCH',
    body: { children }
  }, env);
}

async function ensureTimeCycle(dataSourceId, spec, concepts, env) {
  const existing = await notionRequest(`/data_sources/${dataSourceId}/query`, {
    method: 'POST',
    body: {
      page_size: 5,
      filter: { and: [
        { property: 'Cycle', title: { equals: spec.title } },
        { property: 'Cycle Type', select: { equals: spec.cycleType } },
        { property: 'Chart', relation: { contains: spec.chartId } }
      ] }
    }
  }, env);
  if (existing.results?.[0]) return existing.results[0];

  const stemConcept = findConcept(concepts, { hanja: spec.pillar.stem.hanja, korean: spec.pillar.stem.ko, english: spec.pillar.stem.roman });
  const branchConcept = findConcept(concepts, { hanja: spec.pillar.branch.hanja, korean: spec.pillar.branch.ko, english: spec.pillar.branch.roman });
  const elementConcept = findConcept(concepts, { english: spec.pillar.stem.element });
  const tgConcept = findConcept(concepts, { hanja: spec.tenGod.hanja, korean: spec.tenGod.ko, english: spec.tenGod.en });

  return notionRequest('/pages', {
    method: 'POST',
    body: {
      parent: { data_source_id: dataSourceId },
      properties: {
        'Cycle': title(spec.title),
        'Cycle Type': select(spec.cycleType),
        'Start': dateProp(spec.start),
        'End': dateProp(spec.end),
        'Stem': rich(`${spec.pillar.stem.hanja} ${spec.pillar.stem.ko} · ${spec.pillar.stem.roman}`),
        'Branch': rich(`${spec.pillar.branch.hanja} ${spec.pillar.branch.ko} · ${spec.pillar.branch.roman}`),
        'Element': select(spec.pillar.stem.element),
        'Animal': rich(spec.pillar.branch.animal),
        'Ten God': rich(`${spec.tenGod.en} · ${spec.tenGod.ko} ${spec.tenGod.hanja}`),
        'Interactions': rich(spec.interactions || ''),
        'Chart': relation([spec.chartId]),
        'Stem Concept': relation(stemConcept ? [stemConcept.id] : []),
        'Branch Concept': relation(branchConcept ? [branchConcept.id] : []),
        'Element Concept': relation(elementConcept ? [elementConcept.id] : []),
        'Ten God Concept': relation(tgConcept ? [tgConcept.id] : [])
      }
    }
  }, env);
}

async function upsertDailyLuck(dataSourceId, p, concepts, annual, monthly, env) {
  const d = p.calculated.day;
  const stemConcept = findConcept(concepts, { hanja: d.stem.hanja, korean: d.stem.ko, english: d.stem.roman });
  const branchConcept = findConcept(concepts, { hanja: d.branch.hanja, korean: d.branch.ko, english: d.branch.roman });
  const tgConcept = findConcept(concepts, { hanja: d.ten_god.hanja, korean: d.ten_god.ko, english: d.ten_god.en });

  const generated = {
    'Entry': title(`${p.date} · ${d.label}`),
    'Date': dateProp(p.date),
    'Day Stem': rich(`${d.stem.hanja} ${d.stem.ko} · ${d.stem.roman}`),
    'Day Branch': rich(`${d.branch.hanja} ${d.branch.ko} · ${d.branch.roman} · ${d.branch.animal}`),
    'Element': select(d.stem.element),
    'Yin Yang': select(d.stem.yin_yang),
    'Ten God': rich(`${preferredTenGodName(d.ten_god)||d.ten_god.en} · ${d.ten_god.ko} ${d.ten_god.hanja} · ${d.ten_god.en}`),
    'Year Pillar': rich(p.calculated.year.label),
    'Month Pillar': rich(p.calculated.month.label),
    'Interactions': rich(p.calculated.interactions_text + (p.calculated.boundary_warnings.length ? `\nBoundary notes: ${p.calculated.boundary_warnings.join(' | ')}` : '')),
    'Major Cycle': relation(p.currentMajor ? [p.currentMajor.id] : []),
    'Annual Cycle': relation(annual ? [annual.id] : []),
    'Monthly Cycle': relation(monthly ? [monthly.id] : []),
    'Day Stem Concept': relation(stemConcept ? [stemConcept.id] : []),
    'Day Branch Concept': relation(branchConcept ? [branchConcept.id] : []),
    'Ten God Concept': relation(tgConcept ? [tgConcept.id] : []),
    'Person': relation([p.person.id]),
    'Chart': relation([p.chart.id]),
    'Calculation Version': rich(DAILY_ENGINE_VERSION)
  };

  const found = await notionRequest(`/data_sources/${dataSourceId}/query`, {
    method: 'POST',
    body: { page_size: 10, filter: { and: [{ property: 'Date', date: { equals: p.date } }, { property: 'Person', relation: { contains: p.person.id } }] } }
  }, env);
  const existing = found.results?.[0] || null;
  if (existing) {
    const page = await notionRequest(`/pages/${existing.id}`, { method: 'PATCH', body: { properties: generated } }, env);
    return { created:false, page, duplicate_count:Math.max(0,(found.results||[]).length-1) };
  }

  const page = await notionRequest('/pages', {
    method: 'POST',
    body: {
      parent: { data_source_id: dataSourceId },
      properties: { ...generated, 'Reading Match': select('Not Reviewed') }
    }
  }, env);
  return { created:true, page, duplicate_count:0 };
}


async function setDefaultProfile(personId, env, peopleDataSourceId='') {
  if(!personId) fail(400,'person_id is required.');
  const peopleId = peopleDataSourceId || (await resolveTargets(null,env)).people;
  // Query only profiles currently marked default. A full People scan + PATCH of
  // every profile is unnecessary and can consume the Worker subrequest budget.
  const current = await notionRequest(`/data_sources/${peopleId}/query`, {
    method:'POST', body:{page_size:100,filter:{property:'Default Profile',checkbox:{equals:true}}}
  }, env);
  const targetKey=String(personId).replace(/-/g,'');
  let targetWasDefault=false;
  for(const page of (current.results||[])){
    const same=String(page.id).replace(/-/g,'')===targetKey;
    if(same){targetWasDefault=true;continue;}
    const should=false;
    await notionRequest(`/pages/${page.id}`,{method:'PATCH',body:{properties:{'Default Profile':checkbox(should)}}},env);
  }
  if(!targetWasDefault){
    await notionRequest(`/pages/${personId}`,{method:'PATCH',body:{properties:{'Default Profile':checkbox(true)}}},env);
  }
  return {person_id:personId,default_profile:true};
}

async function updateSavedProfile(body, env) {
  const personId=String(body.person_id||'').trim();
  if(!personId) fail(400,'person_id is required.');
  const allowedCategory=new Set(['Me','Partner','Family','Friend','Other']);
  const allowedSex=new Set(['Unspecified','Female','Male']);
  const props={};
  if(body.profile_category!==undefined){if(!allowedCategory.has(body.profile_category))fail(400,'Invalid Profile Category.');props['Profile Category']=select(body.profile_category);}
  if(body.sex_basis!==undefined){if(!allowedSex.has(body.sex_basis))fail(400,'Invalid Sex / Luck Basis.');props['Sex / Luck Basis']=select(body.sex_basis);}
  if(body.profile_notes!==undefined)props['Profile Notes']=rich(String(body.profile_notes||''));
  if(body.preferred_name!==undefined)props['Preferred Name']=rich(String(body.preferred_name||''));
  if(body.default_profile===true){await setDefaultProfile(personId,env);} else if(body.default_profile===false) props['Default Profile']=checkbox(false);
  if(Object.keys(props).length) await notionRequest(`/pages/${personId}`,{method:'PATCH',body:{properties:props}},env);
  return {person_id:personId,updated:true};
}

async function listJournalEntries({personId='',limit=60},env){
  const targets=await resolveTargets(null,env);
  let selectedPersonId=String(personId||'').trim();
  if(!selectedPersonId){const selected=await resolveProfileForContext(targets.people,{},env);selectedPersonId=selected.person.id;}
  const safeLimit=Math.max(1,Math.min(100,Number(limit)||60));
  const res=await notionRequest(`/data_sources/${targets.dailyLuck}/query`,{method:'POST',body:{page_size:safeLimit,filter:{property:'Person',relation:{contains:selectedPersonId}},sorts:[{property:'Date',direction:'descending'}]}},env);
  const entries=(res.results||[]).map(page=>({
    id:page.id,url:page.url||null,entry:plainTitle(page.properties?.['Entry']),date:pageDateStart(page.properties?.['Date']),
    day_stem:plainRich(page.properties?.['Day Stem']),day_branch:plainRich(page.properties?.['Day Branch']),element:page.properties?.['Element']?.select?.name||'',
    ten_god:plainRich(page.properties?.['Ten God']),daily_reading:plainRich(page.properties?.['Daily Reading']),journal:plainRich(page.properties?.['Journal']),
    mood:page.properties?.['Mood']?.select?.name||'',energy:page.properties?.['Energy']?.number??null,productivity:page.properties?.['Productivity']?.number??null,
    social_energy:page.properties?.['Social Energy']?.number??null,stress:page.properties?.['Stress']?.number??null,resonance:page.properties?.['Resonance']?.select?.name||'',
    highlights:plainRich(page.properties?.['Highlights']),challenges:plainRich(page.properties?.['Challenges']),custom_tags:plainRich(page.properties?.['Custom Tags']),tags:(page.properties?.['Tags']?.multi_select||[]).map(x=>x.name),
    events:plainRich(page.properties?.['Events']),retrospective:plainRich(page.properties?.['Retrospective']),person_id:selectedPersonId,
    chart_id:page.properties?.['Chart']?.relation?.[0]?.id||null
  }));
  return {person_id:selectedPersonId,entries,count:entries.length};
}


const JOURNAL_MOOD_TO_SCORE={'Very Low':1,'Low':2,'Neutral':3,'Good':4,'Very Good':5};
const JOURNAL_SCORE_TO_MOOD={1:'Very Low',2:'Low',3:'Neutral',4:'Good',5:'Very Good'};
const STANDARD_JOURNAL_TAGS=new Set(['Work','Study','Relationship','Family','Health','Travel','Creativity','Money','Social','Rest']);

async function findDailyPage(targets,personId,date,env){
  const res=await notionRequest(`/data_sources/${targets.dailyLuck}/query`,{method:'POST',body:{page_size:10,filter:{and:[{property:'Date',date:{equals:date}},{property:'Person',relation:{contains:personId}}]}}},env);
  return res.results?.[0]||null;
}
function journalPageData(page){if(!page)return null;return {id:page.id,url:page.url||null,date:pageDateStart(page.properties?.['Date']),entry:plainTitle(page.properties?.['Entry']),daily_reading:plainRich(page.properties?.['Daily Reading']),journal:plainRich(page.properties?.['Journal']),mood_label:page.properties?.['Mood']?.select?.name||'',mood:JOURNAL_MOOD_TO_SCORE[page.properties?.['Mood']?.select?.name]||null,energy:page.properties?.['Energy']?.number??null,productivity:page.properties?.['Productivity']?.number??null,social_energy:page.properties?.['Social Energy']?.number??null,stress:page.properties?.['Stress']?.number??null,resonance:page.properties?.['Resonance']?.select?.name||'',highlights:plainRich(page.properties?.['Highlights']),challenges:plainRich(page.properties?.['Challenges']),tags:(page.properties?.['Tags']?.multi_select||[]).map(x=>x.name),custom_tags:plainRich(page.properties?.['Custom Tags']),ten_god:plainRich(page.properties?.['Ten God']),element:page.properties?.['Element']?.select?.name||'',day_stem:plainRich(page.properties?.['Day Stem']),day_branch:plainRich(page.properties?.['Day Branch']),animal:plainRich(page.properties?.['Animal']),yin_yang:page.properties?.['Yin Yang']?.select?.name||'',interactions:plainRich(page.properties?.['Interactions']),person_id:page.properties?.['Person']?.relation?.[0]?.id||null,chart_id:page.properties?.['Chart']?.relation?.[0]?.id||null};}

async function getJournalDay({personId='',chartId='',date,timezone},env){
  const p=await prepareDailyContext({date,timezone,personId,chartId},env);
  const page=await findDailyPage(p.targets,p.person.id,date,env);
  return {context:publicDailyContext(p),journal:journalPageData(page)};
}

async function saveJournalDay(body,env){
  const timezone=body.timezone||dailyTimezone(env),date=body.date||localDateString(Date.now(),timezone);
  const p=await prepareDailyContext({date,timezone,personId:body.person_id||'',chartId:body.chart_id||''},env);
  let page=await findDailyPage(p.targets,p.person.id,date,env);
  if(!page){const generated=await generateDailyLuck({date,timezone,personId:p.person.id,chartId:p.chart.id,trigger:'journal',generateAi:false},env);page=await notionRequest(`/pages/${generated.daily_luck.id}`,{},env);}
  const clamp=v=>v===null||v===undefined||v===''?null:Math.max(1,Math.min(5,Number(v)||1));
  const tags=Array.isArray(body.tags)?body.tags.map(String):[];
  const mapped=tags;
  const standard=mapped.filter(x=>STANDARD_JOURNAL_TAGS.has(x));
  const custom=[...(Array.isArray(body.custom_tags)?body.custom_tags:[]),...mapped.filter(x=>!STANDARD_JOURNAL_TAGS.has(x))].map(String).map(x=>x.trim()).filter(Boolean);
  const mood=clamp(body.mood);
  const props={
    'Mood':select(mood?JOURNAL_SCORE_TO_MOOD[mood]:null),'Energy':{number:clamp(body.energy)},'Productivity':{number:clamp(body.productivity)},
    'Social Energy':{number:clamp(body.social_energy)},'Stress':{number:clamp(body.stress)},'Resonance':select(body.resonance||null),
    'Journal':rich(String(body.what_happened||body.journal||'')),'Highlights':rich(String(body.highlights||'')),'Challenges':rich(String(body.challenges||'')),
    'Tags':multiSelect(standard),'Custom Tags':rich(custom.join(', '))
  };
  const updated=await notionRequest(`/pages/${page.id}`,{method:'PATCH',body:{properties:props}},env);
  return {journal:journalPageData(updated),context:publicDailyContext(p)};
}

function avg(values){const a=values.filter(Number.isFinite);return a.length?a.reduce((x,y)=>x+y,0)/a.length:null;}
async function journalAnalytics({personId='',limit=90},env){
  const data=await listJournalEntries({personId,limit},env),entries=data.entries;
  const rated=entries.filter(x=>Number.isFinite(x.energy)||Number.isFinite(x.productivity));
  const observations=[];
  if(rated.length>=5){
    observations.push({type:'completion',text:`You recorded journal data on ${rated.length} of the last ${Math.min(limit,90)} retrieved days.`,n:rated.length});
    for(const metric of ['energy','productivity']){
      const byElement={}; for(const e of rated){if(!e.element||!Number.isFinite(e[metric]))continue;(byElement[e.element]??=[]).push(e[metric]);}
      const groups=Object.entries(byElement).map(([k,v])=>({key:k,n:v.length,mean:avg(v)})).filter(x=>x.n>=3).sort((a,b)=>b.mean-a.mean);
      if(groups.length) observations.push({type:'descriptive_correlation',metric,group:'element',text:`Your highest average ${metric} rating in this sample occurred on ${groups[0].key} days (${groups[0].mean.toFixed(2)}/5 across ${groups[0].n} entries).`,data:groups,disclaimer:'Personal Journal Observation — descriptive correlation only; this does not imply causation or a traditional Saju rule.'});
      const byTG={}; for(const e of rated){if(!e.ten_god||!Number.isFinite(e[metric]))continue;const key=e.ten_god.split(' · ')[0];(byTG[key]??=[]).push(e[metric]);}
      const tg=Object.entries(byTG).map(([k,v])=>({key:k,n:v.length,mean:avg(v)})).filter(x=>x.n>=3).sort((a,b)=>b.mean-a.mean);
      if(tg.length) observations.push({type:'descriptive_correlation',metric,group:'ten_god',text:`Your highest average ${metric} rating in this sample occurred on ${tg[0].key} days (${tg[0].mean.toFixed(2)}/5 across ${tg[0].n} entries).`,data:tg,disclaimer:'Personal Journal Observation — descriptive correlation only; this does not imply causation or a traditional Saju rule.'});
    }
  }
  return {person_id:data.person_id,sample_size:rated.length,enough_data:rated.length>=5,minimum_entries:5,observations};
}

async function resolveLifeEventsTarget(env){if(env.NOTION_LIFE_EVENTS_DS){try{const ds=await notionRequest(`/data_sources/${env.NOTION_LIFE_EVENTS_DS}`,{},env);return ds.id||env.NOTION_LIFE_EVENTS_DS;}catch{}}const ds=await searchDataSourceByTitle('Life Events',env);if(!ds?.id)fail(404,'Life Events database is not shared with Saju Cloudflare Bridge.');return ds.id;}
async function listLifeEvents({personId=''},env){const targets=await resolveTargets(null,env);let pid=String(personId||'');if(!pid){const s=await resolveProfileForContext(targets.people,{},env);pid=s.person.id;}const ds=await resolveLifeEventsTarget(env);const pages=await queryAllDataSourcePages(ds,{filter:{property:'Person',relation:{contains:pid}},sorts:[{property:'Date',direction:'ascending'}]},env);return {person_id:pid,events:pages.map(p=>({id:p.id,url:p.url||null,title:plainTitle(p.properties?.['Event']),date:pageDateStart(p.properties?.['Date']),category:p.properties?.['Category']?.select?.name||'Custom',description:plainRich(p.properties?.['Description']),important:!!p.properties?.['Important']?.checkbox,related_journal_id:p.properties?.['Related Journal']?.relation?.[0]?.id||null}))};}
async function saveLifeEvent(body,env){const targets=await resolveTargets(null,env);const selected=await resolveProfileForContext(targets.people,{personId:body.person_id||'',chartId:body.chart_id||''},env);const ds=await resolveLifeEventsTarget(env);const allowed=new Set(['Education','Career','Relationship','Home','Travel','Family','Achievement','Challenge','Custom']);const category=allowed.has(body.category)?body.category:'Custom';const props={'Event':title(String(body.title||'Life Event')),'Date':dateProp(body.date||null),'Category':select(category),'Description':rich(String(body.description||'')),'Important':checkbox(!!body.important),'Source':select('User Recorded'),'Person':relation([selected.person.id]),'Related Journal':relation(body.related_journal_id?[body.related_journal_id]:[])};let page;if(body.event_id)page=await notionRequest(`/pages/${body.event_id}`,{method:'PATCH',body:{properties:props}},env);else page=await notionRequest('/pages',{method:'POST',body:{parent:{data_source_id:ds},properties:props}},env);return {event:{id:page.id,url:page.url||null,title:plainTitle(page.properties?.['Event']),date:pageDateStart(page.properties?.['Date']),category:page.properties?.['Category']?.select?.name||category}};}

async function buildLifeTimeline({personId='',chartId='',startYear=null,endYear=null},env){const targets=await resolveTargets(null,env);const selected=await resolveProfileForContext(targets.people,{personId,chartId},env);const chart=await notionRequest(`/pages/${selected.chartId}`,{},env);const birth=pageDateStart(selected.person.properties?.['Birth Date'])||pageDateStart(chart.properties?.['Birth Date']);const majors=await loadMajorCycles(targets.luckCycles,selected.chartId,env);const sy=Number(startYear)||Number((birth||'2000').slice(0,4));const ey=Number(endYear)||sy+90;const annual=annualLuckRange({startYear:Math.max(1800,sy),endYear:Math.min(2199,ey),timezone:plainRich(chart.properties?.['Timezone'])||dailyTimezone(env),natal:natalFromChartPage(chart)});const events=(await listLifeEvents({personId:selected.person.id},env)).events;return {person:{id:selected.person.id,name:plainTitle(selected.person.properties?.['Name'])},chart:{id:chart.id},birth_date:birth,current_date:localDateString(Date.now(),dailyTimezone(env)),major_luck:majors.map(summarizeLuckPage),annual,events};}

const ANIMAL_EMOJI={Rat:'🐀',Ox:'🐂',Tiger:'🐅',Rabbit:'🐇',Dragon:'🐉',Snake:'🐍',Horse:'🐎',Goat:'🐐',Monkey:'🐒',Rooster:'🐓',Dog:'🐕',Pig:'🐖'};
const ELEMENT_EMOJI={Wood:'🌳',Fire:'🔥',Earth:'🪨',Metal:'⚙️',Water:'💧'};
function jiaziReference(){return Array.from({length:60},(_,i)=>{const stem=STEMS[i%10],branch=BRANCHES[i%12],technical=`${stem.yin_yang} ${stem.element} ${branch.animal}`,preferred=preferredJiaziName(stem.hanja,branch.animal)||technical;return {index:i,number:i+1,characters:`${stem.hanja}${branch.hanja}`,korean:`${stem.ko}${branch.ko}`,romanisation:`${stem.roman}-${branch.roman}`,preferred_display_name:preferred,jewel_sjpj_name:preferred,technical_english_name:technical,english_name:technical,stem:{...stem,preferred_display_name:preferredStemName(stem.hanja)||`${stem.yin_yang} ${stem.element}`},branch,animal:branch.animal,element:stem.element,yin_yang:stem.yin_yang,traditional_technical:{cycle:'Sexagenary Cycle / 육십갑자',stem_element:stem.element,branch_element:branch.element,animal:branch.animal,polarity:stem.yin_yang},journal_symbolism:{label:'Journal Symbolism — application-created, not traditional doctrine',visual:`${ELEMENT_EMOJI[stem.element]||'✦'} ${ANIMAL_EMOJI[branch.animal]||'✦'}`,description:`A journal identity combining ${stem.yin_yang.toLowerCase()} ${stem.element.toLowerCase()} imagery with the ${branch.animal.toLowerCase()} motif.`}};});}

async function queryAllDataSourcePages(dataSourceId, bodyBase, env, max=1000) {
  const out=[]; let cursor;
  do {
    const body={...bodyBase,page_size:100};
    if(cursor) body.start_cursor=cursor;
    const res=await notionRequest(`/data_sources/${dataSourceId}/query`,{method:'POST',body},env);
    out.push(...(res.results||[]));
    cursor=res.has_more?res.next_cursor:null;
  } while(cursor && out.length<max);
  return out;
}

async function listPeopleAndCharts(env) {
  const t = await resolveTargets(null, env);
  const pages = await queryAllDataSourcePages(t.people,{},env);
  const people = pages.map(page => ({
    id: page.id,
    url: page.url || null,
    name: plainTitle(page.properties?.['Name']),
    preferred_name: plainRich(page.properties?.['Preferred Name']),
    person_type: page.properties?.['Person Type']?.select?.name || '',
    profile_category: page.properties?.['Profile Category']?.select?.name || page.properties?.['Person Type']?.select?.name || 'Other',
    default_profile: !!page.properties?.['Default Profile']?.checkbox,
    sex_basis: page.properties?.['Sex / Luck Basis']?.select?.name || 'Unspecified',
    profile_notes: plainRich(page.properties?.['Profile Notes']),
    birth_date: pageDateStart(page.properties?.['Birth Date']),
    birth_time: plainRich(page.properties?.['Birth Time']),
    birth_time_status: page.properties?.['Birth Time Status']?.select?.name || '',
    birthplace: plainRich(page.properties?.['Birthplace']),
    primary_chart_id: primaryChartId(page),
    chart_ids: (page.properties?.['Charts']?.relation || []).map(x => x.id),
    reading_ids: (page.properties?.['Readings']?.relation || []).map(x => x.id)
  }));
  return { people, count: people.length };
}

async function loadChartApplicationData(chartId, env) {
  const targets = await resolveTargets(null, env);
  const chart = await notionRequest(`/pages/${chartId}`, {}, env);
  const technicalText = plainRich(chart.properties?.['Technical Result JSON']);
  const auditText = plainRich(chart.properties?.['Calculation Audit JSON']);
  const technical = safeJsonParse(technicalText);
  const audit = safeJsonParse(auditText);
  const cyclesRes = await notionRequest(`/data_sources/${targets.luckCycles}/query`, {
    method: 'POST', body: {
      page_size: 100,
      filter: { property: 'Chart', relation: { contains: chartId } },
      sorts: [{ property: 'Start Age', direction: 'ascending' }]
    }
  }, env);
  const natal = natalFromChartPage(chart);
  return {
    chart: chartSummaryForApp(chart),
    natal: Object.fromEntries(Object.entries(natal).map(([k,v]) => [k, v ? v.label : null])),
    technical_result: technical,
    calculation_audit: audit,
    luck_cycles: (cyclesRes.results || []).map(summarizeLuckPage),
    methodology: methodologyStatus(),
            lunar_conversion_ready: true,
    analysis_settings: safeJsonParse(plainRich(chart.properties?.['Analysis Settings'])) || DEFAULT_ANALYSIS_SETTINGS
  };
}

function chartSummaryForApp(chart) {
  const p = chart.properties || {};
  return {
    id: chart.id, url: chart.url || null,
    name: plainTitle(p['Chart Name']), status: p['Status']?.select?.name || '',
    birth_date: pageDateStart(p['Birth Date']), recorded_birth_time: plainRich(p['Recorded Birth Time']),
    corrected_time: plainRich(p['Corrected Time']), birthplace: plainRich(p['Birthplace']), timezone: plainRich(p['Timezone']),
    calendar_type: p['Calendar Type']?.select?.name || 'Gregorian',
    year_pillar: plainRich(p['Year Pillar']), month_pillar: plainRich(p['Month Pillar']), day_pillar: plainRich(p['Day Pillar']), hour_pillar: plainRich(p['Hour Pillar']),
    chart_strength: p['Chart Strength']?.select?.name || 'Methodology Pending', strength_index: p['Strength Index']?.number ?? null, strength_method: plainRich(p['Strength Method']),
    useful_element_method: plainRich(p['Useful Element Method']), symbolic_star_method: plainRich(p['Symbolic Star Method']),
    major_luck_method: plainRich(p['Major Luck Method']), daewoon_start_age: p['Daewoon Start Age']?.number ?? null,
    calculation_version: plainRich(p['Calculation Version']), analysis_version: plainRich(p['Analysis Version']),
    current_revision: p['Current Revision']?.number ?? 1,
    person_ids: (p['Person']?.relation || []).map(x => x.id)
  };
}

async function prepareChartExplorer(params, env) {
  const targets = await resolveTargets(null, env);
  let chartId = String(params.get?.('chart_id') || params.chart_id || '').trim();
  let person = null;
  if (!chartId) {
    const selected = await resolveProfileForContext(targets.people, {}, env);
    person = selected.person;
    chartId = selected.chartId;
  }
  if (!chartId) fail(404, 'No verified chart is available for the explorer.');
  const chart = await notionRequest(`/pages/${chartId}`, {}, env);
  const natal = natalFromChartPage(chart);
  const timezone = String(params.get?.('timezone') || params.timezone || plainRich(chart.properties?.['Timezone']) || dailyTimezone(env)).trim();
  const birthDate = pageDateStart(chart.properties?.['Birth Date']) || (person ? pageDateStart(person.properties?.['Birth Date']) : null);
  if (!birthDate) fail(422, 'The selected chart needs a Birth Date for luck-cycle age matching.');
  const majors = await loadMajorCycles(targets.luckCycles, chartId, env);
  return { targets, chartId, chart, natal, timezone, birthDate, majors };
}

async function loadMajorCycles(dataSourceId, chartId, env) {
  const res = await notionRequest(`/data_sources/${dataSourceId}/query`, {
    method: 'POST', body: {
      page_size: 100,
      filter: { and: [
        { property: 'Cycle Type', select: { equals: 'Major Luck' } },
        { property: 'Chart', relation: { contains: chartId } }
      ] },
      sorts: [{ property: 'Start Age', direction: 'ascending' }]
    }
  }, env);
  return res.results || [];
}

function activeMajorFromList(majors, birthDate, date) {
  const age = decimalAge(birthDate, date);
  return (majors || []).find(p => {
    const start = Number(p.properties?.['Start Age']?.number);
    const end = Number(p.properties?.['End Age']?.number);
    return Number.isFinite(start) && Number.isFinite(end) && age >= start && age < end;
  }) || null;
}

function cyclePillar(page) {
  if (!page) return null;
  const stemText = plainRich(page.properties?.['Stem']);
  const branchText = plainRich(page.properties?.['Branch']);
  const stem = STEMS.find(x => stemText.includes(x.hanja));
  const branch = BRANCHES.find(x => branchText.includes(x.hanja));
  if (!stem || !branch) return null;
  return { label: `${stem.roman}-${branch.roman} (${stem.hanja}${branch.hanja})`, stem: { ...stem }, branch: { ...branch } };
}

async function exploreAnnualLuck(params, env) {
  const c = await prepareChartExplorer(params, env);
  const nowYear = Number(params.get('start') || new Date().getUTCFullYear());
  const start = Number(params.get('start') || nowYear - 5);
  const end = Number(params.get('end') || nowYear + 10);
  const annual = annualLuckRange({ startYear: start, endYear: end, timezone: c.timezone, natal: c.natal });
  for (const item of annual) {
    const major = activeMajorFromList(c.majors, c.birthDate, `${item.gregorian_year}-06-15`);
    item.current_major_luck = major ? summarizeLuckPage(major) : null;
    const mp = cyclePillar(major);
    item.major_luck_interactions = mp ? relationshipEventsForPillar({stem:item.stem,branch:item.branch}, { major: mp }, 'annual-vs-major') : [];
  }
  return { chart: chartSummaryForApp(c.chart), timezone: c.timezone, annual };
}

async function exploreMonthlyLuck(params, env) {
  const c = await prepareChartExplorer(params, env);
  const year = Number(params.get('year') || new Date().getUTCFullYear());
  const monthly = monthlyLuckYear({ year, timezone: c.timezone, natal: c.natal });
  for (const item of monthly) {
    item.start_local = localDateTimeString(Date.parse(item.start_utc), c.timezone);
    item.end_local = localDateTimeString(Date.parse(item.end_utc), c.timezone);
    item.display_timezone = c.timezone;
    const representative = localDateString(Date.parse(item.start_utc) + 2 * 86400000, c.timezone);
    const major = activeMajorFromList(c.majors, c.birthDate, representative);
    item.current_major_luck = major ? summarizeLuckPage(major) : null;
    const mp = cyclePillar(major);
    const thisPillar = { stem:item.stem, branch:item.branch };
    item.major_luck_interactions = mp ? relationshipEventsForPillar(thisPillar, { major: mp }, 'monthly-vs-major') : [];
    const dailyContext = calculateDailyContext({ date: representative, timezone: c.timezone, natal: c.natal });
    item.annual_interactions = relationshipEventsForPillar(thisPillar, { annual: dailyContext.year }, 'monthly-vs-annual');
  }
  return { chart: chartSummaryForApp(c.chart), timezone: c.timezone, year, monthly };
}

async function exploreDailyCalendar(params, env) {
  const c = await prepareChartExplorer(params, env);
  const now = new Date();
  const year = Number(params.get('year') || now.getUTCFullYear());
  const month = Number(params.get('month') || now.getUTCMonth()+1);
  const days = dailyLuckMonth({ year, month, timezone: c.timezone, natal: c.natal });
  const start = `${year}-${String(month).padStart(2,'0')}-01`;
  const lastDay = new Date(Date.UTC(year,month,0)).getUTCDate();
  const end = `${year}-${String(month).padStart(2,'0')}-${String(lastDay).padStart(2,'0')}`;
  const savedRes = await notionRequest(`/data_sources/${c.targets.dailyLuck}/query`, {
    method: 'POST', body: { page_size: 100, filter: { and: [
      { property: 'Date', date: { on_or_after: start } },
      { property: 'Date', date: { on_or_before: end } },
      { property: 'Chart', relation: { contains: c.chart.id } }
    ] } }
  }, env);
  const savedMap = new Map((savedRes.results || []).map(p => [pageDateStart(p.properties?.['Date']), p]));
  for (const item of days) {
    const major = activeMajorFromList(c.majors, c.birthDate, item.date);
    const majorPillar = cyclePillar(major);
    item.current_major_luck = major ? summarizeLuckPage(major) : null;
    item.cycle_interactions = relationshipEventsForPillar(item.day, {
      annual: item.year,
      monthly: item.month,
      ...(majorPillar ? { major: majorPillar } : {})
    }, 'daily-vs-cycles');
    const saved = savedMap.get(item.date);
    item.saved_record = saved ? {
      id: saved.id, url: saved.url || null,
      title: plainTitle(saved.properties?.['Entry']),
      has_ai_reading: !!plainRich(saved.properties?.['Daily Reading'])
    } : null;
  }
  return { chart: chartSummaryForApp(c.chart), timezone: c.timezone, year, month, days };
}


function relevantSourceSnippet(text,concepts=[],maxChars=1400){
  const raw=String(text||'').replace(/\r/g,''); if(!raw)return '';
  const terms=[];
  for(const c of concepts){
    terms.push(c.preferred_display_name,c.technical_english_name,c.english,c.korean,c.hanja,c.romanisation);
    for(const a of c.search_aliases||[])terms.push(typeof a==='string'?a:a?.term);
  }
  const usable=[...new Set(terms.filter(x=>String(x||'').trim()).map(x=>String(x).trim()))].sort((a,b)=>b.length-a.length);
  const low=raw.toLowerCase(); let hit=-1;
  for(const term of usable){const i=low.indexOf(term.toLowerCase());if(i>=0&&(hit<0||i<hit))hit=i;}
  const centre=hit>=0?hit:0; const before=hit>=0?Math.min(520,centre):0; const start=Math.max(0,centre-before);
  let slice=raw.slice(start,start+maxChars).replace(/\n{3,}/g,'\n\n').trim();
  if(start>0)slice='… '+slice; if(start+maxChars<raw.length)slice+=' …';
  return slice;
}

async function buildNatalInterpretationProvenance(technical,concepts,env){
  const probes=[];
  const dm=technical?.day_master||technical?.pillars?.day?.stem;if(dm)probes.push({hanja:dm.hanja,korean:dm.ko||dm.korean,english:dm.roman});
  const day=technical?.pillars?.day; if(day?.stem?.hanja&&day?.branch?.hanja)probes.push({hanja:`${day.stem.hanja}${day.branch.hanja}`});
  for(const key of ['useful_element','favourable_element']){const r=technical?.[key]?.result||technical?.[key];if(r?.element)probes.push({english:r.element});}
  for(const s of technical?.symbolic_stars?.detected||[])probes.push({english:s.star,korean:s.korean,hanja:s.hanja});
  const matched=[];for(const q of probes){const c=findConcept(concepts,q);if(c&&!matched.some(x=>x.id===c.id))matched.push(c);}
  const sourceIds=[...new Set(matched.flatMap(c=>c.source_ids||[]))].slice(0,12);const pages=await fetchPagesByIds(sourceIds,env);
  const sourceBasis=pages.map(researchSourceSummary); const retrieval=[];
  for(const source of sourceBasis.slice(0,6)){
    let notePages=[];
    if(source.research_note_ids?.length) notePages=await fetchPagesByIds(source.research_note_ids.slice(0,2),env);
    if(!notePages.length){
      try{const t=await resolveOptionalTargets(env);notePages=await queryAllDataSourcePages(t.researchNotes,{filter:{property:'Source',relation:{contains:source.id}}},env,2);}catch{}
    }
    for(const notePage of notePages.slice(0,2)){
      const note=researchNoteData(notePage); const excerpt=relevantSourceSnippet(note.source_derived_content,matched,1400); if(!excerpt)continue;
      retrieval.push({source_id:source.source_id||source.id,source_title:source.title,priority:source.priority||null,note_id:note.id,excerpt});
    }
  }
  return {calculated:{day_master:dm?.hanja||null,day_pillar:day?.stem?.hanja&&day?.branch?.hanja?`${day.stem.hanja}${day.branch.hanja}`:null,useful_element:technical?.useful_element?.result||null,favourable_element:technical?.favourable_element?.result||null,unfavourable_element:technical?.unfavourable_element?.result||null,symbolic_stars:technical?.symbolic_stars?.detected||[],twelve_stars:technical?.twelve_stars?.pillars||{}},source_basis:sourceBasis,retrieval_context:retrieval,concepts:matched.map(c=>({id:c.id,concept_id:c.concept_id,preferred_name:c.preferred_display_name||c.english,technical_english:c.technical_english_name||c.english,korean:c.korean,hanja:c.hanja,definition:c.definition,interpretation_notes:c.interpretation_notes}))};
}

async function generateNatalInterpretation(body, env) {
  if (!env.AI) fail(503, 'Workers AI binding is not configured.');
  const chartId = String(body.chart_id || '').trim();
  if (!chartId) fail(400, 'chart_id is required.');
  const app = await loadChartApplicationData(chartId, env);
  const targets = await resolveTargets(null, env);
  const concepts = await loadGlossaryConceptIndex(env);
  const technical = app.technical_result || {
    pillars: app.natal,
    strength: { status: 'methodology_pending' },
    useful_element: { status: 'unavailable', method: METHOD_REGISTRY.useful_element },
    favourable_element: { status: 'unavailable', method: METHOD_REGISTRY.useful_element },
    unfavourable_element: { status: 'unavailable', method: METHOD_REGISTRY.useful_element },
    symbolic_stars: { status: 'unavailable', method: METHOD_REGISTRY.symbolic_stars, detected: [] },
    twelve_stars: { status: 'unavailable', method: METHOD_REGISTRY.twelve_stars, pillars: {} },
    method_registry: METHOD_REGISTRY
  };
  const conceptContext = concepts.slice(0, 120).map(c => ({ preferred_name:c.preferred_display_name||c.english,technical_english:c.technical_english_name||c.english,korean:c.korean,hanja:c.hanja,category:c.category,definition:(c.definition||'').slice(0,500) }));
  const provenance=await buildNatalInterpretationProvenance(technical,concepts,env);
  const system = [
    'You write a technical but accessible natal Saju interpretation from LOCKED calculated data.',
    'Never recalculate, alter, infer, replace, invent or remove a pillar, Ten God, relationship, luck cycle, Chart Strength, Useful/Favourable/Unfavourable Element, Symbolic Star or Twelve Star supplied in locked_chart.',
    'Phase 2 deterministic results are LOCKED INPUT. You may explain them, but you may not change their element, star, detected position, trigger, method, confidence or status.',
    'Any field with status methodology_pending/unavailable or a null result must be described as not calculated or unavailable. Never fill such a gap yourself.',
    'Use traditional language carefully: say “traditionally associated with”, “may emphasise”, or “can be read as”; do not make guaranteed predictions.',
    'Use British/Irish English. Use the preferred accessible site term first when supplied. This includes JewelSJPJ Stem names (for example Black Mist) and JewelSJPJ Ten God names (Self God, Rival God, Creator God, Rebel God, Entrepreneur God, Provider God, Wild Card God, Official God, Mystic God, Nurturer God). Show technical identities such as 癸 · Yin Water or 比肩 · 비견 secondarily where useful. Never replace or alter the locked calculated value.',
    'source_retrieval_context contains short extracts from the user’s private indexed research library. Treat them as interpretive references only: paraphrase them, preserve source disagreements, do not reproduce long passages, and never use them to recalculate or override locked_chart.',
    'Use these headings in order: Core Chart Overview; Day Master; Element Balance; Ten God Pattern; Hidden Stems; Chart Strength; Useful, Favourable and Unfavourable Elements; Key Combinations and Clashes; Symbolic Stars; Twelve Stars; Major Life Themes; Relationships; Work and Career; Money and Resources; Creativity and Expression; Social Behaviour; Major Luck Development; Current Luck Context.'
  ].join(' ');
  const response = await env.AI.run(aiModel(env), {
    messages:[{role:'system',content:system},{role:'user',content:JSON.stringify({locked_chart:technical,glossary_context:conceptContext,source_retrieval_context:provenance.retrieval_context||[],request:'Interpret only supplied calculated values; use source extracts only as attributed interpretive context.'})}],
    temperature:0.3,max_completion_tokens:2600,reasoning_effort:null,
    chat_template_kwargs:{enable_thinking:false,clear_thinking:true}
  });
  const text = extractAiReadingText(response);
  let reading = null;
  if (body.save_to_notion === true) {
    const chart = await notionRequest(`/pages/${chartId}`, {}, env);
    const personId = chart.properties?.['Person']?.relation?.[0]?.id || null;
    reading = await notionRequest('/pages', { method:'POST', body:{ parent:{data_source_id:targets.readings}, properties:{
      'Reading': title(`${plainTitle(chart.properties?.['Chart Name']) || 'Natal Saju'} · Full Interpretation`),
      'Reading Date': dateProp(todayIso()), 'Reading Type': select('Natal'), 'Status': select('Complete'),
      'Main Themes': rich(text), 'Person': relation(personId?[personId]:[]), 'Chart': relation([chartId])
    } } }, env);
  }
  return { chart: app.chart, model: aiModel(env), interpretation: text, provenance, saved_reading: summarizePage(reading), locked_fields_preserved: true };
}


function knownAliasesForSource(sourceId,concepts=[]){
  const out=[];
  if(sourceId==='SRC-JEWEL-001'){
    for(const [hanja,term] of Object.entries(JEWEL_STEM_TERMS)){
      const c=findConcept(concepts,{hanja}); if(!c)continue;
      out.push({term:term.preferred,canonical_english:c.preferred_display_name||c.english,concept_id:c.concept_id,alias_type:'preferred UI label',source_id:sourceId,language:'English'});
    }
    for(const j of jiaziRecords()){
      const c=findConcept(concepts,{concept_id:j.concept_id,hanja:j.characters}); if(!c)continue;
      out.push({term:j.preferred,canonical_english:c.preferred_display_name||c.english,concept_id:c.concept_id,alias_type:'preferred UI label',source_id:sourceId,language:'English'});
    }
  }
  if(sourceId==='SRC-JEWEL-002'){
    for(const j of jiaziRecords()){
      const c=findConcept(concepts,{concept_id:j.concept_id,hanja:j.characters}); if(!c)continue;
      out.push({term:j.preferred,canonical_english:c.preferred_display_name||c.english,concept_id:c.concept_id,alias_type:'source-specific terminology',source_id:sourceId,language:'English'});
    }
  }
  if(sourceId==='SRC-JEWEL-004'){
    for(const [hanja,t] of Object.entries(JEWEL_TEN_GOD_TERMS)){
      const c=findConcept(concepts,{hanja,concept_id:t.concept_id,english:t.technical}); if(!c)continue;
      const canonical=c.preferred_display_name||t.preferred;
      out.push({term:t.preferred,canonical_english:canonical,concept_id:c.concept_id,alias_type:'preferred UI label',source_id:sourceId,language:'English'});
      out.push({term:t.jewel_romanisation,canonical_english:canonical,concept_id:c.concept_id,alias_type:'romanisation',source_id:sourceId,language:'Korean romanisation'});
    }
  }
  return out;
}

function deterministicSourceAnalysis(source,concepts,sourceText=''){
  const aliases=knownAliasesForSource(source.source_id,concepts);
  const conceptMatches=[...new Set(aliases.map(a=>a.canonical_english).filter(Boolean))];
  if(source.source_id==='SRC-JEWEL-001') return {english_summary:'JewelSJPJ educational guide to the sixty SJPJ Types, including accessible Stem names, combined Stem–animal Type names and personality-focused interpretations.',methodology:'Modern Saju educational/practitioner interpretation. Use for accessible terminology and interpretive reference, never to override deterministic chart calculations.',language:'English',concept_matches:conceptMatches,aliases,possible_conflicts:[],needs_review:false};
  if(source.source_id==='SRC-JEWEL-002') return {english_summary:'Supporting JewelSJPJ reference pairing SJPJ Types with celebrity examples and showing the accessible Stem and animal naming system.',methodology:'Supporting educational examples only; celebrity examples are not calculation rules.',language:'English',concept_matches:conceptMatches,aliases,possible_conflicts:[],needs_review:false};
  if(source.source_id==='SRC-JEWEL-003') return {english_summary:'JewelSJPJ course captures from The Why Part 1 covering where Ten Gods are read in the chart, the Five Element Help and Hurt relationships, and selected special-star animal groupings.',methodology:'Modern educational/practitioner teaching material. Preserve as source context and terminology; do not use the captures to override the deterministic calculation engine.',language:'English',concept_matches:conceptMatches,aliases,possible_conflicts:[],needs_review:false};
  if(source.source_id==='SRC-JEWEL-004') return {english_summary:'JewelSJPJ course captures from The Why Part 2 defining the preferred accessible names for the ten Gods and grouping them into Me, Output, Wealth, Authority and Input categories.',methodology:'CORE terminology source for beginner-facing Ten God names. Technical English, Hangul and Hanja remain attached as identities/aliases; calculations remain unchanged.',language:'English',concept_matches:conceptMatches,aliases,possible_conflicts:[],needs_review:false};
  return {english_summary:`Imported source “${source.title}”. Review the extracted source text before relying on interpretive claims.`,methodology:'Source stored for research/provenance. No deterministic calculation rule is inferred from this source.',language:'English',concept_matches:[],aliases:[],possible_conflicts:[],needs_review:true};
}

async function knowledgePackStatus(env){
  const core=await resolveTargets(null,env); const concepts=await loadConceptIndex(core.concepts,env);
  const jiaziSet=new Set(concepts.map(c=>String(c.hanja||'')).filter(x=>x.length===2));
  let imported=new Map();
  try{
    const t=await resolveOptionalTargets(env); const pages=await queryAllDataSourcePages(t.researchSources,{},env,500);
    for(const p of pages){const summary=researchSourceSummary(p), meta=summary.source_identity;if(meta?.source_id)imported.set(meta.source_id,summary);}
  }catch{}
  const sources=sourceManifestForUi().map(src=>({
    ...src,
    ingestion_status:src.parent_only?'Collection':(imported.get(src.source_id)?.ingestion_status||'Not imported'),
    notion_source_id:imported.get(src.source_id)?.id||null,
    aliases_indexed:imported.get(src.source_id)?.source_identity?.aliases?.length||0,
    requires_manual_review:imported.get(src.source_id)?.confidence==='Needs Review'
  }));
  const urlCounts=new Map(); for(const src of INITIAL_SOURCE_MANIFEST){if(src.url)urlCounts.set(src.url,(urlCounts.get(src.url)||0)+1);}
  const duplicateUrls=[...urlCounts.entries()].filter(([,count])=>count>1).map(([url,count])=>({url,count}));
  const docs=sources.filter(x=>!x.parent_only);
  return {sources,jiazi_concepts_present:jiaziRecords().filter(j=>jiaziSet.has(j.characters)).length,jiazi_concepts_required:60,duplicate_urls:duplicateUrls,source_counts:{total:sources.length,documents:docs.length,imported:docs.filter(x=>x.notion_source_id).length,ready:docs.filter(x=>x.ingestion_status==='Ready').length,needs_review:docs.filter(x=>x.ingestion_status==='Needs Review').length,not_imported:docs.filter(x=>!x.notion_source_id).length}};
}

async function ensureKnowledgeConcepts({offset=0,batch_size=8}={},env){
  const core=await resolveTargets(null,env); const concepts=await loadConceptIndex(core.concepts,env); const all=jiaziRecords();
  const start=Math.max(0,Math.min(60,Number(offset)||0)); const size=Math.max(1,Math.min(10,Number(batch_size)||8)); const end=Math.min(60,start+size);
  const existing=new Map(concepts.map(c=>[String(c.hanja||''),c])); const created=[],skipped=[];
  for(const j of all.slice(start,end)){
    if(existing.has(j.characters)){skipped.push({concept_id:j.concept_id,hanja:j.characters,name:j.preferred,reason:'already exists'});continue;}
    const page=await notionRequest('/pages',{method:'POST',body:{parent:{data_source_id:core.concepts},properties:{
      'English Name':title(j.preferred),'Korean':rich(j.korean),'Hanja':rich(j.characters),'Category':select('60 Jiazi'),'Element Name':select(j.stem.technical.split(' ')[1]),'Yin Yang':select(j.stem.technical.split(' ')[0]),'Animal':rich(j.branch.animal),'Romanisation':rich(j.romanisation),
      'Definition':rich(`One of the sixty Stem–Branch combinations. Preferred beginner-facing site term: ${j.preferred}. Technical identity: ${j.technical}.`),
      'Interpretation Notes':rich('Interpretive source perspectives are stored in the Research Library. This reference record does not alter deterministic calculations.')
    }}},env);
    created.push({id:page.id,concept_id:j.concept_id,hanja:j.characters,name:j.preferred}); existing.set(j.characters,{id:page.id});
  }
  return {version:KNOWLEDGE_PACK_VERSION,offset:start,next_offset:end<60?end:null,complete:end>=60,created,skipped,processed:end-start};
}

async function importKnowledgeSource(sourceId,env){
  const source=sourceById(sourceId); if(!source) fail(404,'Unknown initial knowledge source ID.');
  if(source.parent_only) return {source_id:source.source_id,title:source.title,status:'collection_parent',ingestion_status:'Collection',message:'This record is a parent collection; its child articles are imported individually.'};
  const core=await resolveTargets(null,env); const concepts=mergeGlossaryConcepts(await loadConceptIndex(core.concepts,env));
  let sourceText='', resolvedUrl=source.url||'', resolvedTitle=source.title, author=source.creator||'', language='English', indexedDocuments=1, collectionWarnings=[];
  try{
    if(source.embedded_key==='jewel_guide'){sourceText=JEWEL_GUIDE_SOURCE_TEXT;indexedDocuments=129;}
    else if(source.embedded_key==='jewel_celebrities'){sourceText=JEWEL_CELEBRITIES_SOURCE_TEXT;indexedDocuments=12;}
    else if(source.embedded_key==='jewel_why_part1'){sourceText=JEWEL_WHY_PART1_SOURCE_TEXT;indexedDocuments=4;}
    else if(source.embedded_key==='jewel_why_part2'){sourceText=JEWEL_WHY_PART2_SOURCE_TEXT;indexedDocuments=5;}
    else if(source.source_id==='SRC-QIORA-001'){
      const collection=await fetchQioraCollection(source.url);sourceText=collection.extracted_text;resolvedUrl=collection.canonical_url||source.url;resolvedTitle=collection.title||source.title;author=collection.author||author;language=collection.language_hint||language;indexedDocuments=collection.documents_count||1;collectionWarnings=collection.failed_urls||[];
    }
    else if(source.url){const fetched=await fetchResearchUrl(source.url);sourceText=fetched.extracted_text||'';resolvedUrl=fetched.canonical_url||fetched.url||source.url;resolvedTitle=fetched.title||source.title;author=fetched.author||author;language=fetched.language_hint||language;}
  }catch(error){
    const retryable=!!error?.retryable||[429,500,502,503,504].includes(Number(error?.upstream_status));
    return {source_id:source.source_id,title:source.title,status:retryable?'temporary_unavailable':'failed',ingestion_status:retryable?'Temporarily Unavailable':'Failed',error:error?.message||String(error),upstream_status:Number(error?.upstream_status)||null,retry_after_seconds:error?.retry_after_seconds==null?null:Number(error.retry_after_seconds),source_url:error?.source_url||source.url||null,retryable,requires_manual_review:true};
  }
  if(!sourceText.trim()) return {source_id:source.source_id,title:resolvedTitle,status:'failed',ingestion_status:'Failed',error:'No readable source text could be retrieved.',requires_manual_review:true};
  let analysis=deterministicSourceAnalysis(source,concepts,sourceText);
  if(collectionWarnings.length) analysis={...analysis,needs_review:true,possible_conflicts:[...(analysis.possible_conflicts||[]),`${collectionWarnings.length} linked Qiora page(s) could not be retrieved and require manual review.`]};
  if(env.AI){
    try{
      const ai=await analyzeResearchSource({title:resolvedTitle,url:resolvedUrl,source_type:source.source_type,text:sourceText,source_id:source.source_id},env);
      analysis={...analysis,...ai.analysis,concept_matches:[...new Set([...(analysis.concept_matches||[]),...(ai.analysis?.concept_matches||[])])],aliases:[...new Map([...(analysis.aliases||[]),...(ai.analysis?.aliases||[])].map(a=>[`${a.concept_id}|${normaliseAliasKey(a.term)}`,a])).values()]};
    }catch(error){analysis={...analysis,needs_review:true,possible_conflicts:[...(analysis.possible_conflicts||[]),`AI indexing unavailable: ${error?.message||String(error)}`]};}
  }
  const saved=await saveResearchSource({source_id:source.source_id,parent_source_id:source.parent_source_id||null,priority:source.priority,priority_label:source.priority_label,title:resolvedTitle,source_type:source.source_type==='Website Collection'?'Website':source.source_type,url:resolvedUrl,author,language,publication:source.creator||'',analysis,source_text:sourceText,confidence:analysis.needs_review?'Needs Review':'Useful'},env);
  const paragraphCount=sourceText.split(/\n\s*\n/).map(x=>x.trim()).filter(Boolean).length;
  return {source_id:source.source_id,title:resolvedTitle,status:'imported',ingestion_status:analysis.needs_review?'Needs Review':'Ready',notion_source_id:saved.source?.id||null,indexed_documents:indexedDocuments,indexed_characters:sourceText.length,indexed_passages:paragraphCount,concepts_detected:analysis.concept_matches?.length||0,aliases_created:analysis.aliases?.length||0,failed_linked_urls:collectionWarnings,requires_manual_review:!!analysis.needs_review||collectionWarnings.length>0,duplicate_url:false,source_provenance_preserved:true};
}

async function resolveOptionalTargets(env) {
  const out = {};
  const missing = [];
  for (const [key,titleName] of Object.entries(OPTIONAL_TITLES)) {
    const ds = await searchDataSourceByTitle(titleName, env);
    if (ds?.id) out[key] = ds.id; else missing.push(titleName);
  }
  if (missing.length) fail(404, `Research integration cannot see: ${missing.join(', ')}. Share the original databases with “Saju Cloudflare Bridge”.`);
  return out;
}

async function fetchResearchUrl(rawUrl) {
  const url = safeHttpUrl(rawUrl);
  const resp = await fetch(url, { headers:{'User-Agent':'My-Saju-Journal-Research-Inbox/1.7.4.1'} });
  if (!resp.ok) {
    const retryAfterRaw=String(resp.headers.get('Retry-After')||'').trim();
    let retryAfterSeconds=null;
    if(retryAfterRaw){
      const numeric=Number(retryAfterRaw);
      if(Number.isFinite(numeric)&&numeric>=0)retryAfterSeconds=Math.ceil(numeric);
      else{const when=Date.parse(retryAfterRaw);if(Number.isFinite(when))retryAfterSeconds=Math.max(0,Math.ceil((when-Date.now())/1000));}
    }
    const retryable=[429,500,502,503,504].includes(resp.status);
    const e=new Error(`Website extraction failed with HTTP ${resp.status}. ${retryable?'The source appears temporarily unavailable or rate-limited.':'The page may block automated access or require login.'}`);
    e.status=422;
    e.upstream_status=resp.status;
    e.retry_after_seconds=retryAfterSeconds;
    e.retryable=retryable;
    e.source_url=url;
    throw e;
  }
  const contentType = resp.headers.get('content-type') || '';
  if (!contentType.includes('text/html') && !contentType.includes('text/plain')) fail(422, `This URL returned ${contentType || 'an unsupported content type'}. Use the PDF or paste-text workflow instead.`);
  const html = await resp.text();
  const pick = re => decodeHtml(html.match(re)?.[1] || '').trim();
  const titleText = pick(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const lang = pick(/<html[^>]*\blang=["']?([^"'\s>]+)/i);
  const author = pick(/<meta[^>]+(?:name|property)=["'](?:author|article:author)["'][^>]+content=["']([^"']+)/i) || pick(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:name|property)=["'](?:author|article:author)["']/i);
  const description = pick(/<meta[^>]+(?:name|property)=["'](?:description|og:description)["'][^>]+content=["']([^"']+)/i) || pick(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:name|property)=["'](?:description|og:description)["']/i);
  const canonical = pick(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)/i) || pick(/<link[^>]+href=["']([^"']+)["'][^>]+rel=["']canonical["']/i) || url;
  const headings = [...html.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi)].slice(0,80).map(m=>decodeHtml(stripHtml(m[1])).trim()).filter(Boolean);
  const body = decodeHtml(stripHtml(html)).replace(/\n{3,}/g,'\n\n').trim().slice(0,60000);
  return { url, canonical_url:safeHttpUrl(canonical), title:titleText || new URL(url).hostname, author, description, headings, language_hint:lang, extracted_text:body, source_type:'Website', text_available:!!body };
}

async function fetchQioraCollection(rootUrl){
  const root=await fetchResearchUrl(rootUrl); const origin=new URL(rootUrl).origin; const urls=new Set([rootUrl]); const failed=[];
  try{
    const resp=await fetch(rootUrl,{headers:{'User-Agent':'My-Saju-Journal-Knowledge-Pack/1.7.4'}});
    if(resp.ok){const html=await resp.text();for(const m of html.matchAll(/href=["']([^"'#]+)["']/gi)){try{const u=new URL(m[1],rootUrl);if(u.origin===origin&&(/\/learn\//.test(u.pathname)||/\/reference\//.test(u.pathname)))urls.add(u.toString());}catch{}}}
  }catch{}
  const documents=[root];
  for(const u of [...urls].filter(x=>x!==rootUrl).slice(0,16)){
    try{documents.push(await fetchResearchUrl(u));}catch(error){failed.push({url:u,error:error?.message||String(error)});}
  }
  const text=documents.map((d,i)=>`[Document ${i+1}]\nTitle: ${d.title||''}\nURL: ${d.canonical_url||d.url||''}\n\n${d.extracted_text||''}`).join('\n\n==============================\n\n');
  return {title:root.title||'Qiora Learn',author:root.author||'Qiora',canonical_url:root.canonical_url||root.url,language_hint:root.language_hint||'English',documents_count:documents.length,failed_urls:failed,extracted_text:text};
}

async function fetchYouTubeMetadata(rawUrl) {
  const url = safeHttpUrl(rawUrl);
  const parsed = new URL(url);
  if (!/youtube\.com|youtu\.be/i.test(parsed.hostname)) fail(400, 'Enter a YouTube URL.');
  let videoId = '';
  if (/youtu\.be$/i.test(parsed.hostname)) videoId = parsed.pathname.split('/').filter(Boolean)[0] || '';
  else if (/youtube\.com$/i.test(parsed.hostname) || /www\.youtube\.com$/i.test(parsed.hostname) || /m\.youtube\.com$/i.test(parsed.hostname)) {
    if (parsed.pathname === '/watch') videoId = parsed.searchParams.get('v') || '';
    else {
      const parts = parsed.pathname.split('/').filter(Boolean);
      if (['shorts','embed','live'].includes(parts[0])) videoId = parts[1] || '';
    }
  }
  const endpoint = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
  const resp = await fetch(endpoint);
  if (!resp.ok) fail(422, 'YouTube metadata could not be retrieved for this URL.');
  const j = await resp.json();
  return { source_type:'Video', url, video_id:videoId, title:j.title || '', channel:j.author_name || '', author_url:j.author_url || '', thumbnail:j.thumbnail_url || '', provider:j.provider_name || 'YouTube', transcript_status:'not_fetched', transcript_note:'Paste or upload an authorised transcript (.txt/.srt/.vtt). The app does not scrape third-party captions.' };
}

async function analyzeResearchSource(body, env) {
  if (!env.AI) fail(503, 'Workers AI binding is not configured.');
  const targets = await resolveTargets(null, env);
  const concepts = mergeGlossaryConcepts(await loadConceptIndex(targets.concepts, env));
  const allowed = concepts.map(c => c.preferred_display_name||c.english).filter(Boolean);
  const sourceText = String(body.text || body.extracted_text || '').trim();
  if (!sourceText && !body.title) fail(400, 'Provide source text or a title/metadata record to analyse.');
  const system = [
    'Analyse a Saju research source without treating it as deterministic calculation truth.',
    'Return plain text only using exactly these headings: English Summary; Methodology; Language; Concept Matches; Terminology Aliases; Possible Conflicts; Needs Review.',
    'For Concept Matches, choose only exact preferred English concept names from the supplied allowed list, separated by |. Do not invent concept names.',
    'For Terminology Aliases, use one line per unambiguous same-concept name in the form: alias => canonical English | alias_type.',
    'alias_type must be one of: preferred UI label; technical term; Korean name; Hanja; romanisation; alternative translation; source-specific terminology; accessible label; metaphor; legacy terminology; search-only alias.',
    'A metaphor must be labelled metaphor and must never be presented as a formal translation. Do not merge genuinely different concepts.',
    'Clearly distinguish what the source says from interpretation. If evidence is thin or metadata-only, set Needs Review to Yes.'
  ].join(' ');
  const response = await env.AI.run(aiModel(env), {
    messages:[{role:'system',content:system},{role:'user',content:JSON.stringify({metadata:{title:body.title||'',url:body.url||'',source_type:body.source_type||'Other'},source_text:sourceText.slice(0,42000),allowed_concepts:allowed})}],
    temperature:0.2,max_completion_tokens:1500,reasoning_effort:null,chat_template_kwargs:{enable_thinking:false,clear_thinking:true}
  });
  const text = extractAiReadingText(response);
  const parsed = parseResearchAnalysis(text, allowed, concepts, body.source_id||'');
  return { model:aiModel(env), raw_analysis:text, analysis:parsed, source_text:sourceText.slice(0,60000) };
}

async function uploadResearchFile(request, env) {
  const form = await request.formData();
  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') fail(400, 'A file is required.');
  const size = Number(file.size || 0);
  if (!size) fail(400, 'The selected file is empty.');
  if (size > 20 * 1024 * 1024) fail(413, 'This direct Notion upload workflow supports files up to 20 MB.');
  const filename = String(file.name || 'research-file');
  const contentType = String(file.type || 'application/octet-stream');
  const created = await notionRequest('/file_uploads', { method:'POST', body:{ mode:'single_part', filename, content_type:contentType } }, env);
  const fd = new FormData();
  fd.append('file', file, filename);
  const resp = await fetch(`${NOTION_API}/file_uploads/${created.id}/send`, {
    method:'POST', body:fd,
    headers:{ 'Authorization':`Bearer ${env.NOTION_TOKEN}`, 'Notion-Version':NOTION_VERSION }
  });
  const text = await resp.text();
  let sent={}; try{sent=text?JSON.parse(text):{};}catch{sent={raw:text};}
  if(!resp.ok) fail(resp.status, sent?.message || `Notion file upload failed with HTTP ${resp.status}.`);
  return { file_upload_id: created.id, filename, content_type:contentType, size, status:sent.status || 'uploaded' };
}


async function findOrCreateTeacherAuthor(name,targets,env){
  const wanted=String(name||'').trim();if(!wanted)return null;
  const pages=await queryAllDataSourcePages(targets.teachers,{},env,500);
  const norm=v=>String(v||'').trim().toLowerCase();
  const found=pages.find(p=>norm(plainTitle(p.properties?.['Name']))===norm(wanted));
  if(found)return found.id;
  const page=await notionRequest('/pages',{method:'POST',body:{parent:{data_source_id:targets.teachers},properties:{'Name':title(wanted),'Type':select('Author'),'Automatic Reading Authority':checkbox(false)}}},env);
  return page.id;
}

async function saveResearchSource(body, env) {
  const t = await resolveOptionalTargets(env);
  const core = await resolveTargets(null, env);
  const concepts = mergeGlossaryConcepts(await loadConceptIndex(core.concepts, env));
  const analysis = body.analysis || {};
  const authorId=await findOrCreateTeacherAuthor(body.author,t,env);
  const conceptIds = [...new Set((analysis.concept_matches || []).map(name => findConcept(concepts,{english:name})).filter(c=>c?.notion_id).map(x=>x.notion_id))];
  const sourceIdentity=body.source_id?{
    source_id:String(body.source_id),parent_source_id:body.parent_source_id||null,priority:Number(body.priority||0)||null,priority_label:String(body.priority_label||''),aliases:(analysis.aliases||[]).map(a=>({...a,source_id:String(body.source_id)}))
  }:null;
  const processingNotes=sourceIdentity?sourceMetaText(sourceIdentity,analysis.possible_conflicts||[]):(analysis.possible_conflicts||[]).join(' | ');
  const props={
    'Source': title(body.title || body.source || 'Research Source'),
    'Source Type': select(body.source_type || 'Other'),
    'URL': urlProp(body.url || null),
    'Language': multiSelect(normaliseLanguages(analysis.language || body.language || 'Other')),
    'Publication': rich(body.publication || ''),
    'Publication Date': dateProp(body.publication_date || null),
    'Pages': rich(body.pages || ''),
    'Author or Teacher': relation(authorId?[authorId]:[]),
    'Methodology': rich(analysis.methodology || ''),
    'English Summary': rich(analysis.english_summary || ''),
    'Concepts': relation(conceptIds),
    'Confidence': select(analysis.needs_review ? 'Needs Review' : (body.confidence || 'Useful')),
    'Contradiction Flag': checkbox((analysis.possible_conflicts || []).length > 0),
    'Original Material': fileUploadsProp(body.file_upload_id, body.file_name || body.title || 'Original material'),
    'Ingestion Status': select(analysis.needs_review ? 'Needs Review' : 'Ready'),
    'Processing Notes': rich(processingNotes),
    'Source Text Available': checkbox(!!String(body.source_text || '').trim())
  };
  let source=null, sourceExisted=false;
  if(sourceIdentity?.source_id){
    const pages=await queryAllDataSourcePages(t.researchSources,{},env,500);
    source=pages.find(p=>parseSourceMeta(plainRich(p.properties?.['Processing Notes']))?.source_id===sourceIdentity.source_id)||null; sourceExisted=!!source;
  }
  if(source) source=await notionRequest(`/pages/${source.id}`,{method:'PATCH',body:{properties:props}},env);
  else source=await notionRequest('/pages', { method:'POST', body:{ parent:{data_source_id:t.researchSources}, properties:props } }, env);

  const noteProps={
    'Note': title(`${body.title || 'Research Source'} · Source Note`),
    'Note Type': select('Source Note'), 'Source': relation([source.id]), 'Concepts': relation(conceptIds),
    'Source-derived Content': rich(String(body.source_text || '')),
    'AI Summary': rich(analysis.english_summary || ''), 'My Interpretation': rich(''),
    'Questions': rich((analysis.possible_conflicts || []).length ? 'Review the flagged source disagreement(s) before using this methodology in calculation.' : '')
  };
  let note=null;
  if(body.source_id){
    const notes=await queryAllDataSourcePages(t.researchNotes,{filter:{property:'Source',relation:{contains:source.id}}},env,20).catch(()=>[]);
    note=notes.find(p=>String(plainTitle(p.properties?.['Note'])||'').includes('Source Note'))||notes[0]||null;
  }
  if(note) note=await notionRequest(`/pages/${note.id}`,{method:'PATCH',body:{properties:noteProps}},env);
  else note=await notionRequest('/pages', { method:'POST', body:{ parent:{data_source_id:t.researchNotes}, properties:noteProps } }, env);
  return { source:summarizePage(source), research_note:summarizePage(note), concept_matches:analysis.concept_matches || [], aliases:analysis.aliases||[], source_identity:sourceIdentity, updated_existing:sourceExisted };
}

function parseResearchAnalysis(text, allowed, conceptIndex=[], sourceId='') {
  const headings=['English Summary','Methodology','Language','Concept Matches','Terminology Aliases','Possible Conflicts','Needs Review'];
  const map={}; let current=null;
  for (const line of String(text||'').replace(/\r/g,'').split('\n')) {
    const clean=line.trim().replace(/^#{1,6}\s*/,'').replace(/:$/,'');
    const hit=headings.find(h=>h.toLowerCase()===clean.toLowerCase());
    if (hit) { current=hit; map[current]=[]; continue; }
    if (current) map[current].push(line);
  }
  const val=h=>(map[h]||[]).join('\n').trim();
  const allowedSet=new Map(allowed.map(x=>[normaliseAliasKey(x),x]));
  const conceptMatches=val('Concept Matches').split(/[|,\n]/).map(x=>x.trim()).filter(Boolean).map(x=>allowedSet.get(normaliseAliasKey(x))).filter(Boolean);
  const aliasTypes=new Set(['preferred UI label','technical term','Korean name','Hanja','romanisation','alternative translation','source-specific terminology','accessible label','metaphor','legacy terminology','search-only alias']);
  const aliases=[];
  for(const raw of val('Terminology Aliases').split('\n')){
    const line=raw.replace(/^[-•]\s*/,'').trim(); if(!line||!/=>/.test(line))continue;
    const [left,right0]=line.split(/=>/,2), parts=String(right0||'').split('|');
    const term=left.trim(), canonical=parts[0]?.trim(), aliasType=parts[1]?.trim();
    const canonicalName=allowedSet.get(normaliseAliasKey(canonical)); const c=canonicalName?findConcept(conceptIndex,{english:canonicalName}):null;
    if(term&&c&&aliasTypes.has(aliasType)) aliases.push({term,canonical_english:canonicalName,concept_id:c.concept_id,alias_type:aliasType,source_id:sourceId||null,language:/[가-힣]/.test(term)?'Korean':/[一-龯]/.test(term)?'Hanja':'English'});
  }
  const conflicts=val('Possible Conflicts').split(/\n|\|/).map(x=>x.replace(/^[-•]\s*/,'').trim()).filter(x=>x && !/^none$/i.test(x));
  return { english_summary:val('English Summary'), methodology:val('Methodology'), language:val('Language')||'Other', concept_matches:[...new Set(conceptMatches)], aliases:[...new Map(aliases.map(a=>[`${a.concept_id}|${normaliseAliasKey(a.term)}`,a])).values()], possible_conflicts:conflicts, needs_review:/^(yes|true)/i.test(val('Needs Review')) };
}

function stripHtml(html) {
  return String(html||'').replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<noscript[\s\S]*?<\/noscript>/gi,' ').replace(/<br\s*\/?>/gi,'\n').replace(/<\/(p|div|section|article|h[1-6]|li)>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/[ \t]+/g,' ');
}
function decodeHtml(s){return String(s||'').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'"').replace(/&#39;/gi,"'");}
function safeHttpUrl(value){let u;try{u=new URL(String(value||''));}catch{fail(400,'Enter a valid URL.');}if(!['http:','https:'].includes(u.protocol))fail(400,'Only http/https URLs are supported.');return u.toString();}
function safeJsonParse(s){try{return s?JSON.parse(s):null;}catch{return null;}}
function urlProp(value){return { url:value?String(value):null };}
function multiSelect(values){return { multi_select:(values||[]).filter(Boolean).map(name=>({name})) };}
function normaliseLanguages(value){const allowed=['English','Korean','Chinese','Japanese','Other'];const s=Array.isArray(value)?value.join(' '):String(value||'');const found=allowed.filter(x=>new RegExp(x,'i').test(s));return found.length?found:['Other'];}


async function compareSavedProfiles({personA,personB},env){
  if(!personA||!personB) fail(400,'Choose Person A and Person B.');
  if(personA===personB) fail(400,'Choose two different saved profiles.');
  const profiles=await listPeopleAndCharts(env);
  const a=profiles.people.find(x=>x.id===personA),b=profiles.people.find(x=>x.id===personB);
  if(!a||!b) fail(404,'One of the selected saved profiles could not be found.');
  if(!a.primary_chart_id||!b.primary_chart_id) fail(422,'Both profiles need a saved Primary Chart before comparison.');
  const [appA,appB]=await Promise.all([loadChartApplicationData(a.primary_chart_id,env),loadChartApplicationData(b.primary_chart_id,env)]);
  const technicalA=technicalForComparison(appA),technicalB=technicalForComparison(appB);
  return {comparison:compareCharts({personA:profileCompareSummary(a),personB:profileCompareSummary(b),technicalA,technicalB})};
}

function profileCompareSummary(p){return{id:p.id,name:p.preferred_name||p.name,category:p.profile_category||p.person_type||'Other',chart_id:p.primary_chart_id};}
function technicalForComparison(app){
  if(app?.technical_result?.pillars) return app.technical_result;
  const pillars={};
  for(const k of ['year','month','day','hour']){const q=parsePillarText(app?.natal?.[k]);if(q)pillars[k]=q;}
  return {pillars,day_master:pillars.day?.stem||null,elements:null,relationships:null};
}

async function listPersonalNotes({subjectType='',subjectKey=''},env){
  const t=await resolveOptionalTargets(env); const filters=[];
  if(subjectType) filters.push({property:'Subject Type',select:{equals:subjectType}});
  if(subjectKey) filters.push({property:'Subject Key',rich_text:{equals:subjectKey}});
  const body={sorts:[{property:'Created',direction:'descending'}]};
  if(filters.length===1) body.filter=filters[0]; else if(filters.length>1) body.filter={and:filters};
  const pages=await queryAllDataSourcePages(t.researchNotes,body,env,250);
  return {notes:pages.filter(p=>!(p.properties?.['Source']?.relation||[]).length).map(personalNoteData)};
}
function personalNoteData(p){return{id:p.id,url:p.url||null,title:plainTitle(p.properties?.['Note']),subject_type:p.properties?.['Subject Type']?.select?.name||'',subject_key:plainRich(p.properties?.['Subject Key']),text:plainRich(p.properties?.['My Interpretation']),questions:plainRich(p.properties?.['Questions']),created:p.created_time||null,concept_ids:(p.properties?.['Concepts']?.relation||[]).map(x=>x.id),label:'My Notes'};}
async function savePersonalNote(body,env){
  const t=await resolveOptionalTargets(env); const allowed=new Set(['Concept','60 Jiazi','Chart','Relationship']);
  const subjectType=allowed.has(body.subject_type)?body.subject_type:'Concept'; const subjectKey=String(body.subject_key||'').trim();
  if(!subjectKey) fail(400,'subject_key is required for a personal note.');
  const props={
    'Note':title(String(body.title||`My Notes · ${subjectKey}`)),
    'Note Type':select('Interpretation'),'Source':relation([]),'Concepts':relation(body.concept_id?[String(body.concept_id)]:[]),
    'Source-derived Content':rich(''),'AI Summary':rich(''),'My Interpretation':rich(String(body.text||'')),'Questions':rich(String(body.questions||'')),
    'Subject Type':select(subjectType),'Subject Key':rich(subjectKey)
  };
  let page;if(body.note_id)page=await notionRequest(`/pages/${body.note_id}`,{method:'PATCH',body:{properties:props}},env);else page=await notionRequest('/pages',{method:'POST',body:{parent:{data_source_id:t.researchNotes},properties:props}},env);
  return {note:personalNoteData(page),provenance_type:'personal_observation'};
}

async function loadConceptLearningEntry({id,personId=''},env){
  const concepts=await loadGlossaryConceptIndex(env);
  const concept=findConcept(concepts,{concept_id:id,english:id,hanja:id,korean:id,romanisation:id})||concepts.find(x=>x.id===id||x.notion_id===id);
  if(!concept) fail(404,'Saju concept not found.');
  const profiles=await listPeopleAndCharts(env); const chartOccurrences=[];
  for(const p of profiles.people.filter(x=>x.primary_chart_id).slice(0,50)){
    try{const app=await loadChartApplicationData(p.primary_chart_id,env);if(conceptPresentInTechnical(app.technical_result||technicalForComparison(app),concept))chartOccurrences.push({person_id:p.id,person_name:p.preferred_name||p.name,chart_id:p.primary_chart_id});}catch{}
  }
  let selectedPerson=personId?profiles.people.find(x=>x.id===personId):profiles.people.find(x=>x.default_profile)||profiles.people[0]||null;
  let journalDays=[];
  if(selectedPerson){try{const j=await listJournalEntries({personId:selectedPerson.id,limit:120},env);journalDays=j.entries.filter(e=>journalMatchesConcept(e,concept)).slice(0,20);}catch{}}
  const t=await resolveOptionalTargets(env); const sourcePages=await queryAllDataSourcePages(t.researchSources,{},env,500); const allSources=sourcePages.map(researchSourceSummary);
  const sourceMap=allSources.filter(src=>(concept.notion_id&&src.concept_ids.includes(concept.notion_id))||(src.source_identity?.aliases||[]).some(a=>a.concept_id===concept.concept_id));
  const linkedNoteIds=[...new Set([...(concept.research_note_ids||[]),...sourceMap.flatMap(x=>x.research_note_ids||[])])];
  const linkedNotes=await fetchPagesByIds(linkedNoteIds,env);
  const stableKey=concept.concept_id||concept.id; const personalPrimary=await listPersonalNotes({subjectType:'Concept',subjectKey:stableKey},env);
  let personal=personalPrimary.notes;
  if(concept.notion_id&&concept.notion_id!==stableKey){const legacy=await listPersonalNotes({subjectType:'Concept',subjectKey:concept.notion_id},env);personal=[...personal,...legacy.notes.filter(n=>!personal.some(x=>x.id===n.id))];}
  return {
    concept:{...concept,id:concept.notion_id||concept.concept_id,stable_id:stableKey,notion_id:concept.notion_id||null,element:concept.element||null,yin_yang:concept.yin_yang||null,animal:concept.animal||null},
    provenance:{calculated_fact:null,traditional_source_basis:sourceMap.map(x=>({source_id:x.source_id||x.id,title:x.title,publication:x.publication,url:x.external_url,priority:x.priority,priority_label:x.priority_label})),ai_synthesis:null,personal_observation:personal},
    chart_occurrences:chartOccurrences,
    active_profile:selectedPerson?profileCompareSummary(selectedPerson):null,
    relevant_journal_days:journalDays,
    research_sources:sourceMap,
    research_notes:linkedNotes.map(researchNoteData),
    my_notes:personal,
    related_concepts:relatedConcepts(concept,concepts)
  };
}

function conceptPresentInTechnical(technical,concept){
  if(concept.category==='60 Jiazi'&&String(concept.hanja||'').length===2){
    for(const p of Object.values(technical?.pillars||{})){if(`${p?.stem?.hanja||''}${p?.branch?.hanja||''}`===concept.hanja)return true;}
  }
  return conceptMatchesTechnical(technical,concept)||[concept.preferred_display_name,concept.technical_english_name,...(concept.search_aliases||[])].filter(Boolean).some(v=>JSON.stringify(technical||{}).includes(String(v)));
}

function journalMatchesConcept(entry,c){
  const vals=[entry.element,entry.ten_god,entry.day_stem,entry.day_branch,entry.animal,entry.interactions].map(x=>String(x||''));
  return [c.english,c.preferred_display_name,c.technical_english_name,c.korean,c.hanja,c.animal,c.element,...(c.search_aliases||[])].filter(Boolean).some(q=>vals.some(v=>normaliseAliasKey(v).includes(normaliseAliasKey(q))||normaliseAliasKey(q).includes(normaliseAliasKey(v))));
}
function relatedConcepts(c,all){
  const out=[];for(const x of all){if(x.id===c.id)continue;let score=0;if(c.element&&x.element===c.element)score+=3;if(c.yin_yang&&x.yin_yang===c.yin_yang)score+=1;if(c.category===x.category)score+=1;if(score)out.push({score,...x});}
  return out.sort((a,b)=>b.score-a.score||String(a.english).localeCompare(String(b.english))).slice(0,12).map(({score,...x})=>x);
}
async function fetchPagesByIds(ids,env){const out=[];for(const id of (ids||[]).slice(0,40)){try{out.push(await notionRequest(`/pages/${id}`,{},env));}catch{}}return out;}

async function listResearchLibrary({limit=100},env){
  const t=await resolveOptionalTargets(env);const pages=await queryAllDataSourcePages(t.researchSources,{sorts:[{property:'Added',direction:'descending'}]},env,Math.max(1,Math.min(500,limit)));
  const teachers=await queryAllDataSourcePages(t.teachers,{},env,300).catch(()=>[]);const teacherMap=new Map(teachers.map(p=>[p.id,plainTitle(p.properties?.['Name'])||plainTitle(p.properties?.['Teacher'])||plainTitle(p.properties?.['Author'])]));
  const sources=pages.map(p=>researchSourceSummary(p,teacherMap));
  return {sources,count:sources.length};
}
function researchSourceSummary(p,teacherMap=new Map()){
  const pr=p.properties||{};const authorIds=(pr['Author or Teacher']?.relation||[]).map(x=>x.id);const processing=plainRich(pr['Processing Notes']);const sourceIdentity=parseSourceMeta(processing);
  return {id:p.id,url:p.url||null,title:plainTitle(pr['Source']),source_type:pr['Source Type']?.select?.name||'',publication:plainRich(pr['Publication']),publication_date:pageDateStart(pr['Publication Date']),pages:plainRich(pr['Pages']),external_url:pr['URL']?.url||pr['userDefined:URL']?.url||null,language:(pr['Language']?.multi_select||[]).map(x=>x.name),methodology:plainRich(pr['Methodology']),ai_summary:plainRich(pr['English Summary']),confidence:pr['Confidence']?.select?.name||'',ingestion_status:pr['Ingestion Status']?.select?.name||'',contradiction_flag:!!pr['Contradiction Flag']?.checkbox,processing_notes:processing,source_identity:sourceIdentity,source_id:sourceIdentity?.source_id||null,priority:sourceIdentity?.priority||null,priority_label:sourceIdentity?.priority_label||'',aliases:sourceIdentity?.aliases||[],source_text_available:!!pr['Source Text Available']?.checkbox,concept_ids:(pr['Concepts']?.relation||[]).map(x=>x.id),research_note_ids:(pr['Research Notes']?.relation||[]).map(x=>x.id),author_ids:authorIds,authors:authorIds.map(id=>teacherMap.get(id)).filter(Boolean),original_material:(pr['Original Material']?.files||[]).map(f=>({name:f.name||'',type:f.type,url:f.file?.url||f.external?.url||null}))};
}
function researchNoteData(p){const pr=p.properties||{};return{id:p.id,url:p.url||null,title:plainTitle(pr['Note']),note_type:pr['Note Type']?.select?.name||'',source_derived_content:plainRich(pr['Source-derived Content']),ai_summary:plainRich(pr['AI Summary']),my_interpretation:plainRich(pr['My Interpretation']),questions:plainRich(pr['Questions']),subject_type:pr['Subject Type']?.select?.name||'',subject_key:plainRich(pr['Subject Key']),concept_ids:(pr['Concepts']?.relation||[]).map(x=>x.id)};}
async function loadResearchSourceDetail(id,env){
  if(!id) fail(400,'Research source id is required.');const t=await resolveOptionalTargets(env);const page=await notionRequest(`/pages/${id}`,{},env);const source=researchSourceSummary(page);
  const notePages=source.research_note_ids.length?await fetchPagesByIds(source.research_note_ids,env):await queryAllDataSourcePages(t.researchNotes,{filter:{property:'Source',relation:{contains:id}}},env,100);
  const notes=notePages.map(researchNoteData); const concepts=(await loadConceptIndex((await resolveTargets(null,env)).concepts,env)).filter(c=>source.concept_ids.includes(c.id));
  return {source,concepts,provenance:{
    original_source:notes.filter(n=>n.source_derived_content).map(n=>({note_id:n.id,text:n.source_derived_content})),
    bibliographic:{authors:source.authors,title:source.title,date:source.publication_date,publication:source.publication,pages:source.pages,url:source.external_url,files:source.original_material},
    ai_summary:source.ai_summary||notes.map(n=>n.ai_summary).find(Boolean)||'',
    my_notes:notes.filter(n=>n.my_interpretation).map(n=>({note_id:n.id,text:n.my_interpretation})),
    methodology:source.methodology,
    contradiction_flag:source.contradiction_flag
  },notes};
}

async function notionRequest(path, options, env, attempt = 0) {
  if (!env.NOTION_TOKEN) fail(500, 'NOTION_TOKEN is not configured on this Worker.');
  const method = options?.method || 'GET';
  const headers = {
    'Authorization': `Bearer ${env.NOTION_TOKEN}`,
    'Notion-Version': NOTION_VERSION,
    'Content-Type': 'application/json'
  };
  const resp = await fetch(`${NOTION_API}${path}`, {
    method,
    headers,
    body: options?.body === undefined ? undefined : JSON.stringify(options.body)
  });

  if (resp.status === 429 && attempt < 3) {
    const wait = Math.max(400, Number(resp.headers.get('Retry-After') || 1) * 1000);
    await sleep(wait);
    return notionRequest(path, options, env, attempt + 1);
  }

  const text = await resp.text();
  let body = null;
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!resp.ok) {
    const e = new Error(body?.message || `Notion API returned HTTP ${resp.status}.`);
    e.status = resp.status === 401 || resp.status === 403 ? 502 : Math.min(599, Math.max(400, resp.status));
    e.details = body;
    throw e;
  }
  return body;
}

function title(value) {
  return { title: textObjects(value) };
}
function rich(value) {
  return { rich_text: textObjects(value) };
}
function textObjects(value) {
  const s = String(value ?? '');
  if (!s) return [];
  return chunkText(s, 1900).slice(0, 95).map(content => ({ type: 'text', text: { content } }));
}
function fileUploadsProp(id, name='Original material') {
  return { files: id ? [{ type:'file_upload', file_upload:{ id:String(id) }, name:String(name) }] : [] };
}
function dateProp(value) {
  return { date: value ? { start: String(value).slice(0, 10) } : null };
}
function select(value) {
  return { select: value ? { name: String(value) } : null };
}
function checkbox(value) {
  return { checkbox: !!value };
}
function relation(ids) {
  return { relation: (ids || []).filter(Boolean).map(id => ({ id })) };
}
function numberProp(value) {
  const n = Number(value);
  return { number: Number.isFinite(n) ? n : null };
}
function plainTitle(prop) {
  return (prop?.title || []).map(x => x.plain_text || x.text?.content || '').join('');
}
function plainRich(prop) {
  return (prop?.rich_text || []).map(x => x.plain_text || x.text?.content || '').join('');
}
function chunkText(s, n) {
  const out = [];
  for (let i = 0; i < s.length; i += n) out.push(s.slice(i, i + n));
  return out;
}
function summarizePage(page) {
  if (!page) return null;
  return { id: page.id, url: page.url || null };
}
function todayIso() {
  return new Date().toISOString().slice(0, 10);
}
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
function fail(status, message) {
  const e = new Error(message);
  e.status = status;
  throw e;
}
function cors(response, request, env) {
  // Same-origin hosting is the intended path. This permissive response is only
  // useful for the health API and still requires the private X-Saju-Key.
  const h = new Headers(response.headers);
  h.set('Access-Control-Allow-Origin', request.headers.get('Origin') || '*');
  h.set('Access-Control-Allow-Headers', 'Content-Type, X-Saju-Key');
  h.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  h.set('Vary', 'Origin');
  return new Response(response.body, { status: response.status, headers: h });
}
function json(obj, status = 200, request, env) {
  const response = new Response(JSON.stringify(obj, null, 2), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
  });
  return cors(response, request, env);
}
