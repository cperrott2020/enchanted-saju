import { preferredStemName, preferredJiaziName, preferredTenGodName } from './knowledge_pack.js';

export const DEFAULT_AI_MODEL = '@cf/zai-org/glm-4.7-flash';
export const AI_READING_VERSION = '1.6.0-expanded-daily-reading';

export const DAILY_READING_SCHEMA = {
  type: 'object',
  properties: {
    overall_theme: { type: 'string' },
    day_master_relationship: { type: 'string' },
    elemental_influence: { type: 'string' },
    ten_god_influence: { type: 'string' },
    natal_interactions: { type: 'string' },
    major_luck_context: { type: 'string' },
    annual_context: { type: 'string' },
    monthly_context: { type: 'string' },
    work_study: { type: 'string' },
    relationships: { type: 'string' },
    money_resources: { type: 'string' },
    creativity: { type: 'string' },
    energy_pace: { type: 'string' },
    things_to_notice: { type: 'string' },
    reflection_prompt: { type: 'string' }
  },
  required: [
    'overall_theme','day_master_relationship','elemental_influence','ten_god_influence',
    'natal_interactions','major_luck_context','annual_context','monthly_context',
    'work_study','relationships','money_resources','creativity','energy_pace',
    'things_to_notice','reflection_prompt'
  ],
  additionalProperties: false
};

export function lockedDailyFacts(p) {
  const c = p.calculated;
  return {
    date: p.date,
    timezone: p.timezone,
    natal_day_master: {
      hanja: p.natal.day.stem.hanja,
      korean: p.natal.day.stem.ko,
      romanisation: p.natal.day.stem.roman,
      preferred_name: preferredStemName(p.natal.day.stem.hanja) || null,
      element: p.natal.day.stem.element,
      yin_yang: p.natal.day.stem.yin_yang
    },
    day_pillar: c.day.label,
    day_pillar_preferred_name: preferredJiaziName(c.day.stem.hanja,c.day.branch.animal) || null,
    daily_stem: {
      hanja: c.day.stem.hanja,
      korean: c.day.stem.ko,
      romanisation: c.day.stem.roman,
      preferred_name: preferredStemName(c.day.stem.hanja) || null,
      element: c.day.stem.element,
      yin_yang: c.day.stem.yin_yang
    },
    daily_branch: {
      hanja: c.day.branch.hanja,
      korean: c.day.branch.ko,
      romanisation: c.day.branch.roman,
      animal: c.day.branch.animal,
      element: c.day.branch.element
    },
    daily_ten_god: {...c.day.ten_god, preferred_name:preferredTenGodName(c.day.ten_god)||c.day.ten_god.en, technical_english:c.day.ten_god.en},
    year_pillar: c.year.label,
    month_pillar: c.month.label,
    current_major_luck: p.currentMajor ? {
      cycle: plainCycle(p.currentMajor),
      stem: plainRichProp(p.currentMajor.properties?.['Stem']),
      branch: plainRichProp(p.currentMajor.properties?.['Branch']),
      element: p.currentMajor.properties?.['Element']?.select?.name || '',
      ten_god: plainRichProp(p.currentMajor.properties?.['Ten God'])
    } : null,
    interactions: c.natal_interactions || [],
    interactions_text: c.interactions_text,
    boundary_warnings: c.boundary_warnings || [],
    calculation_engine: c.engine
  };
}

export function selectConceptContext(concepts, p, maxItems = 10) {
  const wanted = [];
  const add = (kind, q) => {
    const hit = findConcept(concepts, q);
    if (!hit) return;
    if (wanted.some(x => x.id === hit.id)) return;
    wanted.push({
      kind,
      english: hit.preferred_display_name || hit.english || '',
      technical_english: hit.technical_english_name || hit.english || '',
      korean: hit.korean || '',
      hanja: hit.hanja || '',
      category: hit.category || '',
      definition: truncate(hit.definition || '', 900),
      interpretation_notes: truncate(hit.interpretation_notes || '', 900)
    });
  };

  add('Natal Day Master', { hanja: p.natal.day.stem.hanja });
  add('Daily Heavenly Stem', { hanja: p.calculated.day.stem.hanja });
  add('Daily Earthly Branch', { hanja: p.calculated.day.branch.hanja });
  add('Daily Ten God', { hanja: p.calculated.day.ten_god.hanja, korean: p.calculated.day.ten_god.ko, english: p.calculated.day.ten_god.en });
  add('Daily Stem Element', { english: p.calculated.day.stem.element, category: 'Element' });

  for (const event of p.calculated.natal_interactions || []) {
    add(`Relationship: ${event.type}`, { english: event.type, category: 'Relationship' });
  }

  return wanted.slice(0, maxItems);
}

export function buildDailyAiMessages(p, concepts = []) {
  const facts = lockedDailyFacts(p);
  const conceptContext = selectConceptContext(concepts, p);

  const system = [
    'You write a concise daily Saju reflection from LOCKED deterministic calculation data.',
    'The calculation data is authoritative and immutable. NEVER recalculate, correct, replace, infer, or contradict any pillar, stem, branch, element, Ten God, luck cycle, or interaction.',
    'Do not invent additional 합/충/형/파/해, symbolic stars, useful elements, chart-strength scores, or other technical Saju factors that are not explicitly supplied.',
    'Interpretation is separate from calculation. Discuss the supplied symbolism as reflective themes and tendencies, not guaranteed events or certainties.',
    'Use the supplied Notion concept notes when present. If they are absent or incomplete, keep the interpretation conservative rather than manufacturing a technical rule.',
    'Do not tell the user that a calculated fact is wrong. Do not output alternative calculated values.',
    'Write in accessible British/Irish English. Use preferred JewelSJPJ terminology first when supplied. For Ten Gods use Self God, Rival God, Creator God, Rebel God, Entrepreneur God, Provider God, Wild Card God, Official God, Mystic God and Nurturer God as the main English labels. Keep Korean/Hanja or conventional technical English secondary where useful.',
    'The practical focus should be grounded and non-deterministic. The reflection prompt should be one useful question.',
    'Return plain text only. Do not return JSON and do not use a code block.',
    'Use these headings exactly once and in this order: Overall Theme; Today\'s Day Master Relationship; Elemental Influence; Ten God Influence; Natal Interactions; Major Luck Context; Annual Context; Monthly Context; Work & Study; Relationships; Money & Resources; Creativity; Energy & Pace; Things to Notice; Reflection Prompt.'
  ].join(' ');

  const user = JSON.stringify({
    task: 'Interpret the following locked daily Saju context without changing any calculated data.',
    locked_calculated_facts: facts,
    source_context_from_notion_glossary: conceptContext,
    requested_tone: 'warm, thoughtful, practical and reflective; approximately 650-950 words total, avoiding certainty or prediction'
  });

  return [{ role: 'system', content: system }, { role: 'user', content: user }];
}

/**
 * Workers AI models do not all return the same envelope. This deliberately
 * accepts both the classic {response:string} shape and OpenAI-style
 * {choices:[{message:{content}}]} output. It also accepts the old structured
 * object format so existing tests and future model switches remain safe.
 */
export function extractAiReadingText(result) {
  const structured = structuredInterpretation(result);
  if (structured) return renderInterpretationSections(structured);

  const candidates = [
    result?.response,
    result?.result?.response,
    result?.choices?.[0]?.message?.content,
    result?.response?.choices?.[0]?.message?.content,
    result?.output_text,
    result?.text
  ];

  for (const value of candidates) {
    const text = contentToText(value);
    if (text) return cleanModelText(text);
  }

  const direct = contentToText(result);
  if (direct) return cleanModelText(direct);
  throw new Error(`Workers AI returned no visible answer text. Response shape: ${describeAiShape(result)}. Reasoning is disabled in v1.3.2; retry once, then send this shape if it persists.`);
}

function structuredInterpretation(result) {
  const objects = [
    result,
    result?.response,
    result?.result?.response,
    result?.choices?.[0]?.message?.parsed,
    result?.choices?.[0]?.message?.content
  ];
  for (const obj of objects) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) continue;
    const keys = DAILY_READING_SCHEMA.required;
    if (keys.every(k => String(obj[k] ?? '').trim())) {
      const clean = {};
      for (const k of keys) clean[k] = truncate(String(obj[k]), k === 'reflection_prompt' ? 500 : 1800);
      return clean;
    }
    // Backward compatibility for v1.3-v1.5 structured fixtures/responses.
    const legacy = ['overall_theme','day_master_relationship','ten_god_theme','cycle_context','interaction_context','practical_focus','reflection_prompt'];
    if (legacy.every(k => String(obj[k] ?? '').trim())) {
      return {
        overall_theme: truncate(String(obj.overall_theme),1800),
        day_master_relationship: truncate(String(obj.day_master_relationship),1800),
        elemental_influence: 'No separate elemental-influence section was returned by this legacy response.',
        ten_god_influence: truncate(String(obj.ten_god_theme),1800),
        natal_interactions: truncate(String(obj.interaction_context),1800),
        major_luck_context: truncate(String(obj.cycle_context),1800),
        annual_context: 'No separate annual-context section was returned by this legacy response.',
        monthly_context: 'No separate monthly-context section was returned by this legacy response.',
        work_study: truncate(String(obj.practical_focus),1800),
        relationships: 'No separate relationships section was returned by this legacy response.',
        money_resources: 'No separate money/resources section was returned by this legacy response.',
        creativity: 'No separate creativity section was returned by this legacy response.',
        energy_pace: truncate(String(obj.practical_focus),1800),
        things_to_notice: truncate(String(obj.interaction_context),1800),
        reflection_prompt: truncate(String(obj.reflection_prompt),500)
      };
    }
  }
  return null;
}

function contentToText(value, depth = 0) {
  if (depth > 4 || value == null) return '';
  if (typeof value === 'string') return value.trim();
  if (Array.isArray(value)) {
    return value.map(item => contentToText(item, depth + 1)).filter(Boolean).join('\n').trim();
  }
  if (typeof value === 'object') {
    // Common chat-content block shapes used by OpenAI-compatible APIs.
    const preferred = ['text', 'content', 'value', 'output_text'];
    for (const key of preferred) {
      if (key in value) {
        const t = contentToText(value[key], depth + 1);
        if (t) return t;
      }
    }
  }
  return '';
}

function describeAiShape(result) {
  try {
    if (result == null) return String(result);
    if (typeof result !== 'object') return typeof result;
    const top = Object.keys(result).slice(0, 12).join(',') || '(no keys)';
    const msg = result?.choices?.[0]?.message;
    if (msg && typeof msg === 'object') {
      const mk = Object.keys(msg).slice(0, 12).join(',') || '(no message keys)';
      const contentType = Array.isArray(msg.content) ? 'array' : msg.content === null ? 'null' : typeof msg.content;
      return `top=[${top}] message=[${mk}] content=${contentType}`;
    }
    return `top=[${top}]`;
  } catch {
    return 'uninspectable';
  }
}

function cleanModelText(text) {
  let t = String(text || '').trim();
  t = t.replace(/^```(?:json|text|markdown)?\s*/i, '').replace(/```\s*$/i, '').trim();
  // If the model ignored the instruction and returned JSON text, recover it.
  if (t.startsWith('{') && t.endsWith('}')) {
    try {
      const obj = JSON.parse(t);
      const structured = structuredInterpretation(obj);
      if (structured) return renderInterpretationSections(structured);
    } catch {}
  }
  if (t.length < 80) throw new Error('Workers AI returned an unusually short Daily Reading. Please retry.');
  return truncate(t, 9000);
}

function renderInterpretationSections(i) {
  return [
    'Overall Theme', i.overall_theme,
    '', "Today's Day Master Relationship", i.day_master_relationship,
    '', 'Elemental Influence', i.elemental_influence,
    '', 'Ten God Influence', i.ten_god_influence,
    '', 'Natal Interactions', i.natal_interactions,
    '', 'Major Luck Context', i.major_luck_context,
    '', 'Annual Context', i.annual_context,
    '', 'Monthly Context', i.monthly_context,
    '', 'Work & Study', i.work_study,
    '', 'Relationships', i.relationships,
    '', 'Money & Resources', i.money_resources,
    '', 'Creativity', i.creativity,
    '', 'Energy & Pace', i.energy_pace,
    '', 'Things to Notice', i.things_to_notice,
    '', 'Reflection Prompt', i.reflection_prompt
  ].join('\n');
}

export function formatDailyReadingText(p, aiText, model) {
  const f = lockedDailyFacts(p);
  const major = f.current_major_luck?.cycle || 'No active Major Luck record found';
  const warnings = f.boundary_warnings.length ? `\nBoundary note: ${f.boundary_warnings.join(' | ')}` : '';
  return [
    `🌸 Daily Saju Reflection · ${f.date}`,
    '',
    'LOCKED CALCULATED CONTEXT',
    `Day Pillar: ${f.day_pillar}`,
    `Ten God: ${f.daily_ten_god.preferred_name||f.daily_ten_god.en} · ${f.daily_ten_god.ko} ${f.daily_ten_god.hanja} · ${f.daily_ten_god.technical_english||f.daily_ten_god.en}`,
    `Year Pillar: ${f.year_pillar}`,
    `Month Pillar: ${f.month_pillar}`,
    `Major Luck: ${major}`,
    `Interactions: ${f.interactions_text}${warnings}`,
    '',
    aiText,
    '',
    `AI interpretation: ${model} · Calculated facts supplied by ${f.calculation_engine.version}. The AI can write only this Daily Reading text; it cannot modify calculated database fields.`
  ].join('\n');
}

function findConcept(concepts, q = {}) {
  const norm = v => String(v || '').trim().toLowerCase();
  const hanja = norm(q.hanja), korean = norm(q.korean), english = norm(q.english), category = norm(q.category);
  const filtered = category ? concepts.filter(c => norm(c.category) === category) : concepts;
  if (hanja) {
    const x = filtered.find(c => norm(c.hanja) === hanja);
    if (x) return x;
  }
  if (korean) {
    const x = filtered.find(c => norm(c.korean) === korean);
    if (x) return x;
  }
  if (english) {
    const x = filtered.find(c => norm(c.english) === english || norm(c.english).includes(english) || english.includes(norm(c.english)));
    if (x) return x;
  }
  return null;
}

function plainCycle(page) {
  return (page?.properties?.['Cycle']?.title || []).map(x => x.plain_text || x.text?.content || '').join('');
}
function plainRichProp(prop) {
  return (prop?.rich_text || []).map(x => x.plain_text || x.text?.content || '').join('');
}
function truncate(value, max) {
  const s = String(value || '').trim();
  return s.length > max ? s.slice(0, max - 1).trimEnd() + '…' : s;
}
