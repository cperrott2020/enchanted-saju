export const PHASE1_ANALYSIS_VERSION = '1.7.0-phase1';

export const PHASE1_METHODS = Object.freeze({
  lunar_conversion: {
    id: 'korean-lunar-calendar-0.4.0-kari-offline-v1',
    description: 'Offline Korean lunar-to-solar conversion using pinned korean-lunar-calendar 0.4.0 data following the Korean KARI/KASI standard, with ordinary versus leap month selected explicitly.'
  },
  weighted_elements: {
    id: 'transparent-hidden-stem-equal-allocation-v1',
    description: 'Transparent Phase 1 weighting: each visible Heavenly Stem contributes 1; each Earthly Branch contributes a total of 1, assigned to main qi when Hidden Stem weighting is off or divided equally across its encoded Hidden Stems when enabled. No unvalidated seasonal, palace or combination multiplier is applied.'
  },
  ten_god_weighting: {
    id: 'transparent-hidden-stem-equal-allocation-v1',
    description: 'Uses the exact same deterministic contributor weights as weighted Five Elements, mapping each contributing stem to its Ten God relative to the Day Master before aggregation.'
  },
  chart_strength: {
    id: 'workbook-support-drain-monthbranch-v1',
    description: 'Supplied Korean Saju Workbook method: Companion + Resource = Support; Output + Wealth + Authority = Drain. Clear cases use Support versus Drain; borderline 4/4 or 5/3 cases are resolved by whether the Month Branch main qi supports or drains the Day Master.'
  }
});

export const PHASE1_DEFAULT_SETTINGS = Object.freeze({
  apply_combination_transformations: false,
  seasonal_adjustment: false,
  palace_weighting: false,
  hidden_stem_weighting: true
});

export const PHASE1_INACTIVE_SETTINGS = Object.freeze({
  apply_combination_transformations: 'Stored for compatibility only. Phase 1 does not apply an elemental transformation without separately validated transformation criteria.',
  seasonal_adjustment: 'Stored for compatibility only. No numeric seasonal multiplier is enabled because the supplied source establishes Month Branch importance but does not supply a reproducible numeric coefficient.',
  palace_weighting: 'Stored for compatibility only. No palace/position numerical formula is enabled in Phase 1.'
});
