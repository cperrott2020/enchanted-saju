import KoreanLunarCalendar from 'korean-lunar-calendar';

export const OFFLINE_LUNAR_RANGE=Object.freeze({min:'1800-01-01',max:'2050-11-18',library_min:'1000-01-01',library_max:'2050-11-18'});
export const KASI_LUNAR_RANGE=OFFLINE_LUNAR_RANGE; // backward-compatible export name
export const LUNAR_RANGE=OFFLINE_LUNAR_RANGE;
export const LUNAR_CONVERSION_METHOD='korean-lunar-calendar-0.4.0-kari-offline-v1';

const pad2=n=>String(n).padStart(2,'0');
const iso=(y,m,d)=>`${String(y).padStart(4,'0')}-${pad2(m)}-${pad2(d)}`;

function bool(v){
  if(typeof v==='boolean') return v;
  if(typeof v==='number') return v!==0;
  return /^(1|true|yes|y|leap|intercalation|윤|윤달)$/i.test(String(v??'').trim());
}
function normalizeArgs(args){
  const a=args[0];
  if(a&&typeof a==='object'&&!Array.isArray(a)){
    const src=a.lunar&&typeof a.lunar==='object'?{...a,...a.lunar}:a;
    return {
      year:Number(src.lunar_year??src.lunYear??src.year),
      month:Number(src.lunar_month??src.lunMonth??src.month),
      day:Number(src.lunar_day??src.lunDay??src.day),
      leap:bool(src.lunar_leap_month??src.leap_month??src.is_leap_month??src.intercalation??src.leap)
    };
  }
  return {year:Number(args[0]),month:Number(args[1]),day:Number(args[2]),leap:bool(args[3])};
}
function validateInput({year,month,day}){
  if(!Number.isInteger(year)||!Number.isInteger(month)||!Number.isInteger(day)) throw new Error('Lunar year, month and day must be whole numbers.');
  if(month<1||month>12||day<1||day>30) throw new Error('Invalid Korean lunar date.');
  const key=iso(year,month,day);
  if(key<OFFLINE_LUNAR_RANGE.min||key>OFFLINE_LUNAR_RANGE.max){
    throw new Error(`Unsupported Lunar date ${key}. Enchanted Saju currently certifies Lunar input from ${OFFLINE_LUNAR_RANGE.min} through ${OFFLINE_LUNAR_RANGE.max}. No approximation was made.`);
  }
}

export async function convertLunarToSolarOffline(...args){
  const input=normalizeArgs(args); validateInput(input);
  const calendar=new KoreanLunarCalendar();
  const accepted=calendar.setLunarDate(input.year,input.month,input.day,input.leap);
  if(!accepted) throw new Error('The requested Korean lunar date is invalid, nonexistent, outside the converter range, or requests a leap month that does not exist.');
  const lunar=calendar.getLunarCalendar();
  // Defensive validation: never silently coerce an impossible leap-month request.
  if(Number(lunar.year)!==input.year||Number(lunar.month)!==input.month||Number(lunar.day)!==input.day||Boolean(lunar.intercalation)!==input.leap){
    throw new Error('The converter did not preserve the requested lunar date/leap-month status. Calculation stopped rather than guessing.');
  }
  const solar=calendar.getSolarCalendar();
  const original=iso(input.year,input.month,input.day);
  const normalised=iso(solar.year,solar.month,solar.day);
  return {
    original_calendar_type:'Lunar',
    original_birth_date:original,
    lunar_year:input.year,
    lunar_month:input.month,
    lunar_day:input.day,
    lunar_leap_month:input.leap,
    normalised_gregorian_date:normalised,
    gregorian_date:normalised,
    solar_date:normalised,
    conversion_method:LUNAR_CONVERSION_METHOD,
    conversion_version:'1.7.1',
    conversion_source:'korean-lunar-calendar 0.4.0; offline bundled data following the Korean KARI/KASI standard',
    source_mode:'offline',
    network_required:false,
    supported_range:{...OFFLINE_LUNAR_RANGE}
  };
}

// Compatibility aliases retained so the existing v1.7 Worker route does not need redesign.
export const convertLunarToSolar=convertLunarToSolarOffline;
export const convertLunarToGregorian=convertLunarToSolarOffline;
export const convertKasiLunarToSolar=convertLunarToSolarOffline;
export const convertLunarToSolarViaKasi=convertLunarToSolarOffline;
export const convertLunarBirthDate=convertLunarToSolarOffline;
export const convertLunarDate=convertLunarToSolarOffline;
export const lunarToSolar=convertLunarToSolarOffline;
export function validateLunarInput(input){const n=normalizeArgs([input]);validateInput(n);return n;}
