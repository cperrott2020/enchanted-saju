import { PHASE1_METHODS, PHASE1_DEFAULT_SETTINGS, PHASE1_INACTIVE_SETTINGS } from './methods.js';

export const ELEMENTS = ['Wood','Fire','Earth','Metal','Water'];
export const TEN_GODS = Object.freeze({
  friend: { en:'Friend / Companion', ko:'비견', hanja:'比肩' },
  rob_wealth: { en:'Rob Wealth', ko:'겁재', hanja:'劫財' },
  eating_god: { en:'Eating God', ko:'식신', hanja:'食神' },
  hurting_officer: { en:'Hurting Officer', ko:'상관', hanja:'傷官' },
  indirect_wealth: { en:'Indirect Wealth', ko:'편재', hanja:'偏財' },
  direct_wealth: { en:'Direct Wealth', ko:'정재', hanja:'正財' },
  seven_killings: { en:'Seven Killings / Indirect Officer', ko:'편관', hanja:'偏官' },
  direct_officer: { en:'Direct Officer', ko:'정관', hanja:'正官' },
  indirect_resource: { en:'Indirect Resource', ko:'편인', hanja:'偏印' },
  direct_resource: { en:'Direct Resource', ko:'정인', hanja:'正印' }
});

const STEMS = [
  {index:0,hanja:'甲',roman:'Gap',element:'Wood',yin_yang:'Yang'},
  {index:1,hanja:'乙',roman:'Eul',element:'Wood',yin_yang:'Yin'},
  {index:2,hanja:'丙',roman:'Byeong',element:'Fire',yin_yang:'Yang'},
  {index:3,hanja:'丁',roman:'Jeong',element:'Fire',yin_yang:'Yin'},
  {index:4,hanja:'戊',roman:'Mu',element:'Earth',yin_yang:'Yang'},
  {index:5,hanja:'己',roman:'Gi',element:'Earth',yin_yang:'Yin'},
  {index:6,hanja:'庚',roman:'Gyeong',element:'Metal',yin_yang:'Yang'},
  {index:7,hanja:'辛',roman:'Sin',element:'Metal',yin_yang:'Yin'},
  {index:8,hanja:'壬',roman:'Im',element:'Water',yin_yang:'Yang'},
  {index:9,hanja:'癸',roman:'Gye',element:'Water',yin_yang:'Yin'}
];
const ELEMENT_INDEX={Wood:0,Fire:1,Earth:2,Metal:3,Water:4};

function mod(n,m){return ((n%m)+m)%m;}
function round(n,d=6){const k=10**d;return Math.round((Number(n)+Number.EPSILON)*k)/k;}
function emptyMap(keys, init=0){return Object.fromEntries(keys.map(k=>[k,typeof init==='function'?init(k):init]));}

export function tenGodFromStemIndexes(dayMasterStemIndex,targetStemIndex){
  const dm=STEMS[dayMasterStemIndex], t=STEMS[targetStemIndex];
  if(!dm||!t) throw new Error('Invalid stem index for Ten God calculation.');
  const d=ELEMENT_INDEX[dm.element], x=ELEMENT_INDEX[t.element], rel=mod(x-d,5), same=dm.yin_yang===t.yin_yang;
  let key;
  if(rel===0) key=same?'friend':'rob_wealth';
  else if(rel===1) key=same?'eating_god':'hurting_officer';
  else if(rel===2) key=same?'indirect_wealth':'direct_wealth';
  else if(rel===3) key=same?'seven_killings':'direct_officer';
  else key=same?'indirect_resource':'direct_resource';
  return {key,...TEN_GODS[key]};
}

function stemIndex(stem){
  if(Number.isInteger(stem?.index)) return stem.index;
  if(Number.isInteger(stem?.stem_index)) return stem.stem_index;
  const h=stem?.hanja || stem?.stem?.hanja;
  const i=STEMS.findIndex(x=>x.hanja===h);
  if(i>=0) return i;
  throw new Error(`Could not resolve stem index from ${JSON.stringify(stem)}`);
}
function stemObj(value){
  if(value?.stem) return stemObj(value.stem);
  const i=stemIndex(value); return STEMS[i];
}
function branchHiddenStems(pillar){
  const list = pillar?.hidden_stems || pillar?.branch?.hidden_stems || [];
  return list.map(x=>stemObj(x));
}
function primaryBranchStem(pillar){
  const hs=branchHiddenStems(pillar);
  if(hs.length) return hs[0];
  throw new Error(`Pillar ${pillar?.label||''} has no encoded Hidden Stem/main qi data.`);
}
function pillarOrder(pillars){
  const names=['year','month','day','hour'];
  const available=names.filter(k=>pillars?.[k]);
  return available;
}

export function visibleEightContributors(pillars){
  const order=pillarOrder(pillars);
  const out=[];
  for(const pos of order){
    const p=pillars[pos];
    const s=stemObj(p.stem);
    out.push({source:'Heavenly Stem',pillar:pos,stem:s,element:s.element,weight:1});
    const q=primaryBranchStem(p);
    out.push({source:'Earthly Branch main qi',pillar:pos,stem:q,branch:p.branch?.hanja||null,element:q.element,weight:1});
  }
  return out;
}

export function rawVisibleElementPresence(pillars){
  const counts=emptyMap(ELEMENTS,0);
  for(const c of visibleEightContributors(pillars)) counts[c.element]++;
  return counts;
}

export function rawVisibleTenGodDistribution(pillars,dayMasterStemIndex){
  const counts=emptyMap(Object.keys(TEN_GODS),0);
  const contributors=[];
  for(const c of visibleEightContributors(pillars)){
    const tg=tenGodFromStemIndexes(dayMasterStemIndex,c.stem.index);
    counts[tg.key]++;
    contributors.push({...c,ten_god:tg});
  }
  return {counts,total:contributors.length,contributors};
}

export function buildWeightedContributors(pillars,settings={}){
  const requested={...PHASE1_DEFAULT_SETTINGS,...settings};
  // Only Hidden Stem allocation is an active numeric setting in Phase 1.
  // The other settings are retained in the audit trail but deliberately do
  // not change scores until a documented deterministic formula is selected.
  const applied={
    ...requested,
    seasonal_adjustment:false,
    apply_combination_transformations:false,
    palace_weighting:false
  };
  const order=pillarOrder(pillars);
  const contributors=[];
  for(const pos of order){
    const p=pillars[pos], visible=stemObj(p.stem);
    contributors.push({
      source:'Heavenly Stem',pillar:pos,stem:visible.hanja,stem_index:visible.index,element:visible.element,
      base_weight:1,modifier:1,final_weight:1,
      reason:'Every visible Heavenly Stem contributes base weight 1 in transparent-hidden-stem-equal-allocation-v1.'
    });

    const hidden=branchHiddenStems(p);
    if(!hidden.length) throw new Error(`No Hidden Stems encoded for ${pos} Branch.`);
    if(applied.hidden_stem_weighting){
      // The supplied material establishes Hidden Stems as meaningful but does
      // not supply a numeric Main/Middle/Residual table. Equal allocation is
      // therefore the neutral, fully disclosed application rule; no unequal
      // classical weight is invented.
      const share=1/hidden.length;
      hidden.forEach((h,i)=>contributors.push({
        source:'Hidden Stem',pillar:pos,branch:p.branch?.hanja||null,
        hidden_role:hidden.length===1?'Main':hidden.length===2?(i===0?'Main':'Residual'):(['Main','Middle','Residual'][i]||`Hidden ${i+1}`),
        stem:h.hanja,stem_index:h.index,element:h.element,
        base_weight:round(share,12),modifier:1,final_weight:round(share,12),
        reason:`The ${pos} Branch has total base weight 1 divided equally across its ${hidden.length} encoded Hidden Stem(s). No unsupported role coefficient is assumed.`
      }));
    }else{
      const h=hidden[0];
      contributors.push({
        source:'Earthly Branch main qi',pillar:pos,branch:p.branch?.hanja||null,hidden_role:'Main',stem:h.hanja,stem_index:h.index,element:h.element,
        base_weight:1,modifier:1,final_weight:1,
        reason:'Hidden Stem weighting is disabled, so the branch total weight 1 is assigned to its encoded main qi.'
      });
    }
  }
  return {
    settings_requested:requested,
    settings_used:applied,
    contributors,
    inactive_settings:{...PHASE1_INACTIVE_SETTINGS}
  };
}

export function weightedFiveElements(pillars,settings={}){
  const raw=rawVisibleElementPresence(pillars);
  const built=buildWeightedContributors(pillars,settings);
  const scores=emptyMap(ELEMENTS,()=>({raw_presence:0,weighted_score:0,percentage:0,components:[]}));
  for(const e of ELEMENTS) scores[e].raw_presence=raw[e];
  let total=0;
  for(const c of built.contributors){
    total+=c.final_weight;
    scores[c.element].weighted_score+=c.final_weight;
    scores[c.element].components.push({...c});
  }
  for(const e of ELEMENTS){
    scores[e].weighted_score=round(scores[e].weighted_score);
    scores[e].percentage=total?round(scores[e].weighted_score/total*100,4):0;
  }
  return {
    method:PHASE1_METHODS.weighted_elements.id,
    method_description:PHASE1_METHODS.weighted_elements.description,
    settings_requested:built.settings_requested,
    settings:built.settings_used,
    total_weight:round(total),
    elements:scores,
    contributors:built.contributors,
    inactive_settings:built.inactive_settings
  };
}

export function weightedTenGods(pillars,dayMasterStemIndex,settings={}){
  const raw=rawVisibleTenGodDistribution(pillars,dayMasterStemIndex);
  const built=buildWeightedContributors(pillars,settings);
  const scores=emptyMap(Object.keys(TEN_GODS),key=>({name:TEN_GODS[key],raw_occurrences:raw.counts[key]||0,weighted_score:0,percentage:0,contributors:[]}));
  let total=0;
  for(const c of built.contributors){
    const tg=tenGodFromStemIndexes(dayMasterStemIndex,c.stem_index);
    total+=c.final_weight;
    scores[tg.key].weighted_score+=c.final_weight;
    scores[tg.key].contributors.push({...c,ten_god:tg});
  }
  for(const k of Object.keys(scores)){
    scores[k].weighted_score=round(scores[k].weighted_score);
    scores[k].percentage=total?round(scores[k].weighted_score/total*100,4):0;
  }
  return {
    method:PHASE1_METHODS.ten_god_weighting.id,
    method_description:PHASE1_METHODS.ten_god_weighting.description,
    settings_requested:built.settings_requested,
    settings:built.settings_used,
    total_weight:round(total),
    distribution:scores,
    contributors:built.contributors,
    inactive_settings:built.inactive_settings
  };
}
