import { PHASE1_METHODS } from './methods.js';
import { ELEMENTS, visibleEightContributors } from './weighted_analysis.js';

const GEN={Wood:'Fire',Fire:'Earth',Earth:'Metal',Metal:'Water',Water:'Wood'};
const CTRL={Wood:'Earth',Earth:'Water',Water:'Fire',Fire:'Metal',Metal:'Wood'};

export function roleForElement(dayMasterElement,target){
  if(target===dayMasterElement) return 'Companion';
  if(GEN[target]===dayMasterElement) return 'Resource';
  if(GEN[dayMasterElement]===target) return 'Output';
  if(CTRL[dayMasterElement]===target) return 'Wealth';
  if(CTRL[target]===dayMasterElement) return 'Authority';
  throw new Error(`Unresolved Five Element role: ${dayMasterElement} vs ${target}`);
}

export function calculateChartStrength(pillars,dayMasterElement){
  if(!ELEMENTS.includes(dayMasterElement)) throw new Error('A valid Day Master element is required for Chart Strength.');
  const contributors=visibleEightContributors(pillars);
  if(contributors.length!==8){
    return {
      status:'unavailable',score:null,strength_index:null,classification:null,borderline:null,provisional:null,
      method:PHASE1_METHODS.chart_strength.id,
      method_description:PHASE1_METHODS.chart_strength.description,
      reason:`${PHASE1_METHODS.chart_strength.id} requires all eight visible characters. ${contributors.length} are available.`,
      breakdown:[]
    };
  }
  const roles={Companion:0,Resource:0,Output:0,Wealth:0,Authority:0};
  const breakdown=contributors.map(c=>{
    const role=roleForElement(dayMasterElement,c.element); roles[role]++;
    return {source:c.source,pillar:c.pillar,stem:c.stem.hanja,element:c.element,role,effect:['Companion','Resource'].includes(role)?'Support':'Drain',weight:1};
  });
  const support=roles.Companion+roles.Resource;
  const drain=roles.Output+roles.Wealth+roles.Authority;
  const difference=support-drain;
  const borderline=Math.abs(difference)<=2;
  const monthBranch=breakdown.find(x=>x.pillar==='month' && x.source==='Earthly Branch main qi') || null;
  const monthBranchEffect=monthBranch?.effect || null;
  let classification;
  let decisionRule;
  if(borderline && monthBranchEffect){
    classification=monthBranchEffect==='Support'?'Strong':'Weak';
    decisionRule=`Borderline ${support}/${drain}: Month Branch main qi is ${monthBranchEffect}, so it decides the classification.`;
  }else{
    classification=support>drain?'Strong':'Weak';
    decisionRule=support>drain?'Support > Drain':'Support <= Drain';
  }
  const score=support/8;
  return {
    status:'calculated',
    score,
    strength_index:score*100,
    classification,
    borderline,
    provisional:borderline,
    support_score:support,
    drain_score:drain,
    seasonal_score:null,
    root_score:null,
    month_branch_role:monthBranch?.role||null,
    month_branch_effect:monthBranchEffect,
    decision_rule:decisionRule,
    method:PHASE1_METHODS.chart_strength.id,
    method_description:PHASE1_METHODS.chart_strength.description,
    thresholds:{
      clear_strong:'Support - Drain > 2',
      clear_weak:'Drain - Support > 2',
      borderline:'absolute Support - Drain <= 2; Month Branch main qi decides Strong versus Weak'
    },
    role_counts:roles,
    breakdown,
    limitations:[
      'Only Strong and Weak are asserted because those are the categories supported by the selected workbook method.',
      'This is not ForceTeller’s undocumented multi-band population strength index.',
      'Hidden Stems beyond branch main qi, special formations and combination transformations are not folded into this Phase 1 strength classifier.'
    ]
  };
}
