import { tenGod, relationshipEventsForPillar, STEMS, BRANCHES } from './daily_engine.js';

const GEN={Wood:'Fire',Fire:'Earth',Earth:'Metal',Metal:'Water',Water:'Wood'};
const CTRL={Wood:'Earth',Earth:'Water',Water:'Fire',Fire:'Metal',Metal:'Wood'};

function clonePillar(p){
  if(!p?.stem||!p?.branch) return null;
  return {stem:{...p.stem},branch:{...p.branch},hidden_stems:[...(p.hidden_stems||p.branch?.hidden_stems||[])]};
}

export function compactTechnicalChart(technical){
  const p=technical?.pillars||{};
  return {
    year:clonePillar(p.year),month:clonePillar(p.month),day:clonePillar(p.day),hour:clonePillar(p.hour),
    day_master:technical?.day_master||p.day?.stem||null,
    elements:technical?.elements||null,
    ten_gods:technical?.ten_gods||null,
    relationships:technical?.relationships||null,
    growth_stages:technical?.growth_stages||null,
    void:technical?.void||null,
    strength:technical?.strength||null,
    useful_element:technical?.useful_element||null,
    favourable_element:technical?.favourable_element||null,
    unfavourable_element:technical?.unfavourable_element||null,
    symbolic_stars:technical?.symbolic_stars||null,
    twelve_stars:technical?.twelve_stars||null
  };
}

export function elementRelationship(a,b){
  if(!a||!b) return {type:'unknown',label:'Unknown'};
  if(a===b) return {type:'same',label:`${a} ↔ ${b}: same element`};
  if(GEN[a]===b) return {type:'a_generates_b',label:`${a} generates ${b}`};
  if(GEN[b]===a) return {type:'b_generates_a',label:`${b} generates ${a}`};
  if(CTRL[a]===b) return {type:'a_controls_b',label:`${a} controls ${b}`};
  if(CTRL[b]===a) return {type:'b_controls_a',label:`${b} controls ${a}`};
  return {type:'indirect',label:`${a} and ${b}: no direct generating/controlling step`};
}

function replaceDailyPosition(event,sourcePos,targetLabel){
  const positions=(event.positions||[]).map((x,i)=>x==='daily'?(i===0?sourcePos:sourcePos):`${targetLabel} ${x}`);
  return {...event,positions,source_position:sourcePos,target_chart:targetLabel};
}

function crossEvents(sourcePillars,targetPillars,sourceLabel,targetLabel){
  const events=[];
  for(const [pos,p] of Object.entries(sourcePillars)){
    if(!p?.stem||!p?.branch) continue;
    const found=relationshipEventsForPillar(p,targetPillars,`${sourceLabel}-to-${targetLabel}`)
      .map(e=>replaceDailyPosition(e,`${sourceLabel} ${pos}`,targetLabel));
    for(const e of found) events.push(e);
  }
  const seen=new Set();
  return events.filter(e=>{
    const k=JSON.stringify([e.relationship,e.subtype||'',(e.participants||[]).slice().sort(),(e.positions||[]).slice().sort(),e.resulting_element||'']);
    if(seen.has(k)) return false; seen.add(k); return true;
  });
}

function tenGodView(chart,otherDm){
  const rows=[];
  for(const [pos,p] of Object.entries({year:chart.year,month:chart.month,day:chart.day,hour:chart.hour})){
    if(!p?.stem) continue;
    rows.push({position:`${pos} stem`,hanja:p.stem.hanja,element:p.stem.element,ten_god:tenGod(otherDm.index,p.stem.index)});
    const main=(p.hidden_stems||p.branch?.hidden_stems||[])[0];
    if(main?.index!==undefined) rows.push({position:`${pos} branch main qi`,hanja:main.hanja,element:main.element,ten_god:tenGod(otherDm.index,main.index)});
  }
  return rows;
}

export function compareCharts({personA,personB,technicalA,technicalB}){
  const A=compactTechnicalChart(technicalA),B=compactTechnicalChart(technicalB);
  if(!A.day?.stem||!B.day?.stem) throw new Error('Both saved charts need a Day Pillar for comparison.');
  const ap={year:A.year,month:A.month,day:A.day,hour:A.hour};
  const bp={year:B.year,month:B.month,day:B.day,hour:B.hour};
  const interactions=crossEvents(ap,bp,'A','B');
  const dayBranch=crossEvents({day:A.day},{day:B.day},'A','B').filter(e=>e.positions?.some(x=>/day/i.test(x)));
  const dmRel=elementRelationship(A.day.stem.element,B.day.stem.element);
  return {
    method:'deterministic-cross-chart-structural-v1',
    people:{a:personA,b:personB},
    day_masters:{
      a:{...A.day.stem},b:{...B.day.stem},element_relationship:dmRel
    },
    five_element_relationship:dmRel,
    heavenly_stem_interactions:interactions.filter(e=>/Stem/i.test(e.relationship)),
    earthly_branch_interactions:interactions.filter(e=>!/Stem/i.test(e.relationship)),
    day_branch_relationships:dayBranch,
    ten_god_relationships:{
      a_components_relative_to_b_day_master:tenGodView(A,B.day.stem),
      b_components_relative_to_a_day_master:tenGodView(B,A.day.stem)
    },
    charts:{a:A,b:B},
    disclaimer:'Structural comparison only. No compatibility score or good/bad verdict is calculated.'
  };
}

export function conceptMatchesTechnical(technical,concept){
  const text=JSON.stringify(technical||{});
  const probes=[concept?.hanja,concept?.korean,concept?.english].filter(Boolean);
  return probes.some(v=>text.includes(String(v)));
}

export function buildCalculationInspector({technical,audit,chart}){
  const birth=technical?.birth||audit?.birth||{};
  const astronomy=audit?.astronomy||technical?.calculation_audit?.astronomy||{};
  const boundary=technical?.boundary_checks||audit?.boundary_check||{};
  const pillars=technical?.pillars||{};
  const li=astronomy?.li_chun_utc||astronomy?.liChunUtc||null;
  const monthBounds=astronomy?.month_boundaries||null;
  const birthUtc=birth?.resolved_utc||null;
  const afterIpchun=(birthUtc&&li)?Date.parse(birthUtc)>=Date.parse(li):null;
  const monthPrev=monthBounds?.previous||monthBounds?.prev||null;
  const monthNext=monthBounds?.next||null;
  const yStem=Number.isInteger(pillars?.year?.stem?.index)?pillars.year.stem.index:null;
  const yBranch=Number.isInteger(pillars?.year?.branch?.index)?pillars.year.branch.index:null;
  const mStem=Number.isInteger(pillars?.month?.stem?.index)?pillars.month.stem.index:null;
  const mBranch=Number.isInteger(pillars?.month?.branch?.index)?pillars.month.branch.index:null;
  const monthIndex=mBranch===null?null:((mBranch-2)%12+12)%12;
  const inferredMonthStem=(yStem===null||monthIndex===null)?null:((2*yStem+2+monthIndex)%10+10)%10;
  const gregorianYear=birthUtc?new Date(birthUtc).getUTCFullYear():null;
  const sajuYear=gregorianYear===null?null:(afterIpchun===false?gregorianYear-1:gregorianYear);
  return {
    year:{
      result:chart?.year_pillar||pillarLabel(pillars.year),
      birth_utc:birthUtc,ipchun_utc:li,after_ipchun:afterIpchun,saju_year:sajuYear,
      stem_index:yStem,branch_index:yBranch,
      formula:sajuYear===null?null:`Year Stem = (${sajuYear} − 4) mod 10; Year Branch = (${sajuYear} − 4) mod 12.`,
      rule:'Saju year changes at the exact Ipchun solar-term boundary used by the deterministic engine.',
      method:technical?.method_registry?.year_boundary||audit?.engine?.year_boundary||'ipchun-swiss-v1'
    },
    month:{
      result:chart?.month_pillar||pillarLabel(pillars.month),
      birth_utc:birthUtc,previous_boundary:monthPrev,next_boundary:monthNext,
      month_index:monthIndex,month_branch_index:mBranch,year_stem_index:yStem,month_stem_index:mStem,
      stem_formula:(yStem===null||monthIndex===null)?null:`Month Stem = (2 × ${yStem} + 2 + ${monthIndex}) mod 10 = ${inferredMonthStem}.`,
      branch_formula:monthIndex===null?null:`Month Branch = (2 + ${monthIndex}) mod 12 = ${mBranch}.`,
      rule:'Saju month is determined by the 12 sectional solar-term boundaries beginning at Ipchun; the Month Stem then follows the engine’s year-stem/month-index formula.',
      method:technical?.method_registry?.month_boundary||audit?.engine?.month_boundary||'sectional-terms-swiss-v1'
    },
    day:{
      result:chart?.day_pillar||pillarLabel(pillars.day),
      effective_local:birth?.effective_for_day_hour||birth?.corrected_solar_local||null,
      day_boundary:technical?.calculation_audit?.engine?.day_boundary||audit?.engine?.day_boundary||null,
      rule:'Day Pillar comes from the deterministic sexagenary-day anchor after the selected day-boundary rule is applied.'
    },
    hour:{
      result:chart?.hour_pillar||pillarLabel(pillars.hour),
      recorded_time:birth?.original_time||chart?.recorded_birth_time||null,
      corrected_time:birth?.corrected_solar_local||chart?.corrected_time||null,
      boundary_sensitive:!!boundary?.boundary_sensitive,
      warnings:boundary?.warnings||[],
      rule:'Hour Pillar uses the saved corrected/effective birth time and double-hour branch rule; unknown time remains unavailable.'
    },
    timezone:{
      iana:birth?.iana_timezone||chart?.timezone||null,
      historical_offset_minutes:birth?.historical_utc_offset_minutes??null,
      solar_correction:birth?.solar_correction||null
    },
    raw:{technical,audit}
  };
}

function pillarLabel(p){
  return p?.stem?.hanja&&p?.branch?.hanja?`${p.stem.hanja}${p.branch.hanja}`:null;
}

export const UPDATE3_VERSION='1.7.3.1-update3-save-hotfix';
