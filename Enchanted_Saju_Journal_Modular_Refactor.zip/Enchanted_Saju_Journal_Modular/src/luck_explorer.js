import { calculateDailyContext, tenGod, relationshipEventsForPillar, growthStage } from './daily_engine.js';

function pad2(n){return String(n).padStart(2,'0');}
function daysInMonth(year,month){return new Date(Date.UTC(year,month,0)).getUTCDate();}

export function annualLuckRange({startYear,endYear,timezone,natal}) {
  const start=Math.max(1800,Number(startYear));
  const end=Math.min(2199,Number(endYear));
  if(!Number.isInteger(start)||!Number.isInteger(end)||start>end||end-start>80) throw new Error('Annual range must be a valid span of at most 81 years.');
  const dm=natal.day.stem.index;
  const out=[];
  for(let year=start;year<=end;year++){
    const c=calculateDailyContext({date:`${year}-06-15`,timezone,natal});
    out.push({
      gregorian_year:year,
      effective_saju_year:c.year.effective_saju_year,
      label:c.year.label,
      stem:c.year.stem,
      branch:c.year.branch,
      animal:c.year.branch.animal,
      element:c.year.stem.element,
      ten_god:tenGod(dm,c.year.stem.index),
      growth_stage:growthStage(dm,c.year.branch.index),
      start_utc:c.year.start_utc,
      end_utc:c.year.end_utc,
      natal_interactions:relationshipEventsForPillar(c.year,natal,'annual')
    });
  }
  return out;
}

export function monthlyLuckYear({year,timezone,natal}) {
  year=Number(year);
  if(!Number.isInteger(year)||year<1800||year>2199) throw new Error('Monthly explorer supports years 1800–2199.');
  // A Saju year contains exactly 12 solar-term months from the In month after Ipchun
  // through the Chuk month immediately before the following Ipchun. We sample well
  // inside each month, then use calculateDailyContext's exact Swiss boundaries.
  const samples=[];
  for(let month=2;month<=12;month++) samples.push(`${year}-${pad2(month)}-15`);
  samples.push(`${year+1}-01-15`);
  const seen=new Map();
  for(const date of samples){
    const c=calculateDailyContext({date,timezone,natal});
    if(!seen.has(c.month.start_utc)) seen.set(c.month.start_utc,c);
  }
  const dm=natal.day.stem.index;
  const rows=[...seen.values()].sort((a,b)=>Date.parse(a.month.start_utc)-Date.parse(b.month.start_utc));
  if(rows.length!==12) throw new Error(`Solar-month explorer expected 12 months but resolved ${rows.length}; review boundary sampling.`);
  return rows.map(c=>({
      saju_year:year,
      month_index:c.month.month_index,
      label:c.month.label,
      stem:c.month.stem,
      branch:c.month.branch,
      animal:c.month.branch.animal,
      element:c.month.stem.element,
      ten_god:tenGod(dm,c.month.stem.index),
      growth_stage:growthStage(dm,c.month.branch.index),
      start_utc:c.month.start_utc,
      end_utc:c.month.end_utc,
      start_longitude:c.month.start_longitude,
      natal_interactions:relationshipEventsForPillar(c.month,natal,'monthly')
    }));
}

export function dailyLuckMonth({year,month,timezone,natal}) {
  year=Number(year);month=Number(month);
  if(!Number.isInteger(year)||!Number.isInteger(month)||year<1800||year>2200||month<1||month>12) throw new Error('Invalid calendar month.');
  const dim=daysInMonth(year,month);
  const days=[];
  for(let day=1;day<=dim;day++){
    const date=`${year}-${pad2(month)}-${pad2(day)}`;
    const c=calculateDailyContext({date,timezone,natal});
    days.push({
      date,
      day:c.day,
      year:c.year,
      month:c.month,
      natal_interactions:c.structured_interactions || relationshipEventsForPillar(c.day,natal,'daily'),
      boundary_warnings:c.boundary_warnings
    });
  }
  return days;
}
