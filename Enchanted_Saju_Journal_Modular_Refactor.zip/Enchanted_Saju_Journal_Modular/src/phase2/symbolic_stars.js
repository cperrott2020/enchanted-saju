import { PHASE2_METHODS, SYMBOLIC_STAR_RULES } from './methods.js';

const TRINES=[
  {members:[8,0,4],peach:9,travel:2,canopy:4,label:'申子辰'},
  {members:[2,6,10],peach:3,travel:8,canopy:10,label:'寅午戌'},
  {members:[5,9,1],peach:6,travel:11,canopy:1,label:'巳酉丑'},
  {members:[11,3,7],peach:0,travel:5,canopy:7,label:'亥卯未'}
];
const NOBLE={0:[1,7],4:[1,7],6:[1,7],1:[0,8],5:[0,8],2:[11,9],3:[11,9],8:[3,5],9:[3,5],7:[2,6]};
const META={
  peach:{english:'Peach Blossom',korean:'도화살',hanja:'桃花煞',rule:'peach-blossom-year-day-trine-v1',traditional:'Traditionally associated with social visibility, attraction and interpersonal attention.'},
  travel:{english:'Travelling Horse',korean:'역마살',hanja:'驛馬煞',rule:'travelling-horse-year-day-trine-v1',traditional:'Traditionally associated with movement, travel, relocation and change of environment.'},
  canopy:{english:'Flower Canopy',korean:'화개살',hanja:'華蓋煞',rule:'flower-canopy-year-day-trine-v1',traditional:'Traditionally associated with solitary study, art, spirituality or specialised interests.'},
  noble:{english:'Heavenly Nobleman',korean:'천을귀인',hanja:'天乙貴人',rule:'heavenly-nobleman-day-stem-v1',traditional:'Traditionally associated with assistance, protection or helpful people.'}
};
const positions=['hour','day','month','year'];
const branchIndex=p=>Number.isInteger(p?.branch?.index)?p.branch.index:null;
const groupFor=b=>TRINES.find(g=>g.members.includes(b))||null;

function hitsForTarget(pillars,target,meta,reference){
  const detected=[];
  for(const pos of positions){const p=pillars?.[pos];if(p&&branchIndex(p)===target) detected.push({pillar:pos,branch:p.branch?.hanja||null});}
  if(!detected.length)return null;
  return {
    star:meta.english,korean:meta.korean,hanja:meta.hanja,
    trigger:`${reference.rule_text}; target branch ${detected[0].branch}`,
    reference_pillar:reference.pillar,reference_value:reference.value,reference_basis:reference.basis,
    detected_in:detected.map(x=>`${x.pillar} Branch`),result_positions:detected,
    method_version:meta.rule,traditional_interpretation:meta.traditional
  };
}

export function calculateSymbolicStars(pillars){
  const detected=[];
  for(const refPos of ['year','day']){
    const b=branchIndex(pillars?.[refPos]); if(!Number.isInteger(b))continue;
    const g=groupFor(b); if(!g)continue;
    const reference={pillar:refPos,value:pillars[refPos].branch?.hanja||null,basis:`Natal ${refPos} Branch`,rule_text:`Reference ${g.label} 삼합 group`};
    for(const [kind,target] of [['peach',g.peach],['travel',g.travel],['canopy',g.canopy]]){
      const hit=hitsForTarget(pillars,target,META[kind],reference); if(hit)detected.push(hit);
    }
  }
  const dayStem=Number.isInteger(pillars?.day?.stem?.index)?pillars.day.stem.index:null;
  if(Number.isInteger(dayStem)){
    for(const target of (NOBLE[dayStem]||[])){
      const hit=hitsForTarget(pillars,target,META.noble,{pillar:'day',value:pillars.day.stem?.hanja||null,basis:'Natal Day Stem',rule_text:`Day Stem ${pillars.day.stem?.hanja||''} Heavenly Nobleman table`});
      if(hit)detected.push(hit);
    }
  }
  const seen=new Set();
  const unique=detected.filter(x=>{const k=[x.star,x.reference_pillar,x.reference_value,x.detected_in.join(',')].join('|');if(seen.has(k))return false;seen.add(k);return true;});
  return {
    status:'calculated',method:PHASE2_METHODS.symbolic_stars,
    enabled_rules:SYMBOLIC_STAR_RULES.map(x=>({...x})),detected:unique,
    methodological_notes:[
      'Only four explicitly tabled rules are enabled in v1.7 Complete. Other named 신살 remain unimplemented rather than inferred.',
      'Peach Blossom, Travelling Horse and Flower Canopy use both natal Year-Branch and Day-Branch 삼합 references.',
      'Heavenly Nobleman uses the natal Day Stem. The selected table is versioned because alternate classical assignments exist for some stems.'
    ]
  };
}
