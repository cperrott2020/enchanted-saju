import { deriveUsefulElements } from './useful_elements.js';
import { calculateSymbolicStars } from './symbolic_stars.js';
import { calculateTwelveStars } from './twelve_stars.js';
import { PHASE2_ANALYSIS_VERSION, PHASE2_METHODS } from './methods.js';

export function phase2Analysis({pillars,day_master,strength}){
  const elements=deriveUsefulElements({pillars,day_master,strength});
  return {
    version:PHASE2_ANALYSIS_VERSION,
    useful_element:elements.useful_element,
    favourable_element:elements.favourable_element,
    unfavourable_element:elements.unfavourable_element,
    symbolic_stars:calculateSymbolicStars(pillars||{}),
    twelve_stars:calculateTwelveStars(pillars||{}),
    methods:{...PHASE2_METHODS}
  };
}
