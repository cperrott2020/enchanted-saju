export const PHASE2_ANALYSIS_VERSION='1.7-complete';

export const PHASE2_METHODS=Object.freeze({
  useful_element:'workbook-useful-god-simplified-v1',
  favourable_element:'workbook-useful-god-simplified-v1',
  unfavourable_element:'workbook-useful-god-simplified-v1',
  symbolic_stars:'symbolic-stars-four-rule-set-v1',
  twelve_stars:'year-branch-trine-12sinsal-v1'
});

export const ELEMENT_LABELS=Object.freeze({
  Wood:{english:'Wood',korean:'목',hanja:'木'},
  Fire:{english:'Fire',korean:'화',hanja:'火'},
  Earth:{english:'Earth',korean:'토',hanja:'土'},
  Metal:{english:'Metal',korean:'금',hanja:'金'},
  Water:{english:'Water',korean:'수',hanja:'水'}
});

export const SYMBOLIC_STAR_RULES=Object.freeze([
  {id:'peach-blossom-year-day-trine-v1',method_version:'peach-blossom-year-day-trine-v1',english:'Peach Blossom',korean:'도화살',hanja:'桃花煞',reference_position:['Natal Year Branch','Natal Day Branch'],result_position:'Any natal Earthly Branch',trigger_rule:'Find the reference branch 삼합 group, then detect its fixed Peach Blossom target branch.',trigger_table:{'申子辰':'酉','寅午戌':'卯','巳酉丑':'午','亥卯未':'子'}},
  {id:'travelling-horse-year-day-trine-v1',method_version:'travelling-horse-year-day-trine-v1',english:'Travelling Horse',korean:'역마살',hanja:'驛馬煞',reference_position:['Natal Year Branch','Natal Day Branch'],result_position:'Any natal Earthly Branch',trigger_rule:'Find the reference branch 삼합 group, then detect its fixed Travelling Horse target branch.',trigger_table:{'申子辰':'寅','寅午戌':'申','巳酉丑':'亥','亥卯未':'巳'}},
  {id:'flower-canopy-year-day-trine-v1',method_version:'flower-canopy-year-day-trine-v1',english:'Flower Canopy',korean:'화개살',hanja:'華蓋煞',reference_position:['Natal Year Branch','Natal Day Branch'],result_position:'Any natal Earthly Branch',trigger_rule:'Find the reference branch 삼합 group, then detect its fixed Flower Canopy target branch.',trigger_table:{'申子辰':'辰','寅午戌':'戌','巳酉丑':'丑','亥卯未':'未'}},
  {id:'heavenly-nobleman-day-stem-v1',method_version:'heavenly-nobleman-day-stem-v1',english:'Heavenly Nobleman',korean:'천을귀인',hanja:'天乙貴人',reference_position:['Natal Day Stem'],result_position:'Any natal Earthly Branch',trigger_rule:'Use the selected Day-Stem Heavenly Nobleman lookup table and detect either target branch in the natal branches.',trigger_table:{'甲戊庚':'丑未','乙己':'子申','丙丁':'亥酉','壬癸':'卯巳','辛':'寅午'}}
]);

export const TWELVE_STAR_RULE_VERSION='year-branch-trine-12sinsal-v1';
