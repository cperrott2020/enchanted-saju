import { ELEMENT_LABELS, PHASE2_METHODS } from './methods.js';

const GENERATES={Wood:'Fire',Fire:'Earth',Earth:'Metal',Metal:'Water',Water:'Wood'};
const CONTROLS={Wood:'Earth',Fire:'Metal',Earth:'Water',Metal:'Wood',Water:'Fire'};
const ELEMENTS=Object.keys(ELEMENT_LABELS);
const reverse=(map,target)=>Object.keys(map).find(k=>map[k]===target)||null;

export function roleElements(dayMasterElement){
  if(!ELEMENTS.includes(dayMasterElement)) throw new Error(`Unsupported Day Master element: ${dayMasterElement}`);
  return {
    Companion:dayMasterElement,
    Resource:reverse(GENERATES,dayMasterElement),
    Output:GENERATES[dayMasterElement],
    Wealth:CONTROLS[dayMasterElement],
    Authority:reverse(CONTROLS,dayMasterElement)
  };
}

function resultElement(element){return element?{...ELEMENT_LABELS[element]}:null;}
function factor(key,value,rule){return {factor:key,value,rule};}

export function deriveUsefulElements({day_master,pillars,strength}){
  const dayElement=day_master?.element||pillars?.day?.stem?.element||null;
  const method=PHASE2_METHODS.useful_element;
  if(!dayElement||!strength||strength.status!=='calculated'||!strength.classification){
    const reason=!dayElement?'Day Master element unavailable.':'Phase 1 Chart Strength is unavailable; Useful Element is not guessed.';
    return {
      useful_element:{status:'unavailable',result:null,method,factors:[factor('availability',false,reason)],confidence:'unavailable',methodological_notes:[reason]},
      favourable_element:{status:'unavailable',result:null,method:PHASE2_METHODS.favourable_element,factors:[]},
      unfavourable_element:{status:'unavailable',result:[],method:PHASE2_METHODS.unfavourable_element,factors:[]}
    };
  }
  const roles=roleElements(dayElement);
  const counts={Companion:0,Resource:0,Output:0,Wealth:0,Authority:0,...(strength.role_counts||{})};
  let usefulRole=null,selectedRule='';
  const outputException=counts.Output>=3&&counts.Output>counts.Wealth&&counts.Output>counts.Authority;
  if(strength.classification==='Weak'){
    if(outputException){usefulRole='Resource';selectedRule='Weak Day Master exception: Output is the clearly dominant drain (3+ of eight and greater than Wealth and Authority), so Resource is selected.';}
    else{usefulRole='Companion';selectedRule='Weak Day Master default: reinforce the Day Master with its own element / Companion.';}
  } else if(strength.classification==='Strong'){
    if(counts.Resource>counts.Companion){usefulRole='Wealth';selectedRule='Strong Day Master: Resource exceeds Companion, so Wealth is selected to check excess Resource.';}
    else if(counts.Companion>counts.Resource){usefulRole='Authority';selectedRule='Strong Day Master: Companion exceeds Resource, so Authority is selected to restrain excess Companion.';}
    else{usefulRole='Output';selectedRule='Strong Day Master: Resource and Companion are equal, so Output is selected to drain surplus.';}
  } else {
    return {useful_element:{status:'unavailable',result:null,method,factors:[],confidence:'unavailable',methodological_notes:[`Unsupported strength classification: ${strength.classification}`]},favourable_element:{status:'unavailable',result:null,method:PHASE2_METHODS.favourable_element,factors:[]},unfavourable_element:{status:'unavailable',result:[],method:PHASE2_METHODS.unfavourable_element,factors:[]}};
  }
  const useful=roles[usefulRole];
  const favourable=reverse(GENERATES,useful);
  const unfavourable=reverse(CONTROLS,useful);
  const confidence=strength.borderline?'provisional':'method-consistent';
  const commonFactors=[
    factor('day_master_element',dayElement,'Role relationships are defined relative to the Day Master.'),
    factor('chart_strength',strength.classification,`Phase 1 method: ${strength.method}`),
    factor('support_score',strength.support_score,'Companion + Resource.'),
    factor('drain_score',strength.drain_score,'Output + Wealth + Authority.'),
    factor('role_counts',counts,'Eight visible characters grouped into the workbook five-role table.'),
    factor('month_branch_effect',strength.month_branch_effect||null,strength.borderline?'Borderline strength case is decided by the Month Branch main qi.':'Not required as a tiebreak in this clear strength case.'),
    factor('output_exception',outputException,'For a weak Day Master, Resource replaces Companion only when Output is clearly dominant: Output >= 3 and exceeds Wealth and Authority.'),
    factor('selected_useful_role',usefulRole,selectedRule)
  ];
  return {
    useful_element:{
      status:'calculated',result:resultElement(useful),element:useful,korean:ELEMENT_LABELS[useful].korean,hanja:ELEMENT_LABELS[useful].hanja,
      role:usefulRole,method,reasoning_data:commonFactors,factors:commonFactors,confidence,provisional:!!strength.borderline,
      methodological_notes:['This is the supplied workbook’s simplified Useful God method, not a claim of universal school consensus.',strength.borderline?'Strength was a workbook borderline case; the result is therefore marked provisional.':'Strength was not borderline under the active Phase 1 rule.']
    },
    favourable_element:{
      status:'calculated',result:resultElement(favourable),element:favourable,method:PHASE2_METHODS.favourable_element,
      factors:[factor('useful_element',useful,'Workbook rule: Favourable God is the element that produces the Useful God.'),factor('derivation',`${favourable} → ${useful}`,'Five Element generating cycle.')],confidence
    },
    unfavourable_element:{
      status:'calculated',result:[resultElement(unfavourable)],elements:[unfavourable],method:PHASE2_METHODS.unfavourable_element,
      factors:[factor('useful_element',useful,'Workbook rule: Unfavourable God is the element that controls the Useful God.'),factor('derivation',`${unfavourable} controls ${useful}`,'Five Element controlling cycle.')],confidence
    }
  };
}
