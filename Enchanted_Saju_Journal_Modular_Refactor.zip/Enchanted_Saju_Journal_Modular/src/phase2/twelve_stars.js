import { PHASE2_METHODS, TWELVE_STAR_RULE_VERSION } from './methods.js';

export const TWELVE_STARS=Object.freeze([
  {english:'Robbery Star',korean:'겁살',hanja:'劫煞'},
  {english:'Disaster Star',korean:'재살',hanja:'災煞'},
  {english:'Heavenly Star',korean:'천살',hanja:'天煞'},
  {english:'Earth Star',korean:'지살',hanja:'地煞'},
  {english:'Year Star',korean:'년살',hanja:'年煞'},
  {english:'Month Star',korean:'월살',hanja:'月煞'},
  {english:'Loss of Reputation Star',korean:'망신살',hanja:'亡身煞'},
  {english:'General Star',korean:'장성살',hanja:'將星煞'},
  {english:'Saddle Star',korean:'반안살',hanja:'攀鞍煞'},
  {english:'Travelling Horse',korean:'역마살',hanja:'驛馬煞'},
  {english:'Six Harm Star',korean:'육해살',hanja:'六害煞'},
  {english:'Flower Canopy',korean:'화개살',hanja:'華蓋煞'}
]);
const GROUPS=[
  {members:[8,0,4],start:5,label:'申子辰'},
  {members:[2,6,10],start:11,label:'寅午戌'},
  {members:[5,9,1],start:2,label:'巳酉丑'},
  {members:[11,3,7],start:8,label:'亥卯未'}
];
const positions=['hour','day','month','year'];
const bidx=p=>Number.isInteger(p?.branch?.index)?p.branch.index:null;

export function calculateTwelveStars(pillars){
  const y=bidx(pillars?.year);
  const group=GROUPS.find(g=>g.members.includes(y));
  if(!group)return {status:'unavailable',method:PHASE2_METHODS.twelve_stars,reference_basis:'Natal Year Branch',reference_value:pillars?.year?.branch?.hanja||null,rule_version:TWELVE_STAR_RULE_VERSION,pillars:{},methodological_notes:['Natal Year Branch is required.']};
  const results={};
  for(const pos of positions){
    const p=pillars?.[pos]; const b=bidx(p); if(!p||!Number.isInteger(b))continue;
    const idx=(b-group.start+12)%12; const star=TWELVE_STARS[idx];
    results[pos]={name:star.english,korean:star.korean,hanja:star.hanja,reference_basis:'Natal Year Branch',reference_value:pillars.year.branch?.hanja||null,trigger:`${group.label} 삼합 reference; branch ${p.branch?.hanja||''} is sequence position ${idx+1}`,pillar_result:pos,branch:p.branch?.hanja||null,method_version:TWELVE_STAR_RULE_VERSION};
  }
  return {status:'calculated',method:PHASE2_METHODS.twelve_stars,reference_basis:'Natal Year Branch',reference_value:pillars.year.branch?.hanja||null,reference_group:group.label,rule_version:TWELVE_STAR_RULE_VERSION,pillars:results,methodological_notes:['This is the year-branch-reference 삼합 Twelve Stars / 십이신살 system. It is a separate data structure from Twelve Growth Stages / 십이운성.','Some practitioners use a Day-Branch reference instead. That convention is not blended into this method version.']};
}
