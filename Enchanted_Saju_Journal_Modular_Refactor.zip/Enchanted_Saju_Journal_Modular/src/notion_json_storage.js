export const NOTION_JSON_STORAGE_MAX_CHARS = 179000;

export function compactJsonForNotion(value, label='Structured Notion JSON', max=NOTION_JSON_STORAGE_MAX_CHARS) {
  const json=JSON.stringify(value);
  if(json.length>max){
    throw new Error(`${label} exceeds the ${max}-character Notion storage safety limit even after compact serialization (${json.length}). No truncation was performed.`);
  }
  return json;
}

export function technicalResultForNotion(master){
  if(!master || typeof master!=='object') return master;
  const { calculation_audit, ...technical } = master;
  return {
    ...technical,
    calculation_audit_storage:{
      embedded:false,
      property:'Calculation Audit JSON',
      note:'The complete audit is stored separately to avoid duplicating the same large structure inside Technical Result JSON.'
    }
  };
}
