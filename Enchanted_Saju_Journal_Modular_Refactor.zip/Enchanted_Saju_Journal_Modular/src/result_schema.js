import { RESULT_SCHEMA_VERSION, ANALYSIS_VERSION, METHOD_REGISTRY, DEFAULT_ANALYSIS_SETTINGS, METHOD_DESCRIPTIONS } from './method_registry.js';
import { phase2Analysis } from './phase2/phase2_analysis.js';

function pendingPhase2(){return {
  useful_element:{status:'unavailable',result:null,method:METHOD_REGISTRY.useful_element,factors:[],reasoning_data:[]},
  favourable_element:{status:'unavailable',result:null,method:METHOD_REGISTRY.useful_element,factors:[]},
  unfavourable_element:{status:'unavailable',result:[],method:METHOD_REGISTRY.useful_element,factors:[]},
  symbolic_stars:{status:'unavailable',method:METHOD_REGISTRY.symbolic_stars,enabled_rules:[],detected:[]},
  twelve_stars:{status:'unavailable',method:METHOD_REGISTRY.twelve_stars,pillars:{}}
};}

export function masterResultFromPayload(payload) {
  const raw = payload?.raw_calculation || {};
  const chart = payload?.chart || {};
  const pillars = chart.pillars || raw.pillars || {};
  const settings = {
    ...DEFAULT_ANALYSIS_SETTINGS,
    ...(payload?.analysis_settings || {}),
    ...(chart?.analysis_settings || {}),
    ...(raw?.analysis_settings || {})
  };
  const calendarConversion = chart.calendar_conversion || raw.calendar_conversion || {
    original_calendar_type: chart.calendar_type || raw.input_calendar || 'Gregorian',
    original_birth_date: chart.birth_date || raw?.birth?.original_date || null,
    normalised_gregorian_date: chart.birth_date || raw?.birth?.original_date || null,
    conversion_method: (chart.calendar_type || raw.input_calendar)==='Lunar' ? METHOD_REGISTRY.lunar_conversion : 'identity-gregorian-v1',
    conversion_version: '1'
  };
  const weightedElements = chart.weighted_elements || raw.elements_weighted || raw.weighted_elements || null;
  const weightedTenGods = chart.weighted_ten_gods || raw.weighted_ten_gods || null;
  const rawTenGods = chart.raw_ten_gods || raw.raw_ten_gods || null;
  const strength = chart.chart_strength_result || raw.chart_strength_result || raw.strength || {
    status:'unavailable', method:METHOD_REGISTRY.chart_strength, score:null, strength_index:null, classification:null, breakdown:[]
  };

  let derived=pendingPhase2();
  try{
    if(Object.keys(pillars).length && strength) derived=phase2Analysis({pillars,day_master:chart.day_master||raw.day_master||pillars?.day?.stem,strength});
  }catch{}
  const useful=chart.useful_element||raw.useful_element||derived.useful_element;
  const favourable=chart.favourable_element||raw.favourable_element||derived.favourable_element;
  const unfavourable=chart.unfavourable_element||raw.unfavourable_element||derived.unfavourable_element;
  const symbolic=chart.symbolic_stars||raw.symbolic_stars||derived.symbolic_stars;
  const twelve=chart.twelve_stars||raw.twelve_stars||derived.twelve_stars;

  const phase1Audit = {
    calendar_conversion: calendarConversion,
    element_weighting: weightedElements ? {
      method: weightedElements.method, settings_requested: weightedElements.settings_requested || settings, settings_used: weightedElements.settings || settings,
      total_weight: weightedElements.total_weight, contributors: weightedElements.contributors || [], inactive_settings: weightedElements.inactive_settings || {}
    } : null,
    ten_god_weighting: weightedTenGods ? {
      method: weightedTenGods.method, settings_requested: weightedTenGods.settings_requested || settings, settings_used: weightedTenGods.settings || settings,
      total_weight: weightedTenGods.total_weight, contributors: weightedTenGods.contributors || []
    } : null,
    chart_strength: strength ? {
      method: strength.method, score: strength.score, strength_index: strength.strength_index, classification: strength.classification,
      thresholds: strength.thresholds || {}, support_score: strength.support_score ?? null, drain_score: strength.drain_score ?? null,
      month_branch_role: strength.month_branch_role ?? null, month_branch_effect: strength.month_branch_effect ?? null,
      decision_rule: strength.decision_rule ?? null, breakdown: strength.breakdown || []
    } : null
  };
  const phase2Audit={
    useful_element:{method:useful?.method||METHOD_REGISTRY.useful_element,input_factors:useful?.factors||useful?.reasoning_data||[],result:useful?.result||null,confidence:useful?.confidence||null},
    favourable_element:{method:favourable?.method||METHOD_REGISTRY.useful_element,input_factors:favourable?.factors||[],result:favourable?.result||null},
    unfavourable_element:{method:unfavourable?.method||METHOD_REGISTRY.useful_element,input_factors:unfavourable?.factors||[],result:unfavourable?.result||[]},
    symbolic_stars:{method:symbolic?.method||METHOD_REGISTRY.symbolic_stars,enabled_rule_list:symbolic?.enabled_rules||[],rule_versions:(symbolic?.enabled_rules||[]).map(x=>x.id),detected:symbolic?.detected||[]},
    twelve_stars:{method:twelve?.method||METHOD_REGISTRY.twelve_stars,rule_version:twelve?.rule_version||METHOD_REGISTRY.twelve_stars,reference_basis:twelve?.reference_basis||null,reference_value:twelve?.reference_value||null}
  };

  return {
    schema_version: RESULT_SCHEMA_VERSION,
    analysis_version: ANALYSIS_VERSION,
    generated_at: payload?.generated_at || new Date().toISOString(),
    person: payload?.person || {},
    input_calendar: chart.calendar_type || raw.input_calendar || 'Gregorian',
    calendar_conversion: calendarConversion,
    birth: raw.birth || {
      original_date: chart.birth_date || payload?.person?.birth_date || null,
      original_time: chart.recorded_birth_time || payload?.person?.birth_time || null,
      birthplace: chart.birthplace || payload?.person?.birthplace || null,
      timezone: chart.timezone || payload?.person?.timezone || null
    },
    normalised_birth: {
      gregorian_date: calendarConversion.normalised_gregorian_date || chart.birth_date || raw?.birth?.original_date || null,
      corrected_time: chart.corrected_time || raw?.birth?.corrected_solar_local || null,
      timezone: chart.timezone || raw?.birth?.iana_timezone || null,
      solar_correction: raw?.birth?.solar_correction || null
    },
    boundary_checks: raw?.boundary_check || {},
    pillars,
    day_master: chart.day_master || raw?.day_master || null,
    hidden_stems: Object.fromEntries(Object.entries(pillars).map(([key,p]) => [key, p?.hidden_stems || p?.branch?.hidden_stems || []])),
    elements: {
      raw: chart.five_elements || raw?.five_elements || {}, weighted: weightedElements,
      method: METHOD_REGISTRY.weighted_elements, method_description: METHOD_DESCRIPTIONS.weighted_elements, settings
    },
    ten_gods: {
      pillars: Object.fromEntries(Object.entries(pillars).map(([key,p]) => [key, { stem: p?.stem?.ten_god || null, hidden_stems: (p?.hidden_stems || p?.branch?.hidden_stems || []).map(x => x?.ten_god || null) }])),
      raw_distribution: rawTenGods, weighted_distribution: weightedTenGods, distribution: weightedTenGods,
      method: METHOD_REGISTRY.ten_god_weighting, method_description: METHOD_DESCRIPTIONS.ten_god_weighting
    },
    relationships: chart.relationships || raw?.relationships || {},
    growth_stages: Object.fromEntries(Object.entries(pillars).map(([key,p]) => [key, p?.growth_stage || null])),
    void: chart.void || raw?.void || {},
    strength,
    useful_element: useful,
    favourable_element: favourable,
    unfavourable_element: unfavourable,
    symbolic_stars: symbolic,
    twelve_stars: twelve,
    major_luck_meta: { direction: raw?.daewoon?.direction || null, start_age_years: raw?.daewoon?.start_age_years ?? null, days_to_sectional_term: raw?.daewoon?.days_to_sectional_term ?? null, method: raw?.daewoon?.method || chart?.major_luck_method || null },
    major_luck: Array.isArray(payload?.major_luck_cycles) ? payload.major_luck_cycles : raw?.daewoon?.cycles || [],
    annual_luck: [], monthly_luck: [], analysis_settings: settings,
    method_registry: METHOD_REGISTRY, method_descriptions: METHOD_DESCRIPTIONS,
    calculation_audit: {
      ...(payload?.audit || { engine: raw?.engine || {}, birth: raw?.birth || {}, astronomy: raw?.astronomy || {}, boundary_check: raw?.boundary_check || {} }),
      phase1: phase1Audit,
      phase2: phase2Audit
    },
    revision: { current: 1, parent_revision: null, reason: 'Initial verified save' }
  };
}

export function stringifyForNotion(value, max = 150000) {
  const s = JSON.stringify(value, null, 2);
  if (s.length > max) throw new Error(`Structured Notion JSON exceeds the ${max}-character safety limit (${s.length}). Refusing to save truncated/invalid JSON.`);
  return s;
}
