# Update 5 Visual System

## Design motto

**Rigorous Saju underneath; enchanted personal field journal on the surface.**

## Core palette

| Role | Value |
|---|---|
| Cream | `#F5EFE3` |
| Paper | `#ECE3D2` |
| Blush | `#EED6D9` |
| Dusty pink | `#D7A5AF` |
| Rose | `#B77F8B` |
| Sage | `#AAB69D` |
| Fern | `#78846C` |
| Moss | `#5F6955` |
| Olive | `#909579` |
| Mushroom | `#A28D7B` |
| Brown | `#66564B` |
| Deep brown | `#443A34` |
| Lilac | `#C6B7CF` |
| Periwinkle | `#AEB9D7` |
| Moon blue | `#879CB7` |
| Antique gold | `#B99D69` |

## Reusable visual roles

- Botanical card: source/data card with restrained botanical corners
- Scrapbook card: textured paper / label treatment
- Fairy-shrine card: more decorative profile and hero treatment
- Celestial card: blue/lilac dream layer
- Technical card: quiet cream/sage surface for calculation and audit data
- Fairy-ring: cyclical spiral/orbit motif used at low opacity
- Type emblem/card: element + branch animal + Yin/Yang modular identity

## Type-art system

The generator is kept in `scripts_build_sjpj_art.py` so future visual refinements can regenerate all 60 types consistently instead of manually drifting apart.

The current release supplies a complete Phase-1 modular art set (emblem + reference/profile card) for every type. The system is deliberately source-neutral: type keywords are not invented by the art generator, and decorative motifs are not inserted into calculated or source-backed interpretation fields.
