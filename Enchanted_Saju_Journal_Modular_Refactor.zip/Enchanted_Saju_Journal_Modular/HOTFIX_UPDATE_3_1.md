# Enchanted Saju Update 3.1 — Structured Notion JSON Save Hotfix

## Error fixed

`Save failed: Structured Notion JSON exceeds the 150000-character safety limit (...)`

The calculation itself was not failing. The saved master result had grown beyond the deliberately conservative v1.7 JSON-property limit because Update 3 contains much richer technical, Phase 1 and Phase 2 data.

## Fix

- Structured JSON is now stored as compact JSON rather than pretty-printed JSON.
- `Technical Result JSON` no longer embeds a second copy of the complete Calculation Audit; it contains an explicit pointer to the separate `Calculation Audit JSON` property.
- `Calculation Audit JSON` remains complete and valid JSON.
- No JSON is cut mid-object or saved invalid.
- The Notion rich-text chunk budget is increased safely from 80 to 95 chunks.
- The readable Chart page audit is appended in batches instead of silently stopping at 70 code blocks.
- Older Chart revisions remain readable because the loader already reads Technical Result and Calculation Audit as separate properties.

## Calculation impact

None. The deterministic Saju engine, Phase 1/2 methods, Today, Daily Luck, Calendar, Journal, Timeline, comparison and AI calculation boundary are unchanged.
