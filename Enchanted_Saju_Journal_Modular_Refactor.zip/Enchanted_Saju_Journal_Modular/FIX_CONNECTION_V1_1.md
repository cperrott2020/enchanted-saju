# Connection Fix v1.1

This update removes reliance on hard-coded Notion data-source IDs.

The Worker now uses the Notion Search API with the **Saju Cloudflare Bridge's own token** to discover these original databases by title:

- People
- Charts
- Readings
- Luck Cycles
- Saju Concepts

## Updating an existing installation on Windows

1. Unzip this new folder.
2. Double-click `update_existing_windows.bat`.
3. If Cloudflare asks you to log in, approve the login.
4. You do **not** need to enter your Notion token again.
5. You do **not** need to set a new connection key.
6. Open the same `workers.dev` URL.
7. Hard refresh (Ctrl+F5).
8. Enter your existing private connection key and click **Test Notion connection**.

If it still fails, the new error will list which Saju databases the integration can actually see. That makes the remaining permission issue identifiable instead of only showing an opaque ID.
