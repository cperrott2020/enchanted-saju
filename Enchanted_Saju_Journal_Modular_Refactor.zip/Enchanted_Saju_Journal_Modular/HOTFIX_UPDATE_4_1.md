# Enchanted Saju — Update 4.1 Import / Resume Hotfix

This hotfix fixes the behaviour seen when Saju Atelier begins returning temporary HTTP 503 responses part-way through the Initial Knowledge Source Pack import.

## Changes

- **Import / Resume Pack** now skips every source already saved in Notion as **Ready** or **Needs Review**.
- **Retry Failed Sources** retries only the locally saved failure queue. When upgrading from the original Update 4 importer (which did not save a failure queue), it safely falls back to all currently missing sources — so the existing 10 imported records are not repeated.
- Saju Atelier source requests are spaced by **4 seconds**.
- Temporary HTTP **429 / 500 / 502 / 503 / 504** responses are retried using **5s → 15s → 30s** backoff.
- A server-provided **Retry-After** header is honoured when it asks for a longer delay, including both numeric seconds and HTTP-date formats.
- After **three consecutive temporary Saju Atelier failures**, the queue cools down for **60 seconds** before continuing.
- A **Pause Import** button was added. The queue can be resumed later; successful sources are discovered from Notion and skipped automatically.
- Failed / temporarily unavailable source IDs are persisted in browser local storage so **Retry Failed Sources** remains useful after a reload.
- Progress wording now distinguishes **Temporarily Unavailable** from a hard failure and never claims an unavailable page was ingested.

## What to do after deployment

Because your previous Update 4 run already saved the first 10 source records, deploy this hotfix and then open:

**Research → Initial Knowledge Source Pack → Retry Failed Sources**

On the first run after upgrading, the old importer has no saved local failure list, so the button will detect the **currently missing** source records from Notion and retry those. It will not redo sources already stored as Ready / Needs Review.

You can also use **Import / Resume Pack**. It uses the same skip-existing logic and is safe to resume.
