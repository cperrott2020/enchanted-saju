# Enchanted Saju — Update 4.2

This is an in-place update for the same Cloudflare Worker created by the earlier Enchanted Saju releases.

Update 4.2 adds the nine supplied JewelSJPJ *How to Read Your SJPJ* lesson captures to the private source pack and changes the ordinary Ten God vocabulary to JewelSJPJ's accessible labels.

After deployment, use **Research → Initial Knowledge Source Pack → Import / Resume Pack**. The existing Update 4.1 resume logic skips sources already stored as Ready / Needs Review, imports the two new embedded Jewel lesson records, and can continue any Saju Atelier sources that were previously throttled.

The deterministic chart engine is unchanged. Existing saved charts do not need recalculation.

See `UPDATE_4_2_JEWEL_TEN_GODS.md` for the complete terminology map.
