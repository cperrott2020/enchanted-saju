# v1.6.1 — Save Verified Chart hotfix

If v1.6 showed:

`Save failed: Could not find property with name or id: Birth Date`

Notion was resolving an unrelated database also named **People**. Your actual My Saju Journal People data source *does* contain `Birth Date`.

v1.6.1 fixes this by preferring the exact configured My Saju Journal data-source IDs before any title-based discovery.

## Update

1. Extract the v1.6.1 ZIP.
2. Double-click `update_existing_windows.bat`.
3. Open the same workers.dev URL and press **Ctrl+F5**.
4. Click **Test Notion connection**.
5. Try **Save Verified Chart** again.

No new Notion token, save key, or Workers AI setup is required.
