#!/usr/bin/env bash
echo "KASI_SERVICE_KEY is no longer required. v1.7 Complete uses the pinned offline Korean lunar calendar converter."
