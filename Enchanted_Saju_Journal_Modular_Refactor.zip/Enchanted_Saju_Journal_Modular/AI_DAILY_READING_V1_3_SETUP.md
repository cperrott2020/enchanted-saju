> **v1.3.2 note:** GLM thinking is explicitly disabled for this short Daily Reading task. If you previously saw “unsupported response shape”, deploy v1.3.2 and use **Regenerate AI Daily Reading**.

# Enchanted Saju Journal v1.3 — Workers AI Daily Reading

This update adds **Workers AI interpretation** after the deterministic Daily Luck record is created.

The architecture is deliberately separated:

1. The Saju engine calculates and writes the Day Pillar, Ten God, Year Pillar, Month Pillar, Major/Annual/Monthly cycles, and configured natal interactions.
2. Workers AI receives a **read-only copy** of those facts plus relevant entries from your Notion Saju Concepts glossary.
3. The Worker accepts the AI's interpretation text and performs a separate Notion update containing exactly **one property: `Daily Reading`**.

The AI model has no Notion tools, no page-update capability, and no code path that writes the calculated fields.

## What you need to do

### 1. Download and extract v1.3

Extract the ZIP to a normal folder on your computer.

### 2. Run the update script

On Windows, double-click:

`update_existing_windows.bat`

This uses your **existing Cloudflare Worker**, existing `NOTION_TOKEN`, and existing `SAJU_SAVE_KEY`. You do not need to create a new Notion integration or enter another AI API key.

The script will:

- install/update Wrangler;
- run the deterministic calculation test;
- run the AI data-integrity test;
- deploy the same Worker with a Workers AI binding.

### 3. Hard-refresh the calculator

Open your existing `https://...workers.dev` address and press **Ctrl + F5**.

### 4. Test the connection

Under **04 · Export & Notion**, click **Test Notion connection**.

A successful v1.3 connection should mention:

`Workers AI ready (@cf/zai-org/glm-4.7-flash)`

If it says `Workers AI binding missing`, the v1.3 deployment did not finish successfully.

### 5. Try one day manually

Go to **05 · Daily Luck + AI Reading**.

1. Choose a date.
2. Confirm the timezone.
3. Click **Preview Daily Cycle**. This is deterministic and does not use AI.
4. Click **Generate Daily Luck + AI Reading**.
5. Open the returned Daily Luck Notion page.

The record should contain the calculated fields as before, and the `Daily Reading` property should now contain a structured reflection.

## Regenerating interpretation without touching calculation

Use:

**Regenerate AI Daily Reading**

This calls `/api/daily/interpret` and updates only `Daily Reading` for that date. It does not recalculate or rewrite the other Notion properties.

## Automatic daily generation

Your existing hourly Cloudflare Cron Trigger remains in place. When the configured local timezone reaches midnight, it:

1. calculates Daily Luck;
2. creates/updates the Notion Daily Luck record;
3. attempts the AI Daily Reading.

If Workers AI fails or reaches a quota/capacity limit, the deterministic Daily Luck record still succeeds. The AI failure is treated as non-fatal.

## Free-plan model

The default model is:

`@cf/zai-org/glm-4.7-flash`

It is configured in `wrangler.toml` as `SAJU_AI_MODEL`. Workers AI uses the Cloudflare AI binding, so there is no third-party API key in the browser.

To disable automatic AI while keeping deterministic Daily Luck running, change:

`SAJU_AI_DAILY_ENABLED = "true"`

to:

`SAJU_AI_DAILY_ENABLED = "false"`

and redeploy.

## What the AI is allowed to do

It may write reflective prose about:

- overall daily theme;
- relationship to the natal Day Master;
- the already-calculated Ten God;
- the already-stored Major Luck and current Year/Month context;
- the already-detected natal interactions;
- practical focus;
- one reflection question.

It is explicitly instructed not to calculate or invent new technical Saju data.

## What the AI cannot write to

The Notion API PATCH produced by the AI stage contains only:

`Daily Reading`

It cannot update:

- Date;
- Day Stem;
- Day Branch;
- Element;
- Yin/Yang;
- Ten God;
- Year Pillar;
- Month Pillar;
- Interactions;
- Major Cycle;
- Annual Cycle;
- Monthly Cycle;
- glossary relations;
- Journal;
- Mood;
- Energy;
- Productivity;
- Events;
- Retrospective.

## Endpoints added/updated

- `GET /api/daily/calculate` — deterministic preview only.
- `POST /api/daily/generate` — deterministic save, then AI interpretation if enabled.
- `POST /api/daily/interpret` — regenerate only the AI Daily Reading for an existing Daily Luck date.

All endpoints still require your private `X-Saju-Key` connection key.
